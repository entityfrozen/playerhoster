#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;

uniform sampler2D Sampler0;
out vec2 arcCanvas;
out vec3 arcView;
flat out ivec2 arcCarrier;
flat out vec3 arcClock;
flat out ivec2 arcNoiseBase;
#moj_import <minecraft:globals.glsl>
out vec3 aspectPoint;
out vec3 aspectNormal;
flat out int aspectMaterial;
#moj_import <minecraft:ascension_mesh_vertex.glsl>
void main() {
  ivec2 atlasSize=textureSize(Sampler0,0);
  ivec2 texel=clamp(ivec2(floor(UV0*vec2(atlasSize))),ivec2(0),atlasSize-1);
  ivec4 stamp=ivec4(round(texelFetch(Sampler0,texel,0)*255.));
  vec3 meshNormal;
  vec3 itemPosition=aspectVertex(texel,stamp,meshNormal,aspectMaterial);
  aspectPoint=itemPosition;
  aspectNormal=mat3(ModelViewMat)*meshNormal;
  bool carrier=stamp.r>=44&&stamp.r<=47&&stamp.g>=7&&stamp.g<=18&&stamp.a==253
    &&(stamp.b>=0&&stamp.b<132);
  int corner=stamp.r-44;
  arcCanvas=carrier?vec2(float(corner&1),float((corner>>1)&1)):vec2(0.);
  arcCarrier=carrier?ivec2(stamp.g-7,stamp.b):ivec2(-1);
  arcView=(ModelViewMat*vec4(itemPosition,1.)).xyz;
  arcClock=round(Color.rgb*255.);
  arcNoiseBase=ivec2(-1);
  if(carrier&&stamp.b==9){
    ivec2 base=texel-ivec2((stamp.g-7)*16+(corner&1)*15,((corner>>1)&1)*15);
    if(all(greaterThanEqual(base,ivec2(0)))&&all(lessThan(base+ivec2(1023),atlasSize))){
      ivec4 flag=ivec4(round(texelFetch(Sampler0,base+ivec2(192,0),0)*255.));
      if(all(equal(flag,ivec4(71,80,16,254))))arcNoiseBase=base;
    }
  }else if(carrier&&stamp.b<85){
    int slot=stamp.b*12+stamp.g-7;
    ivec2 base=texel-ivec2((slot%64)*16+(corner&1)*15,(slot/64)*16+((corner>>1)&1)*15);
    if(all(greaterThanEqual(base,ivec2(0)))&&all(lessThan(base+ivec2(1023,1279),atlasSize))){
      ivec4 flag=ivec4(round(texelFetch(Sampler0,base+ivec2(0,256),0)*255.));
      if(all(equal(flag,ivec4(71,80,0,254))))arcNoiseBase=base;
    }
  }


    gl_Position = ProjMat * ModelViewMat * vec4(itemPosition, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}
