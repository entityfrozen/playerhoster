Blades of War 2 v2.1, by Zerotekz. Assets supplied by the project owner.
Imported: Bloody Lance, Angelic Bow (including draw stages), and Knight Killer (Aspect Killer visual).
Original ZIP SHA-256: 54da2c7fd78a0628846adbd05d13ad566fdb7a072031afed06ce2d515e30cdf0
Vanilla name-based overrides and unrelated assets are not imported.
