#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:projection.glsl>
flat in ivec2 arcNoiseBase;
flat in ivec2 arcCarrier;
#moj_import <minecraft:ascension_volume.glsl>
in vec2 arcCanvas;
in vec3 arcView;
flat in vec3 arcClock;
in vec3 aspectPoint;
in vec3 aspectNormal;
flat in int aspectMaterial;
#moj_import <minecraft:ascension_mesh_surface.glsl>
void main() {
  gl_FragDepth=gl_FragCoord.z;
  if(aspectMaterial>=0){fragColor=aspectSurface(aspectMaterial,aspectPoint,aspectNormal,arcView)*ColorModulator;return;}
  if(arcCarrier.x>=0){
    int face=arcCarrier.x;vec3 local=arcLocal(face,arcCanvas);
    vec3 du=dFdx(arcView),dv=dFdy(arcView);vec2 ux=dFdx(arcCanvas),uy=dFdy(arcCanvas);
    float det=ux.x*uy.y-ux.y*uy.x;if(abs(det)<1e-12)discard;
    vec3 vu=(du*uy.y-dv*ux.y)/det*.5,vv=(-du*uy.x+dv*ux.x)/det*.5;
    vec3 lu=(arcLocal(face,vec2(1,0))-arcLocal(face,vec2(0,0)))*.5;
    vec3 lv=(arcLocal(face,vec2(0,1))-arcLocal(face,vec2(0,0)))*.5;
    vec3 ln=arcLocal(face,vec2(.5));
    bool rigged=arcClock.g>=128.&&arcClock.g<255.;
    vec3 ratios=rigged?vec3(exp2((arcClock.r-127.)/12.),exp2((arcClock.g-192.)/6.),1.):vec3(1.);
    float unit=length(vu)/dot(abs(lu),ratios);vec3 vn=normalize(cross(vu,vv))*sign(dot(cross(lu,lv),ln));
    vec3 wn=vn*unit*dot(abs(ln),ratios);
    mat3 basis=mat3(vu*lu.x+vv*lv.x+wn*ln.x,vu*lu.y+vv*lv.y+wn*ln.y,vu*lu.z+vv*lv.z+wn*ln.z);
    vec3 center=arcView-basis*local;mat3 undo=rigged?transpose(mat3(basis[0]/dot(basis[0],basis[0]),basis[1]/dot(basis[1],basis[1]),basis[2]/dot(basis[2],basis[2]))):transpose(basis)/max(unit*unit,1e-20);
    vec3 ro=undo*(-center),rd=normalize(undo*normalize(arcView));
    bool inside=all(lessThan(abs(ro),vec3(1.0001)));
    if((face>=6)!=inside)discard;
    if(dot(normalize(arcView),vn)*(inside?1.:-1.)<0.)discard;
    float time=GameTime*1200.,age=-1.;
    if(rigged){time=arcCarrier.y==129?mod(GameTime*12000.-arcClock.b+250.,250.)/10.:mod(GameTime*24000.-arcClock.b+250.,250.)/20.;}
    else if(arcClock.g<=93.){
      float born=arcClock.g*256.+arcClock.b;
      age=max(0.,mod(GameTime*24000.-born+36000.,24000.)-12000.);
      time=age/20.;
    }
    if(!rigged&&arcClock.r<255.&&age>=arcClock.r)discard;
    float hit;vec4 effect=arcRender(arcCarrier.y,ro,rd,time,hit);
    if(!rigged&&arcClock.r<255.&&age>=0.)effect.a*=1.-smoothstep(arcClock.r*.82,arcClock.r,age);
    if(effect.a<.005)discard;
    vec3 viewHit=center+basis*(ro+rd*hit);vec4 clip=ProjMat*vec4(viewHit,1.);
    gl_FragDepth=arcCarrier.y==105?0.:clamp(clip.z/clip.w*.5+.5,0.,1.);
    fragColor=effect*ColorModulator;
    if(fragColor.a<.005)discard;
    return;
  }

    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= vertexColor * ColorModulator;
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
