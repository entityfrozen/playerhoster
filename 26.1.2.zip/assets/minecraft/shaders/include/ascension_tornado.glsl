// Original 0.9.2 tornado: identical 64 samples, density, dust, colors and debris.
// Cache only repeated hash lattice values, at 16-bit precision; do not simplify the cloud.
vec2 tornadoHashPair(vec4 sampleValue){
  return (sampleValue.rb*256.+sampleValue.ga)/257.;
}
vec4 tornadoCorners(ivec3 cell){
  int index=2*((cell.z*80+cell.y)*80+cell.x);
  ivec2 a=arcNoiseBase+ivec2(index%1024,16+index/1024),b=arcNoiseBase+ivec2((index+1)%1024,16+(index+1)/1024);
  return vec4(tornadoHashPair(texelFetch(Sampler0,a,0)),tornadoHashPair(texelFetch(Sampler0,b,0)));
}
float tornadoNoise(vec3 p){
  ivec3 cell=ivec3(floor(p));
  if(arcNoiseBase.x<0||any(lessThan(cell,ivec3(-40)))||any(greaterThanEqual(cell,ivec3(39))))return noise3(p);
  vec3 f=fract(p);f=f*f*(3.-2.*f);cell+=40;
  vec4 lower=tornadoCorners(cell),upper=tornadoCorners(cell+ivec3(0,0,1));
  return mix(mix(mix(lower.x,lower.y,f.x),mix(lower.z,lower.w,f.x),f.y),mix(mix(upper.x,upper.y,f.x),mix(upper.z,upper.w,f.x),f.y),f.z);
}
float tornadoFbm(vec3 p){return tornadoNoise(p)*.57+tornadoNoise(p*2.07+17.3)*.28+tornadoNoise(p*4.13-9.1)*.15;}
vec2 tornadoCloudSpan(vec3 ro,vec3 rd,float begin,float end){
  float enter=begin,leave=end;
  if(abs(rd.y)<1e-7){if(ro.y<-.84||ro.y>.85)return vec2(end+1.,begin-1.);}
  else{vec2 y=vec2((-.84-ro.y)/rd.y,(.85-ro.y)/rd.y);enter=max(enter,min(y.x,y.y));leave=min(leave,max(y.x,y.y));}
  for(int i=0;i<8;i++){
    float a=float(i)*ASC_PI/4.;vec3 n=vec3(cos(a),-.64/1.64,sin(a));float den=dot(n,rd),distance=.70-dot(n,ro);
    if(abs(den)<1e-7){if(distance<0.)return vec2(end+1.,begin-1.);}
    else if(den<0.)enter=max(enter,distance/den);else leave=min(leave,distance/den);
  }
  return vec2(enter,leave);
}
vec4 funnelSurface(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec4 sum=vec4(0);hit=begin;bool touched=false;
  float stepSize=(end-begin)/64.;
  vec2 cloudSpan=tornadoCloudSpan(ro,rd,begin,end);
  vec3 inv=1./(rd+vec3(1e-8)),a=(vec3(-.8,-1.,-.8)-ro)*inv,b=(vec3(.8,-.27,.8)-ro)*inv;
  vec3 lo=min(a,b),hi=max(a,b);
  vec2 dustSpan=vec2(max(begin,max(max(lo.x,lo.y),lo.z)),min(end,min(min(hi.x,hi.y),hi.z)));
  if(cloudSpan.y<cloudSpan.x)cloudSpan=vec2(end+1.,begin-1.);
  if(dustSpan.y<dustSpan.x)dustSpan=vec2(end+1.,begin-1.);
  float enter=min(cloudSpan.x,dustSpan.x),leave=max(cloudSpan.y,dustSpan.y);
  int first=max(0,int(floor((enter-begin)/stepSize-.5))-1),last=min(63,int(ceil((leave-begin)/stepSize-.5))+1);
  for(int i=first;i<=last;i++){
    float s=begin+(float(i)+.5)*stepSize;vec3 p=ro+rd*s;
    if((s<cloudSpan.x||s>cloudSpan.y)&&(s<dustSpan.x||s>dustSpan.y))continue;
    float density=0.;vec3 color=vec3(0);

      float h=clamp((p.y+.82)/1.64,0.,1.);vec3 q=p;
      q.xz-=vec2(sin(h*3.-t*.65),cos(h*4.+t*.5))*.055*h;
      float r=length(q.xz),radius=.105+.55*pow(h,1.4);
      radius+=.03*sin(h*12.-t*1.2)+.03*sin(h*21.+t*2.);
      float skirt=exp(-pow((p.y+.73)/.10,2.))*(1.-smoothstep(.43,.72,r));
      bool cloudPossible=p.y>-.84&&p.y<.85&&r<radius+.1875;
      // These samples cannot affect an 8-bit output. Preserve the original sample positions.
      if(!cloudPossible&&skirt<1e-8)continue;
      float angle=atan(q.z,q.x);
      vec3 uv=vec3(cos(angle+h*9.-t*3.)*r*7.,h*9.-t*.7,sin(angle+h*9.-t*3.)*r*7.);
      float cloud=tornadoFbm(uv+vec3(tornadoNoise(uv*.7)*2.)),detail=tornadoNoise(uv*5.1);
      density=(1.-smoothstep(radius*.68,radius+.06,(r+(cloud-.5)*.22+(detail-.5)*.035)))*smoothstep(-.84,-.74,p.y)*(1.-smoothstep(.73,.85,p.y));
      density=(density*(.5+cloud*.9)+skirt*.7)*(1.+detail*.35)*5.;
      float light=clamp(.17+cloud*.72+detail*.12+max(0.,-p.x)*.22,0.,1.);
      color=mix(vec3(.12,.10,.085),vec3(.66,.69,.68),light);
      color=mix(vec3(.25,.19,.12),color,smoothstep(-.8,-.25,p.y));
    float alpha=1.-exp(-density*stepSize);
    if(alpha>.009&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;
    if(sum.a>.985)break;
  }

    for(int i=0;i<12;i++){
      float k=float(i),seed=hash31(vec3(k,8,2)),phase=fract(seed+t*.19);
      float h=phase*1.1-.73,r=.31+phase*.30,a=k*2.39996-t*(2.3-seed);
      vec3 c=vec3(cos(a)*r,h,sin(a)*r);float radius=.007+seed*.010;
      vec3 delta=ro-c;float along=dot(delta,rd);
      if(dot(delta,delta)-along*along>radius*radius*3.)continue;
      vec3 n;float s=fragmentEntry(ro,rd,c,radius,seed,n);
      if(s<end){
        vec3 color=vec3(.12,.085,.045)*(.6+.4*max(0.,n.y));
        if(s<hit){sum=vec4(color,1.);hit=s;}else if(sum.a<.95){sum.rgb+=(1.-sum.a)*color;sum.a=1.;}
      }
    }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
