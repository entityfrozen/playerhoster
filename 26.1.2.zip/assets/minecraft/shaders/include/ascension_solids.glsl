bool clipSide(vec3 ro,vec3 rd,vec3 n,float offset,inout float enter,inout float leave,inout vec3 normal){
  float den=dot(n,rd),distance=offset-dot(n,ro);
  if(abs(den)<1e-8)return distance>=0.;float s=distance/den;
  if(den<0.){if(s>enter){enter=s;normal=n;}}else leave=min(leave,s);
  return leave>=enter;
}
float boxEntry(vec3 ro,vec3 rd,vec3 size,bool facets,out vec3 normal){
  float enter=0.,leave=1e5;normal=vec3(0,1,0);
  for(int i=0;i<3;i++)for(int side=-1;side<=1;side+=2){vec3 n=vec3(0);n[i]=float(side);if(!clipSide(ro,rd,n,size[i],enter,leave,normal))return 1e5;}
  if(facets){
    if(!clipSide(ro,rd,normalize(vec3(.7,1.,.35)),size.y*.77,enter,leave,normal))return 1e5;
    if(!clipSide(ro,rd,normalize(vec3(-.9,.35,.8)),size.x*.97,enter,leave,normal))return 1e5;
    if(!clipSide(ro,rd,normalize(vec3(.3,-.4,-1.)),size.z*.89,enter,leave,normal))return 1e5;
  }
  return enter>0.?enter:leave>0.?leave:1e5;
}
float prismEntry(vec3 ro,vec3 rd,float radius,float height,out vec3 normal){
  float enter=0.,leave=1e5;normal=vec3(0,1,0);
  if(!clipSide(ro,rd,vec3(0,1,0),height*.5,enter,leave,normal)||!clipSide(ro,rd,vec3(0,-1,0),height*.5,enter,leave,normal))return 1e5;
  for(int i=0;i<6;i++){
    float a=float(i)*1.047197;vec3 n=vec3(cos(a),0,sin(a));
    if(!clipSide(ro,rd,n,radius,enter,leave,normal))return 1e5;
    n.y=radius*1.9/height;
    if(!clipSide(ro,rd,n,radius,enter,leave,normal))return 1e5;
  }
  normal=normalize(normal);return enter>0.?enter:leave>0.?leave:1e5;
}
vec4 solidScene(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal=vec3(0,1,0);
  if(mode==1||mode==5){
    for(int i=0;i<8;i++){
      vec3 c,size,o=ro,d=rd;
      if(i==0){c=vec3(0,-.07,-.40);size=vec3(.215,.185,.245);}
      else if(i==1){c=vec3(0,-.04,.04);size=vec3(.395,.235,.255);}
      else if(i<6){c=vec3((float(i-2)-1.5)*.23,.20,.32);size=vec3(.106,.192,.182);}
      else if(i==6){c=vec3(0,-.06,.34);size=vec3(.37,.11,.14);}
      else{c=vec3(-.43,-.15,.16);size=vec3(.135,.145,.225);}
      o-=c;if(i==7){o.xy=spin(-.45)*o.xy;d.xy=spin(-.45)*d.xy;}
      vec3 n;float s=boxEntry(o,d,size,false,n);if(s<min(hit,end)&&s>=begin){hit=s;if(i==7)n.xy=spin(.45)*n.xy;normal=n;}
    }
  }else if(mode==17||mode==53){
    int count=mode==17?8:9;
    for(int i=0;i<9;i++){if(i>=count)break;vec3 c=vec3(0),size;
      if(mode==17){
        if(i==0)size=vec3(.18,.655,.18);
        else if(i<6){c.y=-.48+float(i-1)*.24;size=vec3(.213,.043,.213);}
        else{c.y=i==6?.68:-.68;size=vec3(.242,.087,.242);}
      }else{
        if(i==0)size=vec3(.192,.472,.192);
        else{int k=i-1,corner=k%4;c=vec3(corner%2==0?-.15:.15,k<4?-.63:.63,corner<2?-.15:.15);size=vec3(.073,.198,.073);}
      }
      vec3 n;float s=boxEntry(ro-c,rd,size,false,n);if(s<min(hit,end)&&s>=begin){hit=s;normal=n;}
    }
  }else if(mode==12||mode==18){
    int count=mode==12?7:1;
    for(int i=0;i<7;i++){if(i>=count)break;float k=float(i),seed=hash31(vec3(k,3,6));
      vec3 o=ro,d=rd,size;
      if(mode==12){o-=vec3((k-3.)*.19,-.22+seed*.12,sin(k*3.)*.16);o.xy=spin((seed-.5)*.75)*o.xy;d.xy=spin((seed-.5)*.75)*d.xy;o.xz=spin(k*1.7)*o.xz;d.xz=spin(k*1.7)*d.xz;size=vec3(.14+seed*.07,.19+seed*.18,.15);}
      else{o.yz=spin(.5)*o.yz;d.yz=spin(.5)*d.yz;size=vec3(.27,.38,.17);}
      vec3 n;float s=boxEntry(o,d,size,true,n);
      if(s<min(hit,end)&&s>=begin){hit=s;if(mode==12){n.xz=spin(-k*1.7)*n.xz;n.xy=spin(-(seed-.5)*.75)*n.xy;}else n.yz=spin(-.5)*n.yz;normal=n;}
    }
  }else{
    int count=mode==42?9:3;
    for(int i=0;i<9;i++){if(i>=count)break;vec3 o=ro,d=rd,n;float radius,height;
      if(mode==42){float a=float(i)*.698132;o.xz=spin(a)*o.xz;d.xz=spin(a)*d.xz;o-=vec3(.34,-.12,0);o.xy=spin(-.5)*o.xy;d.xy=spin(-.5)*d.xy;radius=.065;height=.76;}
      else if(i==0){o.xz=spin(.38)*o.xz;d.xz=spin(.38)*d.xz;o-=vec3(0,.01,0);radius=.19;height=1.55;}
      else if(i==1){o-=vec3(.23,-.23,.08);o.xy=spin(.35)*o.xy;d.xy=spin(.35)*d.xy;radius=.105;height=.88;}
      else{o-=vec3(-.17,-.30,-.12);o.yz=spin(-.25)*o.yz;d.yz=spin(-.25)*d.yz;radius=.10;height=.70;}
      float s=prismEntry(o,d,radius,height,n);
      if(s<min(hit,end)&&s>=begin){hit=s;
        if(mode==42){n.xy=spin(.5)*n.xy;n.xz=spin(-float(i)*.698132)*n.xz;}
        else if(i==0)n.xz=spin(-.38)*n.xz;else if(i==1)n.xy=spin(-.35)*n.xy;else n.yz=spin(.25)*n.yz;normal=n;}
    }
  }
  if(hit>end)return vec4(0);return material(mode,ro+rd*hit,normal,rd,t);
}
vec4 groundImpactSurface(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec2 roots=quadratic(-.015*dot(rd.xz,rd.xz),rd.y-.03*dot(ro.xz,rd.xz),ro.y-.025-.015*dot(ro.xz,ro.xz));
  hit=end+.01;
  for(int i=0;i<2;i++){
    float s=roots[i];if(s<begin||s>min(hit,end))continue;vec3 p=ro+rd*s;float r=length(p.xz);if(r>.85)continue;
    float aa=max(.002,length(fwidth(p.xz))*.4),rings=abs(mod(r+.06,.18)-.09);
    float cracks=abs(sin(atan(p.z,p.x)*8.+noise3(p*15.)*.8))*r*.09;
    if(min(rings-.009,cracks-.006)>aa)continue;hit=s;
  }
  if(hit>end)return vec4(0);vec3 p=ro+rd*hit;return moveMaterial(25,p,normalize(vec3(-p.x*.03,1.,-p.z*.03)),rd,t);
}
vec4 webSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec2 roots=mode==44?quadratic(.54*dot(rd.xy,rd.xy),rd.z+1.08*dot(ro.xy,rd.xy),ro.z-.34+.54*dot(ro.xy,ro.xy)):
      vec2(-ro.z/(abs(rd.z)<1e-8?1e-8:rd.z));
  hit=end+.01;vec3 normal=vec3(0,0,1);
  for(int i=0;i<2;i++){
    float s=roots[i];if(s<begin||s>min(hit,end))continue;vec3 p=ro+rd*s;float r=length(p.xy),a=atan(p.y,p.x);if(r>.87)continue;
    float aa=max(.001,length(fwidth(p.xy))*.5),spokes=abs(sin(a*9.+.025*sin(a*7.)))*r/9.;
    float spiral=abs(mod(r+.015*a+.012*sin(a*5.+r*9.),.095)-.0475);
    if(min(spokes,spiral)>.0026+aa)continue;hit=s;normal=mode==44?normalize(vec3(p.xy*1.08,1.)):vec3(0,0,1);
  }
  if(hit>end)return vec4(0);return material(mode,ro+rd*hit,normal,rd,t);
}
