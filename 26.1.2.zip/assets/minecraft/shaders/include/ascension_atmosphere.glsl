// Restored three-dimensional fire and smoke density, using 32 bounded integration positions.
// Reject empty space before evaluating turbulence and terminate opaque rays immediately.
vec4 livingAtmosphere(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec4 sum=vec4(0);hit=begin;bool touched=false;
  bool smoke=mode==8||mode==19||mode==37,ring=mode==3||mode==7;
  int steps=smoke?20:ring?20:mode==41?24:28;
  float stepSize=(end-begin)/float(steps);
  for(int i=0;i<32;i++){
    if(i>=steps)break;
    float s=begin+(float(i)+.5)*stepSize;vec3 p=ro+rd*s;
    float density=0.,heat=0.;vec3 color=vec3(0);float r=length(p.xz);
    if(smoke){
      if(abs(p.y)>.755||r>.89)continue;
      float nearest=10.;
      for(int k=0;k<5;k++){float a=float(k)*2.39996;vec3 c=vec3(cos(a)*.30,sin(a*3.)*.18,sin(a)*.30);nearest=min(nearest,length(p-c));}
      if(nearest>.575)continue;
      float n=fluidFbm(p*7.-vec3(t*.22,t*.55,0));
      float clouds=1.-smoothstep(.19,.48,nearest+(n-.5)*.19);
      density=clouds*(.12+n*n*2.)*4.5;
      color=mix(vec3(.026,.031,.039),vec3(.31,.33,.35),n*.6+max(0.,p.y)*.25);
      if(mode==19){density*=.5;color*=.56;}if(mode==37)density*=.28;
    }else if(ring){
      // The Gaussian tails here are below one 8-bit color level outside this slab.
      if(abs(p.y-.065)>.30||r<.49||r>.99)continue;
      float angle=atan(p.z,p.x),n=fluidFbm(vec3(angle*3.,r*19.,p.y*15.-t*3.));
      float center=.785+(n-.5)*.07;
      density=exp(-pow((r-center)/.071,2.)-pow((p.y-.065-(n-.5)*.08)/.085,2.))*7.;
      heat=.48+n*.45;color=hotGas(heat);
    }else{
      if(p.y<=-.75||p.y>=.80||r>.78)continue;
      float h=(p.y+.75)/1.55,angle=atan(p.z,p.x);
      float radius=.35+.065*sin(angle*3.+h*5.-t*1.7),width=.23*(1.-h)+.025;
      if(mode!=41&&abs(r-radius)>width+.08)continue;
      vec3 flow=p*vec3(5.,3.,5.)-vec3(0,t*2.5,0);
      float billow=fluidFbm(flow+vec3(mode==41?0.:fluidNoise(flow*.6)*2.8,0,0)),wisps=fluidNoise(flow*5.3+vec3(0,-t*2.,0));
      float envelope=mode==41?1.-smoothstep(.10,.22+.25*h+(billow-.5)*.16,r):1.-smoothstep(width*.35,width,abs(r-radius)+(billow-.5)*.16);
      density=envelope*smoothstep(0.,.08,h)*(1.-smoothstep(.62+billow*.25,.99,h));
      density*=smoothstep(.29,.62,billow+(.65-h)*.38+(wisps-.5)*.22)*7.;
      heat=clamp(.16+.55*(1.-h)+billow*.28+wisps*.12,0.,1.);color=hotGas(heat);
      if(mode==20)color=mix(vec3(.012,.008,.006),color*.7,pow(clamp(billow*1.5-.4,0.,1.),3.));
      if(mode==41)color=mix(color,vec3(.12,.105,.09),smoothstep(.5,.95,h)*.7);
    }
    float alpha=1.-exp(-density*stepSize);
    if(alpha>.009&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;
    if(sum.a>.985)break;
  }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
vec4 pressureColumn(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec4 sum=vec4(0);hit=begin;bool touched=false;float stepSize=(end-begin)/24.;
  for(int k=0;k<24;k++){
    float s=begin+(float(k)+.5)*stepSize;vec3 p=ro+rd*s;float r=length(p.xz);
    if(abs(p.y)>.85||r>.88)continue;
    float dust=exp(-pow((p.y+.74)/.075,2.))*(1.-smoothstep(.36,.88,r));
    if(r>.37&&dust<.001)continue;
    float flow=fluidFbm(p*vec3(18.,8.,18.)+vec3(0,t*2.1,0));
    float streak=pow(smoothstep(.32,.72,flow),2.),envelope=1.-smoothstep(.27,.37,r);
    float density=envelope*(.16+streak*2.1)*smoothstep(-.85,-.78,p.y)*(1.-smoothstep(.78,.85,p.y))+dust*(.5+flow)*1.8;
    vec3 color=mix(vec3(.30,.40,.42),vec3(.86,.93,.93),flow);color=mix(color,vec3(.38,.30,.20),dust*.6);
    float alpha=1.-exp(-density*stepSize*3.);
    if(alpha>.008&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;if(sum.a>.985)break;
  }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
