// Private glyph corners opt into transitions; ordinary Minecraft text retains its native path.
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
out vec2 codexCanvas;
flat out ivec2 codexOrigin;
flat out ivec2 codexSize;
flat out int codexKind;
flat out int codexTile;
flat out int codexShadow;
flat out int codexStyle;
flat out int codexBirth;
flat out int codexMode;
flat out int codexInk;
flat out int codexTheme;
void codexVertex(bool allowed){
  codexKind=-1;codexTile=0;codexShadow=0;codexStyle=0;codexBirth=0;codexMode=3;codexInk=13;codexTheme=0;
  codexCanvas=vec2(0);codexOrigin=ivec2(0);codexSize=ivec2(1);
  if(!allowed)return;
  ivec3 tint=ivec3(round(Color.rgb*255.));
  bool panelTint=tint.r>=246&&tint.r<=253&&tint.g<=93;
  bool inkTint=tint.r>=128&&tint.r<=191&&tint.g<=93;
  bool shadowTint=((tint.r>=32&&tint.r<=63)&&tint.g<=23||tint.r==63&&tint.g==63)&&tint.b<=63;
  if(!panelTint&&!inkTint&&!shadowTint)return;
  ivec2 size=textureSize(Sampler0,0),p=clamp(ivec2(floor(UV0*vec2(size))),ivec2(0),size-1);
  ivec4 tag=ivec4(round(texelFetch(Sampler0,p,0)*255.));
  if(tag.r<110||tag.r>113||tag.g<40||tag.g>45||tag.a!=255)return;
  int kind=tag.g-40,corner=tag.r-110,tile=tag.b;
  if(kind==5){if(tile<2||tile>32||(!inkTint&&!shadowTint))return;}
  else if(tile<0||tile>=(kind==0?112:56)||(!panelTint&&!shadowTint))return;
  if(kind>0&&kind<5&&tile%4>=kind)return;
  ivec2 dimensions=kind==5?ivec2(tile,32):kind==0?ivec2(160,224):ivec2(kind==1?192:kind==2?150:kind==3?196:158,32);
  ivec2 xy=ivec2(corner&1,(corner>>1)&1),origin=p-xy*(dimensions-1);
  if(any(lessThan(origin,ivec2(0)))||any(greaterThan(origin+dimensions,size)))return;
  for(int i=0;i<4;i++){
    ivec2 c=ivec2(i&1,(i>>1)&1);
    ivec4 marker=ivec4(round(texelFetch(Sampler0,origin+c*(dimensions-1),0)*255.));
    if(any(notEqual(marker,ivec4(110+i,40+kind,tile,255))))return;
  }
  codexKind=kind;codexTile=kind==0?tile%8:kind==5?tile:tile%4;codexTheme=kind==0?tile/8:kind==5?0:tile/4;codexShadow=shadowTint?1:0;codexBirth=tint.g*256+tint.b;
  if(!shadowTint){
    codexMode=kind==5?(tint.r-128)/16:(253-tint.r)/2;
    codexStyle=kind==5?0:(253-tint.r)%2;
    codexInk=kind==5?(tint.r-128)%16:13;
  }
  codexOrigin=origin;codexSize=dimensions;codexCanvas=vec2(xy);
}
vec3 codexOffset(){
  if(codexKind<=0||codexMode==3||codexShadow!=0)return vec3(0);
  float elapsed=mod(GameTime*24000.-float(codexBirth)+24000.,24000.);
  if(elapsed>23980.)elapsed=0.;
  float p=smoothstep(.04,.38,elapsed/20.);
  float direction=codexMode==1?-1.:1.;
  return codexMode==2?vec3(0.,(1.-p)*4.,0.):vec3(direction*(1.-p)*5.,0.,0.);
}
