// Analytic capsule intersections: each strand is tested once per pixel, not at every SDF step.
void takeLine(vec3 ro,vec3 rd,vec3 a,vec3 b,float radius,inout float hit,inout vec3 normal){
  vec3 ba=b-a,oa=ro-a;float bb=dot(ba,ba),bd=dot(ba,rd),bo=dot(ba,oa);
  float A=bb-bd*bd,B=bb*dot(rd,oa)-bo*bd,C=bb*dot(oa,oa)-bo*bo-radius*radius*bb;
  float h=B*B-A*C,s=1e5;
  if(h>=0.&&A>1e-8){float x=(-B-sqrt(h))/A,y=bo+x*bd;if(x>0.&&y>0.&&y<bb)s=x;}
  vec2 span;
  if(raySphereSpan(ro,rd,a,radius,span)&&span.x>0.)s=min(s,span.x);
  if(raySphereSpan(ro,rd,b,radius,span)&&span.x>0.)s=min(s,span.x);
  if(s<hit){hit=s;vec3 p=ro+rd*s;normal=normalize(p-a-ba*clamp(dot(p-a,ba)/max(bb,1e-8),0.,1.));}
}
bool lineMode(int m){return m==6||m==11||m==13||m==24||m==26||m==28||m==30||m==31||m==33||m==34||m==35||m==38||m==39||m==40||m==45||m==46||m==47||m==50||m==51||m==54;}
vec4 lineScene(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 n=vec3(0,1,0);
  if(mode==11||mode==45){
    int strands=mode==45?3:1;
    for(int i=0;i<3;i++){if(i>=strands)break;vec3 last=vec3(0,0,-.77);
      for(int j=1;j<=12;j++){float z=-.77+float(j)*1.54/12.;vec3 next=mode==45?vec3(cos(z*24.+float(i)*2.094395)*.018,sin(z*24.+float(i)*2.094395)*.018,z):vec3(.014*sin(z*9.-t*3.),.012*cos(z*11.),z);
        takeLine(ro,rd,last,next,mode==45?.0035:.007,hit,n);last=next;}}
  }else if(mode==13){
    float flash=floor(t*10.);
    for(int i=0;i<14;i++){float k=float(i);vec3 v=boltPoint(k,flash),w=boltPoint(k+1.,flash);takeLine(ro,rd,v,w,.008,hit,n);
      if(i==3||i==6||i==9){vec3 start=v;float side=i==6?-1.:1.;
        for(int j=1;j<5;j++){float f=float(j);vec3 tip=v+vec3(side*(f*.105+.025*sin(f*8.+k)),-f*.092,sin(k+f)*.07);takeLine(ro,rd,start,tip,.0045-f*.00065,hit,n);start=tip;}}}
  }else if(mode==33||mode==46){
    bool crown=mode==46;int count=crown?8:5;float flash=floor(t*8.);
    for(int i=0;i<8;i++){if(i>=count)break;float k=float(i),a=k*6.283185/float(count);vec3 last=vec3(cos(a)*.43,-.55,sin(a)*.43);
      for(int j=1;j<7;j++){float f=float(j)/6.,seed=hash31(vec3(k,float(j),flash));float radius=(crown?.25+.40*sin(f*3.14159):.40+.10*sin(f*3.14159))+(seed-.5)*.13;
        vec3 next=vec3(cos(a+(seed-.5)*.65)*radius,-.55+f*(crown?1.38:1.02),sin(a+(seed-.5)*.65)*radius);
        takeLine(ro,rd,last,next,crown?.007:.006,hit,n);
        if(j==3||crown&&j==4)takeLine(ro,rd,next,next+vec3(cos(a+.6)*.18,.10,sin(a+.6)*.18),.003,hit,n);last=next;}}
  }else if(mode==24||mode==47){
    float flash=floor(t*6.);
    for(int i=0;i<9;i++){float a=float(i)*6.283185/9.;vec3 last=vec3(0,.018,0);
      for(int j=1;j<5;j++){float r=float(j)*.205,angle=a+(hash31(vec3(i,j,flash))-.5)*.17;vec3 next=vec3(cos(angle)*r,.018,sin(angle)*r);
        takeLine(ro,rd,last,next,.005,hit,n);
        if(j==3)takeLine(ro,rd,next,next+vec3(cos(a+.6)*.15,.02,sin(a+.6)*.15),.003,hit,n);
        if(mode==47&&j==4&&i%3==0){vec3 lead=next;
          for(int k=1;k<=5;k++){float u=float(k)/5.,jitter=hash31(vec3(float(i),float(k),flash+3.))-.5;vec3 tip=next*(1.-u*.30)+vec3(cos(a+.8)*jitter*.19,u*.70,sin(a+.8)*jitter*.19);
            takeLine(ro,rd,lead,tip,.006,hit,n);if(k==3)takeLine(ro,rd,tip,tip+vec3(cos(a+.6)*.13,.13,sin(a+.6)*.13),.003,hit,n);lead=tip;}}
        last=next;}}
  }else if(mode==28||mode==54){
    bool singular=mode==54;int count=singular?8:6;
    for(int i=0;i<8;i++){if(i>=count)break;float a=float(i)*6.283185/float(count);vec3 last=vec3(0,-.72,0);
      for(int j=1;j<10;j++){float f=float(j)/9.,radius=sin(f*3.141593)*(singular?.70:.58),angle=a+(singular?sin(f*6.28318)*.45:0.);vec3 next=vec3(cos(angle)*radius,-.72+1.44*f,sin(angle)*radius);
        takeLine(ro,rd,last,next,singular?.006:.007,hit,n);last=next;}}
    takeLine(ro,rd,vec3(0),vec3(0,.001,0),singular?.20:.10,hit,n);
  }else if(mode==35||mode==51){
    for(int plane=0;plane<3;plane++){
      float a=mode==51?float(plane)*1.047197:0.,phase=mode==51?float(plane)*2.1:plane==0?0.:plane==1?1.8:-1.8;
      float offset=mode==35?(plane==0?0.:plane==1?.32:-.32):0.;
      for(int i=0;i<18;i++){float x=-.78+float(i)*.0867,z=x+.0867;vec3 v=vec3(x,sin(x*14.-t*7.+phase)*.115+offset,0),w=vec3(z,sin(z*14.-t*7.+phase)*.115+offset,0);
        v.xz=spin(-a)*v.xz;w.xz=spin(-a)*w.xz;takeLine(ro,rd,v,w,.008,hit,n);}}
  }else if(mode==50){
    for(int side=-1;side<=1;side+=2){vec3 last=vec3(0,-.78,0);
      for(int i=1;i<16;i++){float y=-.78+float(i)*.104,angle=y*7.+float(side)*1.5708,width=.28*(1.-abs(y)*.4);vec3 next=vec3(cos(angle)*width,y,sin(angle)*width);takeLine(ro,rd,last,next,.012,hit,n);last=next;}}
    for(int i=0;i<24;i++){float a=float(i)*6.283185/24.,b=float(i+1)*6.283185/24.;takeLine(ro,rd,vec3(cos(a)*.52,sin(a)*.67,0),vec3(cos(b)*.52,sin(b)*.67,0),.006,hit,n);}
  }else if(mode==31){
    for(int i=0;i<12;i++){float a=float(i)*.523599;vec3 v=vec3(.21,.02,.006),w=vec3(.84,.05,.006);v.xy=spin(-a)*v.xy;w.xy=spin(-a)*w.xy;takeLine(ro,rd,v,w,.0018,hit,n);vec3 c=vec3(.59,.039,.006);c.xy=spin(-a)*c.xy;takeLine(ro,rd,c,c+vec3(0,.001,0),.008,hit,n);}
  }else if(mode==38){
    for(int pole=-1;pole<=1;pole+=2)for(int i=0;i<4;i++){float a=float(i)*1.570796;vec3 v=vec3(.18,float(pole)*.62,0),w=vec3(.29,float(pole)*.48,.025),z=vec3(.20,float(pole)*.27,0);v.xz=spin(-a)*v.xz;w.xz=spin(-a)*w.xz;z.xz=spin(-a)*z.xz;takeLine(ro,rd,v,w,.003,hit,n);takeLine(ro,rd,w,z,.003,hit,n);}
  }else if(mode==26){
    for(int plane=0;plane<2;plane++){float a=float(plane)*1.570796;takeLine(ro,rd,vec3(0,-.65,0),vec3(0,.65,0),.014,hit,n);
      for(int side=-1;side<=1;side+=2)for(int j=0;j<3;j++){float y=float(j)*.35-.4;vec3 v=vec3(0,y,0),w=vec3(float(side)*(.30+float(j)*.05),y+.21,.025);w.xz=spin(-a)*w.xz;takeLine(ro,rd,v,w,.009,hit,n);takeLine(ro,rd,w,w+vec3(0,.001,0),.035,hit,n);}}
  }else if(mode==40){
    for(int face=-1;face<=1;face+=2){float z=float(face)*.31;vec3 v0=vec3(-.82,.62,z),v1=vec3(-.43,.37,z),v2=vec3(-.14,.48,z),v3=vec3(.19,.05,z),v4=vec3(.82,-.14,z);
      takeLine(ro,rd,v0,v1,.0035,hit,n);takeLine(ro,rd,v1,v2,.0035,hit,n);takeLine(ro,rd,v2,v3,.0035,hit,n);takeLine(ro,rd,v3,v4,.0035,hit,n);
      vec3 b1=vec3(-.33,-.06,z),b2=vec3(-.51,-.42,z),b3=vec3(-.26,-.81,z),c1=vec3(.34,.40,z),c2=vec3(.24,.83,z);
      takeLine(ro,rd,v1,b1,.003,hit,n);takeLine(ro,rd,b1,b2,.003,hit,n);takeLine(ro,rd,b2,b3,.003,hit,n);takeLine(ro,rd,v3,c1,.0025,hit,n);takeLine(ro,rd,c1,c2,.0025,hit,n);takeLine(ro,rd,b2,vec3(-.80,-.36,z),.002,hit,n);}
    for(int i=0;i<7;i++){vec3 c=vec3((float(i)-3.)*.24,-.85,.34);takeLine(ro,rd,c,c+vec3(0,.04,0),.035,hit,n);}
  }else{
    int count=mode==39?22:mode==34?11:mode==30?18:7;
    for(int i=0;i<22;i++){if(i>=count)break;float k=float(i),seed=hash31(vec3(k,4,7)),a=k*2.39996;vec3 c;float radius;
      if(mode==39){seed=hash31(vec3(k,8,6));a+=t*.26;c=vec3(cos(a)*(.36+seed*.34),sin(k*3.)*.25,sin(a)*(.36+seed*.34));radius=.007;}
      else if(mode==34){a+=t*.5;c=vec3(cos(a)*.48,sin(k*7.)*.58,sin(a)*.27);radius=.022;}
      else{c=vec3(cos(a)*(.32+seed*.25),fract(t*.48+seed)*1.48-.74,sin(a)*(.32+seed*.25));radius=.018+seed*.018;}
      takeLine(ro,rd,c,c+vec3(0,.012,0),radius,hit,n);}
  }
  if(hit>end||hit<begin)return vec4(0);
  return material(mode,ro+rd*hit,n,rd,t);
}
