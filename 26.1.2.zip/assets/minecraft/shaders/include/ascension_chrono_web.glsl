// Fixed-cost analytic layers. No volumetric marching or nested noise loops.
float cwRing(float r,float at,float width){return exp(-abs(r-at)/width);}
float cwSilk(vec2 q,float phase){
 float r=length(q),a=atan(q.y,q.x);
 float spokes=exp(-abs(sin(a*8.))*max(r,.05)*85.);
 float scallop=r*(1.+.045*cos(a*16.));
 float strands=exp(-abs(sin(scallop*32.+phase))*38.);
 return max(spokes,strands)*smoothstep(.06,.15,r)*(1.-smoothstep(.88,.98,r));
}
vec4 chronoWebSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
 hit=end+.01;vec4 sum=vec4(0);vec2 span;
 if(mode==91||mode==97){
  if(abs(rd.y)<1e-6)return sum;
  float s=-ro.y/rd.y;if(s<begin||s>end)return sum;
  vec3 p=ro+rd*s;float r=length(p.xz),a=atan(p.z,p.x);if(r>.98)return sum;
  hit=s;
  if(mode==97){float burst=cwRing(r, min(.92,t*.85+.08),.028);float web=cwSilk(p.xz,0.);return vec4(vec3(.60,.82,1.)+burst*.6,(web*.8+burst)*max(0.,1.-t*.65));}
  float outer=cwRing(r,.91,.004)+cwRing(r,.86,.003),inner=cwRing(r,.64,.004)+cwRing(r,.38,.005);
  float ticks=exp(-abs(sin(a*30.))*60.)*smoothstep(.87,.885,r)*(1.-smoothstep(.94,.95,r));
  float gear=exp(-abs(r-(.72+.018*sign(cos(a*24.+t*2.))))/.006);
  float slots=pow(max(0.,cos(a*12.-t*3.)),28.)*cwRing(r,.49,.026);
  float flow=cwRing(r,.23,.008)*(.4+.6*pow(max(0.,cos(a*3.+t*5.)),6.));
  float ink=max(max(outer,inner),max(ticks,max(gear,max(slots,flow))));
  return vec4(mix(vec3(.18,.74,1.),vec3(1.25,.86,.30),smoothstep(.68,.80,r)),min(.95,ink));
 }
 if(mode==94){
  // Six rigid body parts, instead of a reused clock or an expensive entity clone.
  float nearest=end+.01;vec3 normal=vec3(0),best=vec3(0);bool found=false;
  for(int k=0;k<6;k++){
   vec3 center=k==0?vec3(0,.62,0):k==1?vec3(0,.08,0):k==2?vec3(-.48,.02,0):k==3?vec3(.48,.02,0):k==4?vec3(-.20,-.57,0):vec3(.20,-.57,0);
   vec3 size=k==0?vec3(.27,.25,.27):k==1?vec3(.33,.30,.19):k<4?vec3(.13,.32,.16):vec3(.15,.35,.17);
   float s;vec3 n;if(revisionBox(ro-center,rd,size,begin,end,s,n)&&s<nearest){nearest=s;normal=n;best=ro+rd*s;found=true;}
  }
  if(!found)return sum;hit=nearest;
  float rim=pow(1.-abs(dot(normal,rd)),2.),scan=.5+.5*cos(best.y*95.);
  return vec4(vec3(.25,.70,1.)+rim*.5,(.10+rim*.5+scan*.05)*max(0.,1.-t));
 }
 if(mode==92){
  // Panoramic celestial canopy. One analytic dome intersection and sparse stars.
  if(!raySphereSpan(ro,rd,vec3(0),.96,span))return sum;
  float s=span.x>=begin?span.x:span.y;if(s<begin||s>end)return sum;
  vec3 p=ro+rd*s;if(p.y<-.25)return sum;hit=s;
  vec3 n=normalize(p);float phase=t*7.8539816;vec3 sun=normalize(vec3(cos(phase),sin(phase),.26));
  float daylight=smoothstep(-.25,.35,sun.y),disc=exp(-pow(length(n-sun)/.045,2.));
  float halo=exp(-length(n-sun)*13.),moon=exp(-pow(length(n+sun)/.034,2.));
  vec3 cell=floor(n*190.);float star=step(.994,hash31(cell))*pow(max(0.,1.-length(fract(n*190.)-.5)*1.6),3.);
  float longitude=atan(n.z,n.x),latitude=asin(n.y);
  float trails=pow(max(0.,cos(longitude*90.-phase*2.)),85.)*pow(max(0.,1.-abs(n.y-.45)),10.);
  float orbit=exp(-abs(latitude-(.25+.10*sin(longitude*3.-phase)))*160.);
  float galaxy=exp(-pow((latitude-.40-.13*sin(longitude*2.+phase*.4))/.12,2.));
  float dust=noise3(n*70.+vec3(0,phase*.6,0));
  star=step(.978,hash31(cell))*pow(max(0.,1.-length(fract(n*190.)-.5)*1.6),3.);
  vec3 sky=mix(vec3(.012,.018,.065),vec3(.11,.39,.61),daylight);
  sky+=mix(vec3(.17,.18,.38),vec3(.78,.52,.23),daylight)*galaxy*(.3+dust*.7)+vec3(.39,.65,1.)*orbit*.22;
  sky+=vec3(1.35,.89,.37)*(disc+halo*.35)+vec3(.65,.82,1.)*(moon+(star+trails*.18)*(1.-daylight*.65));
  return vec4(sky,.28+disc*.7+moon*.55+star*.5);
 }
 if(mode==95||mode==96){
  if(!raySphereSpan(ro,rd,vec3(0),.94,span))return sum;
  float s=span.x>=begin?span.x:span.y;if(s<begin||s>end)return sum;
  vec3 p=ro+rd*s;hit=s;
  vec2 uv=mode==96?p.xz:p.xy;float silk=cwSilk(uv,mode==95?sin(t*3.)*.15:0.);
  float rim=pow(1.-abs(dot(normalize(p),rd)),4.);
  float flash=mode==96?.6+.4*pow(max(0.,cos(length(uv)*23.-t)),8.):1.;
  return vec4(mix(vec3(.24,.38,.48),vec3(.85,.95,1.),silk),min(.93,silk*.9*flash+rim*.035));
 }
 // Universe Reset: decelerating orbital bands, frozen fractures and a contracting firmament.
 float elapsed=min(t,4.),v=elapsed-elapsed*elapsed*elapsed/16.+elapsed*elapsed*elapsed*elapsed/128.;
 float stopped=smoothstep(3.75,4.,t),collapse=smoothstep(0.,4.,t);
 if(raySphereSpan(ro,rd,vec3(0),.94,span)){
  float s=span.x>=begin?span.x:span.y;if(s>=begin&&s<=end){
   vec3 p=ro+rd*s,n=normalize(p);hit=s;
   vec3 q=p;q.xz=spin(v*.3)*q.xz;
   float crack=revisionCrack(vec3(q.xy*4.+q.z,7.));
   float rim=pow(1.-abs(dot(n,rd)),3.);
   float latitude=exp(-abs(sin((p.y+sin(atan(p.z,p.x)*5.+v)*.03)*23.))*65.);
   vec3 stars=q*110.;float speck=step(.985,hash31(floor(stars)))*pow(max(0.,1.-length(fract(stars)-.5)*1.4),3.);
   float streams=pow(max(0.,cos(atan(q.y,q.x)*37.-length(q.xy)*55.+v*7.)),45.);
   float dust=exp(-pow((q.y-.23*sin(q.x*5.))/.18,2.))*noise3(q*30.);
   sum=vec4(mix(vec3(.035,.08,.18),vec3(.77,.91,1.),crack),.018+crack*(.12+stopped*.14)+rim*.16+latitude*.15+speck*.5+streams*.08);
   sum.rgb+=vec3(.25,.30,.65)*dust+vec3(.76,.88,1.)*speck;
  }
 }
 for(int shard=0;shard<8;shard++){
  float a=float(shard)*2.399963-v*.12;vec3 n=vec3(cos(a),0,sin(a)),right=vec3(-n.z,0,n.x);
  vec3 center=n*(.68-collapse*.22)+vec3(0,sin(float(shard)*3.7)*.55,0);
  float den=dot(rd,n);if(abs(den)<1e-5)continue;float s=dot(center-ro,n)/den;if(s<begin||s>end)continue;
  vec3 p=ro+rd*s-center;vec2 q=vec2(dot(p,right),p.y);
  float shape=max(abs(q.x)*1.3+abs(q.y)*.5-.12,max(abs(q.y)-.19,-q.x-q.y*.6-.09));if(shape>0.)continue;
  float edge=exp(shape*170.);hit=min(hit,s);sum=solarOver(sum,vec4(vec3(.38,.62,1.)+edge*.65,.07+edge*.65));
 }
 for(int k=0;k<3;k++){
  vec3 n=normalize(k==0?vec3(0,1,.25):k==1?vec3(.7,.5,.3):vec3(-.5,.6,.6));
  float den=dot(rd,n);if(abs(den)<1e-5)continue;float s=-dot(ro,n)/den;if(s<begin||s>end)continue;
  vec3 p=ro+rd*s;float r=length(p),a=atan(p.z,p.x);
  float radius=.87-float(k)*.15-collapse*.07;
  float band=cwRing(r,radius,.007),splinters=pow(max(0.,cos(a*24.-v*4.+float(k))),30.)*cwRing(r,radius-.05,.025);
  float alpha=(band*.8+splinters*.6);if(alpha>.005){hit=min(hit,s);sum=solarOver(sum,vec4(mix(vec3(.27,.53,1.),vec3(1.3,.93,.52),stopped),alpha));}
 }
 return sum;
}
