// Articulated liquid creature parts. Analytic primitives keep the silhouette independent of noise.
float creatureEllipsoid(vec3 ro,vec3 rd,vec3 center,vec3 radii,out vec3 normal){
  vec3 o=(ro-center)/radii,d=rd/radii;float factor=length(d);vec2 span;
  if(!raySphereSpan(o,d/factor,vec3(0),1.,span))return 1e5;
  float s=(span.x>0.?span.x:span.y)/factor;
  normal=normalize((ro+rd*s-center)/(radii*radii));return s;
}
float creatureCapsule(vec3 ro,vec3 rd,vec3 a,vec3 b,float radius,out vec3 normal){
  vec3 axis=normalize(b-a),o=ro-a,d=rd-axis*dot(rd,axis),q=o-axis*dot(o,axis);float h=length(b-a),best=1e5;
  vec2 roots=quadratic(dot(d,d),2.*dot(q,d),dot(q,q)-radius*radius),span;
  for(int i=0;i<2;i++){float s=roots[i],y=dot(ro+rd*s-a,axis);if(s>0.&&y>=0.&&y<=h)best=min(best,s);}
  if(raySphereSpan(ro,rd,a,radius,span)&&span.x>0.)best=min(best,span.x);
  if(raySphereSpan(ro,rd,b,radius,span)&&span.x>0.)best=min(best,span.x);
  vec3 p=ro+rd*best;normal=normalize(p-a-axis*clamp(dot(p-a,axis),0.,h));return best;
}
bool creatureClip(vec3 ro,vec3 rd,vec3 n,float offset,inout float enter,inout float leave,inout vec3 normal){
  float d=dot(n,rd),gap=offset-dot(n,ro);if(abs(d)<1e-7)return gap>=0.;float s=gap/d;
  if(d<0.){if(s>enter){enter=s;normal=normalize(n);}}else leave=min(leave,s);return leave>=enter;
}
float creatureFin(vec3 ro,vec3 rd,out vec3 normal){
  float nearT=0.,farT=1e5;normal=vec3(1,0,0);
  if(!creatureClip(ro,rd,vec3(1,0,0),.045,nearT,farT,normal)||!creatureClip(ro,rd,vec3(-1,0,0),.045,nearT,farT,normal))return 1e5;
  if(!creatureClip(ro,rd,vec3(0,-1,0),-.22,nearT,farT,normal))return 1e5;
  if(!creatureClip(ro,rd,vec3(0,1,1.35),.64,nearT,farT,normal)||!creatureClip(ro,rd,vec3(0,1,-1.),1.12,nearT,farT,normal))return 1e5;
  return nearT>0.?nearT:farT;
}
vec3 liquidLight(vec3 p,vec3 n,vec3 ray,float t){
  float flow=fbm(p*12.+vec3(0,t*.45,-t*.8)),fine=noise3(p*105.);
  float caustic=pow(1.-abs(2.*fbm(p*23.+vec3(t*.2,0,0))-1.),14.);
  float rim=pow(1.-abs(dot(n,ray)),3.),spec=pow(max(0.,dot(reflect(ray,n),normalize(vec3(-.4,.8,-.5)))),48.);
  return mix(vec3(.012,.095,.19),vec3(.055,.46,.63),flow)+vec3(.55,.94,1.)*(caustic*.45+spec*.85+rim*.4+pow(fine,12.)*.2);
}
vec4 leviathanSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+1.;vec3 normal=vec3(0,1,0),candidateNormal;int part=0;
  float s=creatureEllipsoid(ro,rd,mode==59?vec3(0,.07,-.25):vec3(0),mode==59?vec3(.62,.49,.57):vec3(.75,.55,.97),candidateNormal);
  if(s>=begin&&s<hit){hit=s;normal=candidateNormal;}
  if(mode==59){
    // Snout, open lower jaw and a luminous pair of eyes form a readable head from both sides.
    for(int j=0;j<2;j++){
      vec3 center=j==0?vec3(0,.01,.43):vec3(0,-.34,.43),halfSize=j==0?vec3(.43,.18,.46):vec3(.36,.10,.42);
      float boxHit;vec3 boxNormal;
      if(revisionBox(ro-center,rd,halfSize,begin,end,boxHit,boxNormal)&&boxHit<hit){hit=boxHit;normal=boxNormal;}
    }
    for(int side=-1;side<=1;side+=2){
      float signSide=float(side);
      s=creatureCapsule(ro,rd,vec3(signSide*.42,.40,-.3),vec3(signSide*.75,.75,-.75),.045,candidateNormal);
      if(s>=begin&&s<hit){hit=s;normal=candidateNormal;part=1;}
      s=creatureCapsule(ro,rd,vec3(signSide*.28,-.04,.78),vec3(signSide*.88,-.15,.94),.016,candidateNormal);
      if(s>=begin&&s<hit){hit=s;normal=candidateNormal;part=1;}
      s=creatureEllipsoid(ro,rd,vec3(signSide*.50,.17,.25),vec3(.075,.075,.10),candidateNormal);
      if(s>=begin&&s<hit){hit=s;normal=candidateNormal;part=2;}
      for(int tooth=0;tooth<3;tooth++){
        float boxHit;vec3 boxNormal,center=vec3(signSide*.28,-.21,.25+float(tooth)*.23);
        if(revisionBox(ro-center,rd,vec3(.025,.07,.035),begin,end,boxHit,boxNormal)&&boxHit<hit){hit=boxHit;normal=boxNormal;part=1;}
      }
    }
  }
  s=creatureFin(ro,rd,candidateNormal);if(s>=begin&&s<hit){hit=s;normal=candidateNormal;part=1;}
  if(hit>end)return vec4(0);vec3 p=ro+rd*hit;
  if(part==2){float pupil=1.-smoothstep(.006,.018,abs(abs(p.x)-.53));return vec4(mix(vec3(1.,.88,.45),vec3(.005,.03,.04),pupil),1.);}
  vec3 color=liquidLight(p,normal,rd,t);if(part==1)color+=vec3(.18,.42,.50);
  return vec4(color,.78+pow(1.-abs(dot(normal,rd)),3.)*.2);
}
