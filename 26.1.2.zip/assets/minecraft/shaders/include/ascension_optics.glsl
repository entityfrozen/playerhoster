// Reference notes and intentional approximations: docs/VISUAL-REFERENCES.md.
float hash31(vec3 p){p=fract(p*.1031);p+=dot(p,p.yzx+33.33);return fract((p.x+p.y)*p.z);}
float proceduralNoise3(vec3 p){
  vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
  return mix(mix(mix(hash31(i),hash31(i+vec3(1,0,0)),f.x),mix(hash31(i+vec3(0,1,0)),hash31(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(hash31(i+vec3(0,0,1)),hash31(i+vec3(1,0,1)),f.x),mix(hash31(i+vec3(0,1,1)),hash31(i+vec3(1,1,1)),f.x),f.y),f.z);
}
// Shared 16-bit hash lattice: four fetches replace eight hash evaluations per noise call.
// The atlas contains mathematical noise only; shape, timing and movement remain live.
vec2 fieldHashPair(vec4 v){return (v.rb*256.+v.ga)/257.;}
vec4 fieldCorners(ivec3 cell){
  int index=2*((cell.z*80+cell.y)*80+cell.x),row=arcCarrier.y==9?16:272;
  ivec2 uv=arcNoiseBase+ivec2(index&1023,row+(index>>10));
  return vec4(fieldHashPair(texelFetch(Sampler0,uv,0)),fieldHashPair(texelFetch(Sampler0,uv+ivec2(1,0),0)));
}
float fluidNoise(vec3 p){
    vec3 wrapped=mod(floor(p)+40.,80.);ivec3 a=ivec3(wrapped),b=ivec3(mod(wrapped+1.,80.));
    vec3 f=fract(p);f=f*f*(3.-2.*f);vec4 lo,hi;
    if(arcNoiseBase.x>=0){lo=fieldCorners(a);hi=fieldCorners(ivec3(a.xy,b.z));}
    else{
      vec3 x=vec3(a-40),y=vec3(b-40);
      lo=vec4(hash31(x),hash31(vec3(y.x,x.yz)),hash31(vec3(x.x,y.y,x.z)),hash31(vec3(y.xy,x.z)));
      hi=vec4(hash31(vec3(x.xy,y.z)),hash31(vec3(y.x,x.y,y.z)),hash31(vec3(x.x,y.yz)),hash31(y));
    }
    return mix(mix(mix(lo.x,lo.y,f.x),mix(lo.z,lo.w,f.x),f.y),mix(mix(hi.x,hi.y,f.x),mix(hi.z,hi.w,f.x),f.y),f.z);
}
float fluidFbm(vec3 p){return fluidNoise(p)*.57+fluidNoise(p*2.07+17.3)*.28+fluidNoise(p*4.13-9.1)*.15;}
float noise3(vec3 p){
  ivec3 cell=ivec3(floor(p));
  if(arcNoiseBase.x<0||any(lessThan(cell,ivec3(-40)))||any(greaterThanEqual(cell,ivec3(39))))return proceduralNoise3(p);
  vec3 f=fract(p);f=f*f*(3.-2.*f);cell+=40;
  vec4 lo=fieldCorners(cell),hi=fieldCorners(cell+ivec3(0,0,1));
  return mix(mix(mix(lo.x,lo.y,f.x),mix(lo.z,lo.w,f.x),f.y),mix(mix(hi.x,hi.y,f.x),mix(hi.z,hi.w,f.x),f.y),f.z);
}
float fbm(vec3 p){return noise3(p)*.57+noise3(p*2.07+17.3)*.28+noise3(p*4.13-9.1)*.15;}
vec3 hotGas(float heat){
  vec3 c=mix(vec3(.20,.012,.001),vec3(1.,.22,.012),smoothstep(.05,.48,heat));
  c=mix(c,vec3(1.,.69,.20),smoothstep(.40,.78,heat));
  return mix(c,vec3(1.,.96,.77),smoothstep(.77,1.,heat));
}
float sphereEntry(vec3 ro,vec3 rd,vec3 center,float radius){
  vec3 o=ro-center;float b=dot(o,rd),h=b*b-dot(o,o)+radius*radius;
  if(h<0.)return 1e5;float v=-b-sqrt(h);return v>0.?v:1e5;
}
float fragmentEntry(vec3 ro,vec3 rd,vec3 center,float radius,float seed,out vec3 normal){
  vec3 o=ro-center,d=rd;o.xz=spin(seed*6.)*o.xz;d.xz=spin(seed*6.)*d.xz;
  float enter=0.,leave=1e5;vec3 face=vec3(0,1,0);
  for(int i=0;i<10;i++){
    vec3 n=i==0?vec3(1,0,0):i==1?vec3(-1,0,0):i==2?vec3(0,1,0):i==3?vec3(0,-1,0):i==4?vec3(0,0,1):i==5?vec3(0,0,-1):
           normalize(vec3(i<8?1.:-1.,i==6||i==9?1.:-1.,.7));
    float extent=radius*(i==2||i==3?.65:i>=6?1.1:1.);
    float den=dot(n,d),offset=extent-dot(n,o);
    if(abs(den)<1e-7){if(offset<0.)return 1e5;continue;}
    float s=offset/den;
    if(den<0.){if(s>enter){enter=s;face=n;}}else leave=min(leave,s);
    if(leave<enter)return 1e5;
  }
  normal=face;normal.xz=spin(-seed*6.)*normal.xz;
  return enter>0.?enter:1e5;
}
vec4 blackHole(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  // A real disk in model space, a shadow, and a view-dependent lensed image of its far side.
  // This bounded image-space lens is an artistic approximation, not a Kerr geodesic solver.
  // A local cutaway preserves first-person sight when the impact surrounds a player.
  bool internalView=length(ro)<.34;
  float shadow=internalView?1e5:sphereEntry(ro,rd,vec3(0),.282);
  float closest=clamp(-dot(ro,rd),begin,end);
  vec3 q=ro+rd*closest;
  float b=length(q),edge=1.-abs(rd.y);
  vec3 right=normalize(cross(vec3(.0001,1.,0),rd));
  vec3 up=normalize(cross(rd,right));
  float az=atan(dot(q,up),dot(q,right));
  float sx=dot(q,right),sy=dot(q,up);
  float lensedRadius=length(vec2(sx/(1.+1.15*exp(-abs(sy)*13.)),sy));
  vec3 lensUv=vec3(cos(az)*4.,sin(az)*4.,lensedRadius*65.);
  float lensNoise=fbm(lensUv-vec3(t*.7,t*.3,0));
  float photon=exp(-pow((b-.300)/.0028,2.));
  float lens=smoothstep(.312,.321,lensedRadius)*(1.-smoothstep(.408,.448,lensedRadius));
  lens*=pow(edge,.65)*(.40+.60*smoothstep(-.20,.3,dot(q,up)));
  float lanes=pow(noise3(lensUv*vec3(.65,.65,3.5)+vec3(0,t*.3,0)),1.8);
  float asym=.68+.32*tanh(dot(q,right)*5.);
  vec3 lensColor=hotGas(.32+.35*lensNoise+.30*lanes);
  float lensAlpha=internalView?0.:clamp(lens*(.35+.40*lensNoise+.25*lanes)+photon*.96,0.,.98);
  lensColor=mix(lensColor,vec3(1.,.85,.48),photon*.8)*asym;
  vec4 sum=vec4(0);hit=1e5;
  // Analytic disk slices avoid marching past a thin disk at shallow viewing angles.
  // A tiny bounded denominator also gives the exactly edge-on view a finite thickness.
  float dy=abs(rd.y)<.012?(rd.y<0.?-.012:.012):rd.y;
  for(int i=0;i<7;i++){
    float y=(.024-float(i)*.008)*(ro.y>=0.?1.:-1.);
    float s=(y-ro.y)/dy;
    if(s<begin||s>end||s>shadow)continue;
    vec3 p=ro+rd*s;float r=length(p.xz);
    if(r<.326||r>.91)continue;
    float angle=atan(p.z,p.x),speed=.58/pow(r+.12,1.5);
    float twist=angle-t*speed+r*8.;
    vec3 uv=vec3(cos(twist)*5.,sin(twist)*5.,r*31.);
    float turbulence=fbm(uv);
    // Differential rotation shears knots into irregular, finely broken lanes.
    float streak=noise3(vec3(r*175.+turbulence*3.,cos(twist)*2.5,sin(twist)*2.5));
    float fine=noise3(uv*vec3(3.,3.,4.));
    float edgeMask=smoothstep(.326,.339,r)*(1.-smoothstep(.87,.91,r));
    float textureDensity=.28+.70*pow(turbulence,1.3)+.38*streak;
    float alpha=edgeMask*textureDensity*(.47-.035*abs(float(i)-3.));
    float heat=clamp(.19+.48*(1.-smoothstep(.34,.90,r))+.19*turbulence+.12*streak+.08*fine,0.,1.);
    vec3 tangent=normalize(vec3(-p.z,0,p.x));
    float boost=clamp(1.+dot(tangent,-rd)*.48,.50,1.48);
    float detail=.55+.58*streak+.24*fine;
    vec3 color=hotGas(heat)*boost*detail;
    if(alpha>.009&&hit>1e4)hit=s;
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;
  }
  // The far-side image is behind the foreground disk, including the lower lens arc.
  if(lensAlpha>.005){hit=min(hit,closest);sum.rgb+=(1.-sum.a)*lensColor*lensAlpha;sum.a+=(1.-sum.a)*lensAlpha;}
  if(shadow<end){hit=min(hit,shadow);sum.a=1.;}
  // Sparse infalling fragments. Dark rocky centers and hot leading edges, not another ring.
  float debrisDepth=1e5;vec3 debrisColor=vec3(0);
  for(int i=0;i<22;i++){
    float k=float(i),seed=hash31(vec3(k,9,3)),cycle=fract(seed+t*(.09+seed*.04));
    float r=.90-cycle*.38,angle=k*2.399963+t*(.42+seed*.95);
    vec3 c=vec3(cos(angle)*r,(seed-.5)*.19,sin(angle)*r);
    float radius=.006+seed*.009;
    // Reject misses against the fragment's enclosing sphere before clipping its ten facets.
    vec3 o=ro-c;float along=dot(o,rd);if(dot(o,o)-along*along>radius*radius*3.)continue;
    vec3 n;float s=fragmentEntry(ro,rd,c,radius,seed,n);
    if(s<debrisDepth){debrisDepth=s;float glow=pow(max(0.,dot(n,normalize(-c))),3.);float rock=noise3((ro+rd*s-c)*500.+k);debrisColor=mix(vec3(.045,.030,.018),vec3(.22,.14,.07),rock)+vec3(1.,.36,.04)*glow*.65;}
  }
  if(debrisDepth<min(shadow,hit)){sum=vec4(debrisColor,1.);hit=debrisDepth;}
  if(hit>1e4){hit=closest;return vec4(0);}
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
vec4 atmosphericVolume(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec4 sum=vec4(0);hit=begin;bool touched=false;
  float stepSize=(end-begin)/24.;
  for(int i=0;i<24;i++){
    float s=begin+(float(i)+.5)*stepSize;vec3 p=ro+rd*s;
    float density=0.,heat=0.;vec3 color=vec3(0);
    if(mode==2||mode==20){
      float h=clamp((p.y+.75)/1.55,0.,1.),r=length(p.xz),angle=atan(p.z,p.x);
      vec3 flow=p*vec3(5.,3.,5.)-vec3(0,t*2.5,0);
      float billow=fbm(flow+vec3(fbm(flow*.6)*2.8,0,0));
      float wisps=noise3(flow*5.3+vec3(0,-t*2.,0));
      float radius=.35+.065*sin(angle*3.+h*5.-t*1.7),width=.23*(1.-h)+.025;
      float envelope=1.-smoothstep(width*.35,width,abs(r-radius)+(billow-.5)*.16);
      density=envelope*smoothstep(0.,.08,h)*(1.-smoothstep(.62+billow*.25,.99,h));
      density*=smoothstep(.29,.62,billow+(.65-h)*.38+(wisps-.5)*.22)*7.;
      heat=clamp(.16+.55*(1.-h)+billow*.28+wisps*.12,0.,1.);
      color=hotGas(heat);
      if(mode==20)color=mix(vec3(.012,.008,.006),hotGas(heat)*.7,pow(clamp(billow*1.5-.4,0.,1.),3.));
    }else if(mode==3){
      float r=length(p.xz),angle=atan(p.z,p.x);
      float n=fbm(vec3(angle*3.,r*19.,p.y*15.-t*3.));
      float center=.785+(n-.5)*.07;
      density=exp(-pow((r-center)/.071,2.)-pow((p.y-.065-(n-.5)*.08)/.085,2.))*7.;
      heat=.48+n*.45;color=hotGas(heat);
    }else if(mode==9){
      float h=clamp((p.y+.82)/1.64,0.,1.);vec3 q=p;
      q.xz-=vec2(sin(h*3.-t*.65),cos(h*4.+t*.5))*.055*h;
      float r=length(q.xz),angle=atan(q.z,q.x),radius=.105+.55*pow(h,1.4);
      radius+=.03*sin(h*12.-t*1.2)+.03*sin(h*21.+t*2.);
      vec3 uv=vec3(cos(angle+h*9.-t*3.)*r*7.,h*9.-t*.7,sin(angle+h*9.-t*3.)*r*7.);
      float cloud=fbm(uv+vec3(noise3(uv*.7)*2.)),detail=noise3(uv*5.1);
      density=(1.-smoothstep(radius*.68,radius+.06,(r+(cloud-.5)*.22+(detail-.5)*.035)))*smoothstep(-.84,-.74,p.y)*(1.-smoothstep(.73,.85,p.y));
      float skirt=exp(-pow((p.y+.73)/.10,2.))*(1.-smoothstep(.43,.72,r));
      density=(density*(.5+cloud*.9)+skirt*.7)*(1.+detail*.35)*5.;
      float light=clamp(.17+cloud*.72+detail*.12+max(0.,-p.x)*.22,0.,1.);
      color=mix(vec3(.12,.10,.085),vec3(.66,.69,.68),light);
      color=mix(vec3(.25,.19,.12),color,smoothstep(-.8,-.25,p.y));
    }else{
      vec3 q=p;float n=fbm(q*7.-vec3(t*.22,t*.55,0));
      float clouds=0.;for(int k=0;k<5;k++){float a=float(k)*2.39996;vec3 c=vec3(cos(a)*.30,sin(a*3.)*.18,sin(a)*.30);clouds=max(clouds,1.-smoothstep(.19,.48,length(q-c)+(n-.5)*.19));}
      density=clouds*(.12+n*n*2.)*4.5;
      color=mix(vec3(.026,.031,.039),vec3(.31,.33,.35),n*.6+max(0.,p.y)*.25);
      if(mode==19){density*=.5;color*=.56;}
    }
    float alpha=1.-exp(-density*stepSize);
    if(alpha>.009&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;
    if(sum.a>.985)break;
  }
  if(mode==9){
    for(int i=0;i<12;i++){
      float k=float(i),seed=hash31(vec3(k,8,2)),phase=fract(seed+t*.19);
      float h=phase*1.1-.73,r=.31+phase*.30,a=k*2.39996-t*(2.3-seed);
      vec3 c=vec3(cos(a)*r,h,sin(a)*r);float radius=.007+seed*.010;
      vec3 n;float s=fragmentEntry(ro,rd,c,radius,seed,n);
      if(s<end){
        vec3 color=vec3(.12,.085,.045)*(.6+.4*max(0.,n.y));
        if(s<hit){sum=vec4(color,1.);hit=s;}else if(sum.a<.95){sum.rgb+=(1.-sum.a)*color;sum.a=1.;}
      }
    }
  }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
