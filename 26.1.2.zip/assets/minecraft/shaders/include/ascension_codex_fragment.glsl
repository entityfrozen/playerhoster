#moj_import <minecraft:globals.glsl>
in vec2 codexCanvas;
flat in ivec2 codexOrigin;
flat in ivec2 codexSize;
flat in int codexKind;
flat in int codexTile;
flat in int codexShadow;
flat in int codexStyle;
flat in int codexBirth;
flat in int codexMode;
flat in int codexInk;
flat in int codexTheme;
const vec3 CODEX_INKS[16]=vec3[16](
  vec3(214,177,255),vec3(143,231,255),vec3(189,161,242),vec3(255,153,86),
  vec3(166,229,207),vec3(198,184,244),vec3(232,231,218),vec3(255,225,122),
  vec3(186,154,246),vec3(255,207,119),vec3(200,156,255),vec3(174,190,218),
  vec3(201,185,255),vec3(216,221,234),vec3(255,117,117),vec3(202,161,245));
vec4 codexRender(){
  vec2 local=codexCanvas;
  float elapsed=mod(GameTime*24000.-float(codexBirth)+24000.,24000.);if(elapsed>23980.)elapsed=0.;
  float age=elapsed/20.,progress=codexMode==3?1.:smoothstep(.04,.38,age);
  float t=GameTime*1200.;
  if(codexKind==5){
    // Metadata lives at the four corners, outside the letter's readable strokes.
    vec2 pixel=vec2(codexOrigin)+local*vec2(codexSize);
    ivec2 point=clamp(ivec2(floor(pixel))-codexOrigin,ivec2(0),codexSize-1);
    if((point.x==0||point.x==codexSize.x-1)&&(point.y==0||point.y==codexSize.y-1))discard;
    float alpha=texture(Sampler0,pixel/vec2(textureSize(Sampler0,0))).a;
    return vec4(CODEX_INKS[codexInk]/255.,alpha*progress*vertexColor.a);
  }
  vec2 uv=codexKind==0?(vec2(float(codexTile%4),float(codexTile/4))+local)/vec2(4,2):vec2((float(codexTile)+local.x)/float(codexKind),local.y);
  vec2 pixel=vec2(codexOrigin)+clamp(local,vec2(.007),vec2(.993))*vec2(codexSize);
  vec4 c=texture(Sampler0,pixel/vec2(textureSize(Sampler0,0)));
  vec3 accent=CODEX_INKS[codexTheme]/255.;
  if(codexKind==0){
    // Universal's dark card treatment: readable interior, animated margins and traveling trim.
    float edge=min(min(uv.x,1.-uv.x),min(uv.y,1.-uv.y));
    float margin=1.-smoothstep(.015,.28,edge);
    float cloud=(.5+.5*sin(uv.x*9.+sin(uv.y*7.+t*.55)))*(.5+.5*sin(uv.y*13.-uv.x*6.-t*.4));
    c.rgb+=accent*(cloud-.35)*(.012+.025*margin);
    float trim=(1.-smoothstep(.004,.014,edge))*smoothstep(.001,.004,edge);
    float chase=pow(max(0.,cos((uv.x+uv.y)*11.-t*.8)),22.);
    c.rgb+=accent*trim*(.10+.30*chase);
    for(int i=0;i<6;i++){
      float k=float(i),life=fract(t*(.05+k*.003)+k*.173);
      vec2 point=vec2(i%2==0?.026:.974,.92-life*.84);
      point.x+=sin(t*.4+k*3.+life*8.)*.009;
      vec2 d=(uv-point)*vec2(370,310);
      float spark=exp(-dot(d,d))*sin(life*3.14159265);
      c.rgb+=accent*spark*.22;
    }
    if(codexMode!=3&&age<.44){
      float p=clamp(age/.44,0.,1.);
      float x=codexMode==1?p:1.-p;
      float sweep=exp(-pow((uv.x-x)/.032,2.))*sin(p*3.14159265);
      c.rgb+=accent*sweep*.065;
    }
    if(codexMode==2)c.a*=smoothstep(0.,.22,age);
  }else{
    float border=1.-smoothstep(.02,.18,min(uv.y,1.-uv.y));
    c.rgb+=accent*.13*pow(max(0.,cos(uv.x*5.-t*.7)),18.)*border;
    if(codexStyle==1)c.rgb+=accent*.08*(border*.65+.15);
    c.a*=progress;
  }
  c.a*=vertexColor.a;
  return c;
}
