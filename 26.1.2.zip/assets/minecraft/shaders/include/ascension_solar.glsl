// Solar anatomy follows NASA/NSO references; Starfall is the explicitly requested pointed fantasy star.
// Every body, tail and impact has its own bounded renderer. No nested scene traversal.
vec4 solarOver(vec4 front,vec4 back){
  float a=front.a+(1.-front.a)*back.a;
  return vec4((front.rgb*front.a+back.rgb*back.a*(1.-front.a))/max(a,.0001),a);
}
float solarTriangle(vec3 ro,vec3 rd,vec3 a,vec3 b,vec3 c,out vec3 normal){
  vec3 e=b-a,f=c-a,h=cross(rd,f);float d=dot(e,h);if(abs(d)<1e-7)return 1e5;
  vec3 s=ro-a;float u=dot(s,h)/d;if(u<0.||u>1.)return 1e5;
  vec3 q=cross(s,e);float v=dot(rd,q)/d;if(v<0.||u+v>1.)return 1e5;
  normal=normalize(cross(e,f));return dot(f,q)/d;
}
// Irregular convection cells; the darker network separates bright upwelling interiors.
vec2 solarGranules(vec2 p){
  vec2 cell=floor(p),f=fract(p);float first=9.,second=9.;
  for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){
    vec2 o=vec2(x,y),seed=vec2(hash31(vec3(cell+o,17)),hash31(vec3(cell+o,43)));
    float d=length(o+seed-f);if(d<first){second=first;first=d;}else second=min(second,d);
  }return vec2(first,second-first);
}
vec3 solarPhotosphere(vec3 p,vec3 ray,float t){
  vec3 n=normalize(p),q=n;q.xz=spin(t*.025)*q.xz;
  vec3 weights=pow(abs(q),vec3(12.));weights/=max(.0001,weights.x+weights.y+weights.z);
  float detail=1.-smoothstep(.4,1.1,length(fwidth(q))*96.);
  vec2 cell=vec2(.5,.12);
  vec3 warp=vec3(fluidNoise(q*7.+vec3(0,t*.025,0)),fluidNoise(q*7.+19.),fluidNoise(q*7.-13.))-.5;
  vec3 surface=q*96.+warp*.55;
  if(detail>.005){cell=vec2(0);
  if(weights.x>.025)cell+=solarGranules(surface.yz)*weights.x;
  if(weights.y>.025)cell+=solarGranules(surface.xz)*weights.y;
  if(weights.z>.025)cell+=solarGranules(surface.xy)*weights.z;
  }
  float network=1.-smoothstep(.018,.095,cell.y);
  float heat=.38+.30*fluidFbm(q*19.+vec3(0,t*.035,0))+.20*(1.-cell.x);
  vec3 color=mix(vec3(.98,.18,.009),vec3(1.24,.75,.22),smoothstep(.35,.85,heat));
  color*=1.-network*.22*detail;
  color+=vec3(.17,.10,.035)*pow(fluidNoise(q*145.),6.)*detail;
  float limb=.48+.52*pow(abs(dot(n,ray)),.32);color*=limb;
  for(int k=0;k<4;k++){
    vec3 site=normalize(k==0?vec3(.55,.30,.8):k==1?vec3(-.7,-.25,.55):k==2?vec3(.5,-.4,-.7):vec3(-.25,.66,-.7));
    vec3 axis=normalize(cross(site,vec3(.03,1.,.08))),up=cross(axis,site);vec3 delta=q-site;
    float angle=atan(dot(delta,up),dot(delta,axis)),d=length(delta);
    float edge=.045+.008*sin(angle*7.)+.004*sin(angle*19.);
    float penumbra=(1.-smoothstep(edge,edge+.036,d))*(.57+.025*cos(angle*87.));
    float umbra=1.-smoothstep(.016,.036,d);
    color*=1.-max(penumbra*.72,umbra*.94);
    float plage=exp(-pow((d-.10)/.025,2.))*.10;color+=vec3(.8,.4,.08)*plage;
  }
  return color;
}
vec4 solarSun(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end;float surface=end+.01;vec4 body=vec4(0),halo=vec4(0),front=vec4(0);vec2 span;
  if(raySphereSpan(ro,rd,vec3(0),.66,span)){
    float s=span.x>=begin?span.x:span.y;
    if(s>=begin&&s<=end){surface=s;hit=s;body=vec4(solarPhotosphere(ro+rd*s,rd,t),1.);}
  }
  float closest=clamp(-dot(ro,rd),begin,end),b=length(ro+rd*closest);
  if(b>.995&&body.a<.01)return vec4(0);
  if(b>.645&&b<.995){
    vec3 q=normalize(ro+rd*closest+vec3(.00001));
    float structure=fluidFbm(q*11.+vec3(0,t*.12,0));
    float strand=pow(fluidNoise(q*vec3(33.,42.,29.)+structure*3.),3.);
    float height=max(0.,b-.66),chromosphere=exp(-height*100.)*.54;
    float corona=exp(-height*(18.+structure*10.))*(.065+structure*.12+strand*.15);
    float edge=1.-smoothstep(.93,.995,b);
    halo=vec4(mix(vec3(1.05,.18,.012),vec3(1.25,.67,.19),strand),min(.80,(chromosphere+corona)*edge));
    if(halo.a>.008)hit=min(hit,closest);
  }
  // Surface-anchored plasma arches are composited in front only when the ray reaches them first.
  vec3 normal;float best=surface;
  for(int k=0;k<6;k++){
    float a=float(k)*2.399963,lat=sin(float(k)*2.3)*.47;
    vec3 radial=normalize(vec3(cos(a),lat,sin(a))),tangent=normalize(cross(radial,vec3(.03,1.,.07)));
    float loopVisibility=1.-smoothstep(.25,.65,abs(dot(radial,rd)));
    if(loopVisibility<.005)continue;
    vec2 loopBounds;
    if(!raySphereSpan(ro,rd,radial*.73,.24,loopBounds)||loopBounds.y<begin||loopBounds.x>min(end,surface))continue;
    vec3 previous=radial*.635-tangent*.13,side=cross(radial,tangent);
    for(int j=1;j<=12;j++){
      float u=float(j)/12.,h=sin(u*ASC_PI)*(.13+.04*sin(t*.55+float(k)));
      vec3 next=radial*(.635+h)+tangent*((u-.5)*.26)+side*sin(u*ASC_PI*2.+t*.2)*sin(u*ASC_PI)*.014;
      float thickness=.005+.007*pow(abs(u*2.-1.),2.);
      float s=creatureCapsule(ro,rd,previous,next,thickness,normal);
      if(s>=begin&&s<min(best,end)){
        vec3 samplePoint=ro+rd*s;
        float heat=.42+.40*fluidNoise(samplePoint*150.-vec3(0,t*.75,0));
        float core=pow(1.-abs(dot(normal,rd)),.6);
        best=s;front=vec4(mix(vec3(1.10,.15,.008),vec3(1.5,.73,.14),heat),loopVisibility*(.30+.45*core));
      }
      previous=next;
    }
  }
  if(front.a>.01)hit=min(hit,best);
  return solarOver(front,solarOver(body,halo));
}
vec4 solarStar(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+1.;vec3 normal=vec3(0,0,1),nn;float phase=t*.12;
  // Ten alternating boundary vertices and front/back apexes form a real three-dimensional star.
  for(int k=0;k<10;k++){
    float a=ASC_PI*.5+float(k)*ASC_PI/5.+phase,b=a+ASC_PI/5.;
    float ra=k%2==0?.91:.37,rb=k%2==0?.37:.91;
    vec3 u=vec3(cos(a)*ra,sin(a)*ra,0),v=vec3(cos(b)*rb,sin(b)*rb,0);
    for(int side=-1;side<=1;side+=2){
      float s=solarTriangle(ro,rd,vec3(0,0,float(side)*.29),u,v,nn);
      if(s>=begin&&s<min(hit,end)){hit=s;normal=nn;}
    }
  }
  float closest=clamp(-dot(ro,rd),begin,end),b=length(ro+rd*closest);
  vec3 haloTint=mix(vec3(.32,.38,1.10),vec3(1.15,.86,.40),exp(-b*b*12.));
  vec4 glow=vec4(haloTint,exp(-b*b*8.)*.24);
  if(hit>end){hit=closest;return glow;}
  vec3 p=ro+rd*hit;vec2 q=spin(phase)*p.xy;float r=length(q);
  float sector=floor(mod(atan(q.y,q.x)-ASC_PI*.5+2.*ASC_PI,2.*ASC_PI)/(ASC_PI/5.));
  float angle=ASC_PI*.5+sector*ASC_PI/5.;
  float ra=mod(sector,2.)<.5?.91:.37,rb=mod(sector,2.)<.5?.37:.91;
  vec2 a=vec2(cos(angle),sin(angle))*ra,bp=vec2(cos(angle+ASC_PI/5.),sin(angle+ASC_PI/5.))*rb;
  vec2 edgeVector=bp-a;float edge=length(q-a-edgeVector*clamp(dot(q-a,edgeVector)/dot(edgeVector,edgeVector),0.,1.));
  float nebula=fluidFbm(vec3(q*10.,p.z*5.+t*.12));
  vec3 cosmic=mix(vec3(.08,.19,.53),vec3(.54,.22,.76),nebula);
  cosmic+=vec3(.12,.47,.60)*pow(fluidNoise(vec3(q*22.+nebula*2.,t*.10)),3.);
  cosmic=mix(cosmic,vec3(1.15,1.03,.72),smoothstep(.008,.045,length(fwidth(p)))*.80);
  vec2 cell=floor(q*38.),f=fract(q*38.)-.5;
  float stars=step(.985,hash31(vec3(cell,31.)))*(exp(-dot(f,f)*210.)+.16*exp(-abs(f.x)*70.-abs(f.y)*10.)+.16*exp(-abs(f.y)*70.-abs(f.x)*10.));
  float core=exp(-r*r*40.),rim=exp(-edge*95.);
  vec3 color=mix(cosmic,vec3(1.35,1.16,.70),rim);
  color=mix(color,vec3(1.55,1.48,1.22),core);
  color+=stars*vec3(.95,1.12,1.35)*(.80+.20*sin(t*3.+hash31(vec3(cell,7.))*6.));
  color+=vec3(.24,.30,.48)*exp(-edge*28.);
  return solarOver(vec4(color,.98),glow);
}
vec4 solarTail(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end;vec4 sum=vec4(0);vec2 bound;
  if(!raySphereSpan(ro,rd,vec3(0),1.,bound))return sum;
  float near=max(begin,bound.x),far=min(end,bound.y),stepSize=(far-near)/16.;
  if(far<near)return sum;bool touched=false;
  for(int k=0;k<16;k++){
    float s=near+(float(k)+.5)*stepSize;vec3 p=ro+rd*s;float h=clamp((p.y+.98)/1.96,0.,1.),r=length(p.xz);
    float width=.08+.70*(1.-h);if(r>width+.04)continue;
    float angle=atan(p.z,p.x),flow=fluidFbm(vec3(p.x*13.,p.y*4.-t*3.,p.z*13.));
    float lanes=pow(.5+.5*sin(angle*5.+p.y*8.-t*7.+flow*6.),5.);
    float d=(1.-smoothstep(width*.18,width,r))*(1.-h)*(.45+lanes*1.4+flow*.4);
    float a=1.-exp(-d*stepSize*10.);vec3 color=mix(mix(vec3(.20,.30,.92),vec3(.84,.42,1.10),flow),vec3(1.45,1.30,.85),pow(1.-r/max(.001,width),3.));
    if(a>.008&&!touched){hit=s;touched=true;}sum=solarOver(sum,vec4(color,a));
  }
  return sum;
}
vec4 solarBurst(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end;vec4 sum=vec4(0);float phase=clamp(t,0.,1.25);vec2 span;
  // A pressure shell, a fractured radial floor blast, then a fading core. Never a growing sun.
  float radius=.15+.62*smoothstep(0.,.42,phase);
  if(mode!=80&&raySphereSpan(ro,rd,vec3(0),radius,span)){
    float s=span.x>=begin?span.x:span.y;
    if(s>=begin&&s<=end){vec3 p=ro+rd*s,n=normalize(p);float edge=pow(1.-abs(dot(n,rd)),4.);
      float breakup=noise3(n*23.+phase*2.);float a=edge*(.35+breakup*.5)*(1.-smoothstep(.32,1.,phase));
      sum=vec4(mode==80?vec3(1.18,.84,.28):vec3(1.,.31,.018),a);hit=s;}
  }
  if(mode==80){
    float closest=clamp(-dot(ro,rd),begin,end),distance=length(ro+rd*closest);
    float width=.12+.48*phase;
    float flash=exp(-distance*distance/(width*width))*(1.-smoothstep(.03,.24,phase));
    if(flash>.005){hit=closest;sum=vec4(1.55,1.43,1.16,flash*.90);}
  }
  if(abs(rd.y)>1e-6){float s=(.015-ro.y)/rd.y;vec3 p=ro+rd*s;float r=length(p.xz),a=atan(p.z,p.x);
    if(s>=begin&&s<=end&&r<.96){float front=exp(-pow((r-(.12+min(phase,.7)))/.025,2.));
      float cracks=pow(max(0.,cos(a*(mode==80?10.:7.)+noise3(p*9.)*2.)),28.)*smoothstep(.12,.25,r)*(1.-smoothstep(.78,.94,r));
      float fade=1.-smoothstep(.45,1.1,phase);vec4 ground=mode==80?vec4(.76,.72,1.35,(front*.25+cracks*.8)*fade):vec4(1.20,.60,.08,(front*.8+cracks*.9)*fade);
      sum=s<hit?solarOver(ground,sum):solarOver(sum,ground);if(ground.a>.008)hit=min(hit,s);}
  }
  float closest=clamp(-dot(ro,rd),begin,end),b=length(ro+rd*closest);
  float flash=exp(-b*b*38.)*(1.-smoothstep(.08,.5,phase));
  sum=solarOver(sum,vec4(1.6,1.4,.9,flash));if(flash>.008)hit=min(hit,closest);
  return sum;
}
vec4 solarSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  if(mode==62||mode==77)return solarSun(ro,rd,t,begin,end,hit);
  if(mode==64)return solarStar(ro,rd,t,begin,end,hit);
  if(mode==81)return solarTail(ro,rd,t,begin,end,hit);
  if(mode==79||mode==80||mode==82)return solarBurst(mode,ro,rd,t,begin,end,hit);
  hit=end;vec2 span;
  if(mode==78){
    float closest=clamp(-dot(ro,rd),begin,end);vec3 p=ro+rd*closest;float b=length(p);
    if(b>.95)return vec4(0);hit=closest;
    float a=atan(p.y,p.x),spikes=pow(abs(cos(a*4.)),24.)*exp(-b*5.);
    return vec4(mix(vec3(1.,.40,.035),vec3(1.5,1.4,.95),exp(-b*14.)),exp(-b*b*35.)+spikes*.7);
  }
  // Solar Flare: compact turbulent plasma knot with a white-hot core and torn chromosphere.
  if(!raySphereSpan(ro,rd,vec3(0),.76,span))return vec4(0);
  hit=span.x>=begin?span.x:span.y;if(hit<begin||hit>end)return vec4(0);
  vec3 p=ro+rd*hit,n=normalize(p);float flow=fbm(n*10.+vec3(0,-t*.9,0));
  float threads=pow(1.-abs(2.*noise3(n*29.+flow*2.-t*.4)-1.),12.);
  float rim=pow(1.-abs(dot(n,rd)),3.);
  return vec4(mix(vec3(1.,.24,.012),vec3(1.3,1.05,.52),flow)+threads*.35,1.-rim*.25);
}
