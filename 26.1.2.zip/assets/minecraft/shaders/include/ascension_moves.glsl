// Move-specific structures, layered independently of the common material/noise primitives.
float ovalThread(vec3 p,vec2 radius,float width){
  return length(vec2((length(p.xy/radius)-1.)*min(radius.x,radius.y),p.z))-width;
}
float waveTrace(vec3 p,float t,float phase){
  float d=3.;
  for(int i=0;i<18;i++){
    float x=-.78+float(i)*.0867,z=x+.0867;
    vec3 a=vec3(x,sin(x*14.-t*7.+phase)*.115,0);
    vec3 b=vec3(z,sin(z*14.-t*7.+phase)*.115,0);
    d=min(d,capsule(p,a,b,.008));
  }return d;
}
float dischargeRig(vec3 p,float t,bool crown){
  float d=3.,flash=floor(t*8.);int count=crown?8:5;
  for(int i=0;i<8;i++){
    if(i>=count)break;float k=float(i),a=k*6.283185/float(count);
    vec3 last=vec3(cos(a)*.43,-.55,sin(a)*.43);
    for(int j=1;j<7;j++){
      float f=float(j)/6.,seed=hash31(vec3(k,float(j),flash));
      float radius=(crown?.25+.40*sin(f*3.14159):.40+.10*sin(f*3.14159))+(seed-.5)*.13;
      vec3 next=vec3(cos(a+(seed-.5)*.65)*radius,-.55+f*(crown?1.38:1.02),sin(a+(seed-.5)*.65)*radius);
      d=min(d,capsule(p,last,next,crown?.007:.006));
      if(j==3||crown&&j==4)d=min(d,capsule(p,next,next+vec3(cos(a+.6)*.18,.10,sin(a+.6)*.18),.003));
      last=next;
    }
  }return d;
}
float groundDischarge(vec3 p,float t,bool storm){
  float d=3.,flash=floor(t*6.);
  for(int i=0;i<9;i++){
    float a=float(i)*6.283185/9.;vec3 last=vec3(0,.018,0);
    for(int j=1;j<5;j++){
      float r=float(j)*.205,angle=a+(hash31(vec3(i,j,flash))-.5)*.17;
      vec3 next=vec3(cos(angle)*r,.018,sin(angle)*r);
      d=min(d,capsule(p,last,next,.005));
      if(j==3)d=min(d,capsule(p,next,next+vec3(cos(a+.6)*.15,.02,sin(a+.6)*.15),.003));
      if(storm&&j==4&&i%3==0){
        vec3 lead=next;
        for(int k=1;k<=5;k++){
          float u=float(k)/5.,jitter=hash31(vec3(float(i),float(k),flash+3.))-.5;
          vec3 tip=next*(1.-u*.30)+vec3(cos(a+.8)*jitter*.19,u*.70,sin(a+.8)*jitter*.19);
          d=min(d,capsule(p,lead,tip,.006));
          if(k==3)d=min(d,capsule(p,tip,tip+vec3(cos(a+.6)*.13,.13,sin(a+.6)*.13),.003));
          lead=tip;
        }
      }
      last=next;
    }
  }return d;
}
float dipoleField(vec3 p,bool singular){
  float d=3.;int count=singular?8:6;
  for(int i=0;i<8;i++){
    if(i>=count)break;float a=float(i)*6.283185/float(count);vec3 last=vec3(0,-.72,0);
    for(int j=1;j<10;j++){
      float f=float(j)/9.,radius=sin(f*3.141593)*(singular?.70:.58);
      float angle=a+(singular?sin(f*6.28318)*.45:0.);
      vec3 next=vec3(cos(angle)*radius,-.72+1.44*f,sin(angle)*radius);
      d=min(d,capsule(p,last,next,singular?.006:.007));last=next;
    }
  }
  return min(d,rockFacet(p,vec3(singular?.20:.10)));
}
float moveShape(int mode,vec3 p,float t){
  vec3 q=p;float d=3.,r=length(p.xz),a=atan(p.z,p.x);
  if(mode==23){
    for(int i=0;i<3;i++){float y=-.45+float(i)*.42;vec3 v=p-vec3(0,y,0);float radius=.67-.12*abs(float(i)-1.);
      float sector=sin(a*2.+float(i)*2.1);
      d=min(d,max(max(abs(v.y+.13*r*r)-.005,r-radius),(.12-sector)*.10));}
    return d;
  }
  if(mode==24||mode==47)return groundDischarge(p,t,mode==47);
  if(mode==25){
    float rings=abs(mod(r+.06,.18)-.09)-.009;
    float cracks=abs(sin(a*8.+noise3(p*15.)*.8))*r*.09-.006;
    return max(max(min(rings,cracks),abs(p.y-.025-.015*r*r)-.008),r-.85);
  }
  if(mode==26){
    for(int plane=0;plane<2;plane++){
      vec3 v=p;v.xz=spin(float(plane)*1.570796)*v.xz;
      d=min(d,capsule(v,vec3(0,-.65,0),vec3(0,.65,0),.014));
      for(int side=-1;side<=1;side+=2)for(int j=0;j<3;j++){
        float y=float(j)*.35-.4;vec3 end=vec3(float(side)*(.30+float(j)*.05),y+.21,.025);
        d=min(d,capsule(v,vec3(0,y,0),end,.009));d=min(d,length(v-end)-.035);
      }
    }return d;
  }
  if(mode==27){
    float radial=length(p.xy);
    for(int i=0;i<3;i++){float k=float(i),z=-.55+k*.48,radius=.30+k*.24;
      d=min(d,max(abs(p.z-z+radial*radial*.35)-.010,radial-radius));}
    return d;
  }
  if(mode==28||mode==54)return dipoleField(p,mode==54);
  if(mode==29){
    float palm=max(abs(p.y-.205)-.004,boxSdf(p-vec3(0,.20,.03),vec3(.35,.01,.20)));
    float cracks=abs(noise3(p*vec3(25.,9.,25.))-.51)-.025;
    d=max(palm,cracks*.035);
    for(int i=0;i<4;i++){float x=(float(i)-1.5)*.22;
      d=min(d,capsule(p,vec3(x-.055,.405,.24),vec3(x+.045,.405,.34),.003));}
    return d;
  }
  if(mode==30){
    for(int i=0;i<18;i++){float k=float(i),seed=hash31(vec3(k,4,7)),angle=k*2.39996;
      vec3 c=vec3(cos(angle)*(.32+seed*.25),fract(t*.48+seed)*1.48-.74,sin(angle)*(.32+seed*.25));
      d=min(d,crystal(p-c,.018+seed*.018));}
    return d;
  }
  if(mode==31){
    for(int i=0;i<12;i++){float angle=float(i)*.523599;vec3 v=p;v.xy=spin(angle)*v.xy;
      d=min(d,capsule(v,vec3(.21,.02,.006),vec3(.84,.05,.006),.0018));
      d=min(d,length(v-vec3(.59,.039,.006))-.008);}
    return d;
  }
  if(mode==33||mode==46)return dischargeRig(p,t,mode==46);
  if(mode==34){
    for(int i=0;i<11;i++){float k=float(i),angle=k*2.399963+t*.5;vec3 c=vec3(cos(angle)*.48,sin(k*7.)*.58,sin(angle)*.27);
      vec3 v=(p-c)/vec3(1.,1.5,1.);d=min(d,(length(v)-.022)*.8);}
    return d;
  }
  if(mode==35||mode==51){
    int count=mode==51?3:1;
    for(int i=0;i<3;i++){if(i>=count)break;vec3 v=p;v.xz=spin(float(i)*1.047197)*v.xz;
      d=min(d,waveTrace(v,t,float(i)*2.1));
      if(mode==35){v.y-=.32;d=min(d,waveTrace(v,t,1.8));v.y+=.64;d=min(d,waveTrace(v,t,-1.8));}}
    return d;
  }
  if(mode==36){
    float h=clamp((p.y+.72)/1.25,0.,1.);
    d=max(length(p.xz)-(.16+.29*(1.-h)),max(-p.y-.72,p.y-.30));
    d=min(d,boxSdf(p-vec3(0,.48,0),vec3(.19,.19,.17)));
    return d+(fbm(p*10.-vec3(0,t*.35,0))-.45)*.08;
  }
  if(mode==38){
    for(int pole=-1;pole<=1;pole+=2)for(int i=0;i<4;i++){
      float angle=float(i)*1.570796;vec3 v=p;v.xz=spin(angle)*v.xz;
      vec3 start=vec3(.18,float(pole)*.62,0),middle=vec3(.29,float(pole)*.48,.025),end=vec3(.20,float(pole)*.27,0);
      d=min(d,min(capsule(v,start,middle,.003),capsule(v,middle,end,.003)));}
    return d;
  }
  if(mode==39){
    for(int i=0;i<22;i++){float k=float(i),seed=hash31(vec3(k,8,6)),angle=k*2.39996+t*.26;
      vec3 c=vec3(cos(angle)*(.36+seed*.34),sin(k*3.)*.25,sin(angle)*(.36+seed*.34));
      vec3 tangent=vec3(-sin(angle),.15,cos(angle))*.025;
      d=min(d,capsule(p,c-tangent,c+tangent,.0035));}
    return d;
  }
  if(mode==40){
    // Angular connected fractures on each wall face; no smooth noise-contour/jigsaw pattern.
    for(int face=-1;face<=1;face+=2){
      float z=float(face)*.31;
      vec3 v0=vec3(-.82,.62,z),v1=vec3(-.43,.37,z),v2=vec3(-.14,.48,z),v3=vec3(.19,.05,z),v4=vec3(.82,-.14,z);
      d=min(d,min(min(capsule(p,v0,v1,.0035),capsule(p,v1,v2,.0035)),min(capsule(p,v2,v3,.0035),capsule(p,v3,v4,.0035))));
      vec3 b1=vec3(-.33,-.06,z),b2=vec3(-.51,-.42,z),b3=vec3(-.26,-.81,z);
      d=min(d,min(capsule(p,v1,b1,.003),min(capsule(p,b1,b2,.003),capsule(p,b2,b3,.003))));
      vec3 c1=vec3(.34,.40,z),c2=vec3(.24,.83,z);
      d=min(d,min(capsule(p,v3,c1,.0025),capsule(p,c1,c2,.0025)));
      d=min(d,capsule(p,b2,vec3(-.80,-.36,z),.002));
    }
    for(int i=0;i<7;i++){float x=(float(i)-3.)*.24;d=min(d,rockFacet(p-vec3(x,-.85,.34),vec3(.035,.055,.03)));}
    return d;
  }
  if(mode==42){
    for(int i=0;i<9;i++){float angle=float(i)*.698132;vec3 v=p;v.xz=spin(angle)*v.xz;v-=vec3(.34,-.12,0);v.xy=spin(-.5)*v.xy;
      d=min(d,icePrism(v,.065,.76));}
    return d;
  }
  if(mode==44){
    // Bow an orb web forward while preserving thin silk, without broad spherical grid bands.
    float radial=length(p.xy),angle=atan(p.y,p.x);
    float spokes=abs(sin(angle*9.+.025*sin(angle*7.)))*radial/9.-.0025;
    float spiral=abs(mod(radial+.015*angle+.012*sin(angle*5.+radial*9.),.095)-.0475)-.0026;
    float bow=.34-.54*radial*radial;
    float sheet=abs(p.z-bow)/sqrt(1.+1.1664*radial*radial)-.0028;
    return max(min(spokes,spiral),max(radial-.87,sheet));
  }
  if(mode==45){
    for(int i=0;i<3;i++){float angle=p.z*24.+float(i)*2.094395;vec3 v=p;v.xy-=vec2(cos(angle),sin(angle))*.018;d=min(d,max(length(v.xy)-.0035,abs(p.z)-.77));}
    return d;
  }
  if(mode==48){
    float angle=mod(atan(p.z,p.x)+ASC_PI/12.,ASC_PI/6.)-ASC_PI/12.;
    vec2 folded=vec2(cos(angle),sin(angle))*length(p.xz);
    d=max(length(folded-vec2(.70-.48*pow(abs(p.y),.7),0))-.006,abs(p.y)-.83);
    return min(d,torus(p,.62,.005));
  }
  if(mode==49){
    vec3 v=p-vec3(.07,.32,0);float crescent=max(abs(length(v.xy)-.54)-.055,max(-v.y-.04,abs(v.z)-.025));
    float shaft=capsule(p,vec3(-.27,-.82,0),vec3(-.27,.66,0),.035);
    return min(crescent,shaft);
  }
  if(mode==50){
    for(int side=-1;side<=1;side+=2){vec3 last=vec3(0,-.78,0);
      for(int i=1;i<16;i++){float y=-.78+float(i)*.104,angle=y*7.+float(side)*1.5708;float width=.28*(1.-abs(y)*.4);
        vec3 next=vec3(cos(angle)*width,y,sin(angle)*width);d=min(d,capsule(p,last,next,.012));last=next;}}
    return min(d,ovalThread(p,vec2(.52,.67),.006));
  }
  if(mode==52){
    for(int i=0;i<3;i++){float radius=.32+float(i)*.25;vec3 v=p;v.xy=spin(float(i)*.27)*v.xy;
      float cut=abs(sin(atan(v.z,v.x)*3.+float(i)))-.72;
      d=min(d,max(abs(length(v)-radius)-.007,cut*.08));}
    return d;
  }
  if(mode==53){
    d=boxSdf(p,vec3(.18,.46,.18))-.012;
    for(int side=-1;side<=1;side+=2)for(int corner=0;corner<4;corner++){
      vec3 c=vec3(corner%2==0?-.15:.15,float(side)*.63,corner<2?-.15:.15);
      d=min(d,boxSdf(p-c,vec3(.065,.19,.065))-.008);}
    return d;
  }
  return length(p)-.2;
}
vec3 moveGlow(int mode){
  if(mode==26||mode==34||mode==49||mode==50)return vec3(.65,.012,.04);
  if(mode==30||mode==41)return vec3(1.,.37,.025);
  if(mode==29||mode==42)return vec3(.45,.83,.97);
  if(mode==33||mode==46||mode==24||mode==47)return vec3(.25,.52,1.);
  return vec3(.57,.74,.78);
}
vec4 moveMaterial(int mode,vec3 p,vec3 n,vec3 ray,float t){
  float rim=pow(1.-abs(dot(n,ray)),3.),light=.3+.7*max(0.,dot(n,normalize(vec3(-.4,.8,.5))));
  float rough=fbm(p*19.),spec=pow(max(0.,dot(reflect(-normalize(vec3(-.4,.8,.5)),n),-ray)),32.);
  if(mode==23||mode==27||mode==43||mode==52){
    float flow=fbm(p*vec3(18.,9.,18.)-vec3(t*.55,t*.23,0));
    float striation=pow(.5+.5*sin(length(mode==27?p.xy:p.xz)*82.-t*9.+flow*3.),8.);
    if(mode==23||mode==43)return vec4(mix(vec3(.39,.48,.49),vec3(.88,.95,.94),flow)+rim*.15,.10+rim*.38+striation*.24);
    return vec4(mix(vec3(.25,.51,.60),vec3(.71,.91,.94),flow)+rim*.18,.08+rim*.30+striation*.21);
  }
  if(mode==24||mode==33||mode==46||mode==47)return vec4(.83,.93,1.,.96);
  if(mode==25||mode==48)return vec4(mix(vec3(.12,.24,.30),vec3(.73,.86,.91),rough),.34+rim*.30);
  if(mode==26||mode==50){float pulse=.65+.35*pow(.5+.5*sin(p.y*9.-t*4.),4.);return vec4(vec3(.48,.008,.025)*pulse+vec3(.35,.08,.10)*spec,.78);}
  if(mode==28||mode==54){float stream=pow(.5+.5*sin(p.y*19.-t*5.),8.);vec3 poles=mix(vec3(.055,.34,.92),vec3(.96,.14,.035),smoothstep(-.2,.2,p.y));return vec4(mix(vec3(.19,.29,.34),poles,.60)+stream*vec3(.40,.54,.61)+rim*.2,.58+stream*.28);}
  if(mode==29||mode==42)return vec4(mix(vec3(.13,.42,.56),vec3(.71,.94,1.),light*.5+rough*.2)+spec*.25,mode==29?.65:.94);
  if(mode==30){float heat=.58+.35*rough;return vec4(hotGas(heat),smoothstep(-.74,-.50,p.y)*(1.-smoothstep(.52,.74,p.y))*.95);}
  if(mode==31||mode==44||mode==45){float sheen=pow(max(0.,dot(reflect(ray,n),normalize(vec3(-.2,.8,.5)))),60.);float silk=noise3(p*vec3(130.,130.,11.));return vec4(mix(vec3(.31,.40,.46),vec3(.88,.96,.99),light)+sheen*.48+silk*.06,.65+rim*.25);}
  if(mode==34)return vec4(vec3(.29,.003,.014)*light+vec3(.8,.22,.26)*spec,.92);
  if(mode==35||mode==51){float pulse=pow(.5+.5*sin(p.x*18.-t*8.),8.);return vec4(vec3(.29,.62,.71)+vec3(.55,.42,.18)*pulse,.48+rim*.25+pulse*.20);}
  if(mode==36)return vec4(vec3(.055,.061,.069)*light,.26+rim*.32);
  if(mode==38)return vec4(p.y>0.?vec3(.42,.73,1.):vec3(1.,.55,.37),.65);
  if(mode==39||mode==53){
    float brushed=noise3(p*vec3(110.,9.,110.)),pit=pow(noise3(p*150.),9.);
    vec3 steel=mix(vec3(.06,.075,.08),vec3(.40,.44,.46),light)*(.82+brushed*.22)-pit*.08;
    return vec4(steel+spec*(.30+brushed*.25)+rough*.035,1.);
  }
  if(mode==40)return vec4(mix(vec3(.12,.11,.10),vec3(.33,.32,.30),rough)*light,.78);
  if(mode==49)return vec4(mix(vec3(.09,.015,.025),vec3(.44,.47,.49),smoothstep(.015,.05,abs(p.z)))+vec3(.5,.007,.025)*rim+spec*.45,1.);
  return vec4(moveGlow(mode),.7);
}
vec4 moveVolume(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec4 sum=vec4(0);float stepSize=(end-begin)/20.;hit=begin;bool touched=false;
  for(int i=0;i<20;i++){
    float s=begin+(float(i)+.5)*stepSize;vec3 p=ro+rd*s;float r=length(p.xz),density=0.;vec3 color;
    float n=fbm(p*vec3(7.,5.,7.)-vec3(t*.15,t*.7,0));
    if(mode==43){
      // Straight descending downburst strands, not a funnel or a rotating body.
      float column=1.-smoothstep(.28,.36,r),edge=smoothstep(.16,.32,r);
      float flow=fbm(p*vec3(18.,8.,18.)+vec3(0,t*2.1,0));
      float veil=pow(smoothstep(.35,.76,flow),1.5);
      density=column*(.10+veil*1.8)*(.35+edge)*smoothstep(-.85,-.79,p.y)*(1.-smoothstep(.79,.85,p.y));
      color=mix(vec3(.20,.28,.28),vec3(.72,.82,.79),flow);
    }
    else if(mode==32){density=exp(-pow((p.y-.08)/.16,2.))*(1.-smoothstep(.45,.86,r))*(.4+n)*3.;color=mix(vec3(.15,.12,.09),vec3(.48,.44,.37),n);}
    else if(mode==37){float shell=exp(-pow((length(p)-.66-(n-.5)*.14)/.15,2.));density=shell*(.2+n)*.7;color=mix(vec3(.035,.04,.046),vec3(.26,.28,.29),n);}
    else{
      float h=clamp((p.y+.15)/1.1,0.,1.),radius=.16+.35*h+(n-.5)*.16;
      density=(1.-smoothstep(radius*.45,radius,r))*smoothstep(-.15,-.03,p.y)*(1.-smoothstep(.75,.97,p.y))*(.4+n)*7.;
      color=mix(hotGas(.75-h*.4+n*.20),vec3(.18,.16,.14),smoothstep(.48,.94,h));
    }
    float alpha=1.-exp(-density*stepSize);
    if(alpha>.008&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;if(sum.a>.985)break;
  }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
