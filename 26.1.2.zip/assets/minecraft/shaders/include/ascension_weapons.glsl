// Ten weapon materials; finite analytic contacts, with no volume marcher or shared lightning skin.
float weaponLine(float d,float w){return exp(-abs(d)/w);}
vec4 weaponSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
 hit=end+.01;vec3 p,n;vec4 result=vec4(0);
 if(mode==114){
  vec2 roots=quadratic(dot(rd,rd),2.*dot(ro,rd),dot(ro,ro)-.75*.75);float s=roots.x>=begin?roots.x:roots.y;
  if(s<begin||s>end)return result;hit=s;p=ro+rd*s;n=normalize(p);
  float vein=pow(1.-abs(sin(p.x*13.+sin(p.y*9.-t*2.)+p.z*7.)),12.);
  float eddy=.5+.5*sin(p.y*12.+sin(p.x*8.+t)*2.-t*3.);
  float rim=pow(1.-abs(dot(n,rd)),3.),shine=pow(max(0.,dot(reflect(rd,n),normalize(vec3(-.3,.8,-1.)))),28.);
  return vec4(vec3(.23,.004,.012)+vec3(.65,.025,.045)*(eddy*.4+vein*.7)+vec3(1.,.6,.5)*shine+vec3(.7,.04,.06)*rim,.88);
 }
 if(mode==115||mode==122){
  vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-.65*.65);float best=end+.01;
  for(int k=0;k<2;k++){
   float s=roots[k];p=ro+rd*s;if(s<begin||s>best||s>end||abs(p.z)>.98)continue;
   float a=atan(p.y,p.x),edge=pow(1.-abs(dot(normalize(vec3(p.xy,0)),rd)),2.);
   if(mode==115){float pulse=pow(.5+.5*cos(p.z*12.-t*30.+a*3.),8.);result=vec4(vec3(.65,.004,.025)+vec3(.6,.08,.12)*(pulse*.7+edge*.4),.58+edge*.35);}
   else{float links=weaponLine(sin(p.z*34.+a*2.),.16);result=vec4(mix(vec3(.11,.04,.2),vec3(.88,.91,.99),links),.15+links*.8);}
   best=s;
  }if(result.a>0.)hit=best;return result;
 }
 if(mode==116){
  float best=end+.01;
  for(int k=0;k<4;k++){
   vec3 center=k==0?vec3(0,.15,0):k==1?vec3(0,-.6,0):k==2?vec3(0,.61,0):vec3(0,.87,0);
   vec3 axes=k==0?vec3(.045,.7,.045):k==1?vec3(.21,.34,.1):k==2?vec3(.45,.055,.12):vec3(.11,.11,.11);
   float s;vec3 nn;if(!revisionBox(ro-center,rd,axes,begin,end,s,nn)||s>best)continue;
   vec3 q=ro+rd*s-center;if(k==1&&abs(q.x)>(q.y+.35)*.34)continue;
   float rim=pow(1.-abs(dot(nn,rd)),3.);best=s;result=vec4(vec3(.85,.48,.05)+vec3(.7,.55,.25)*rim,.9);
  }if(result.a>0.)hit=best;return result;
 }
 if(mode==117||mode==121){
  if(abs(rd.y)<1e-7)return result;float s=-ro.y/rd.y;p=ro+rd*s;float r=length(p.xz),a=atan(p.z,p.x);
  if(s<begin||s>end||r>.98)return result;hit=s;
  if(mode==117){float halo=weaponLine(r-.94,.014)+weaponLine(r-.82,.008);float links=pow(max(0.,cos(a*24.+t*.7)),24.)*weaponLine(r-.89,.034);return vec4(vec3(1.,.78,.3)+halo*.3,min(.95,halo+links));}
  float split=weaponLine(sin(a*9.+sin(r*13.)*.25)*r,.01)*smoothstep(.05,.2,r);
  float blast=weaponLine(r-min(.94,t*4.),.035)*(1.-smoothstep(.1,.35,t));
  return vec4(vec3(.5,.34,.72)+vec3(.8,.8,.95)*blast,(split*.7+blast)*(1.-smoothstep(.1,.7,t)));
 }
 if(mode==118){
  float best=end+.01;float opening=smoothstep(0.,.3,t);
  for(int side=-1;side<=1;side+=2)for(int feather=0;feather<6;feather++){
   float k=float(feather),angle=float(side)*(.45+opening*.35+k*.08);mat2 pose=spin(angle);
   vec3 center=vec3(float(side)*(.23+k*.105),.33-k*.095,.03+k*.018),o=ro-center,d=rd;o.xy=pose*o.xy;d.xy=pose*d.xy;
   vec3 axes=vec3(.085,.47-k*.024,.035);float s;vec3 nn;
   if(!revisionBox(o,d,axes,begin,end,s,nn)||s>best)continue;vec3 q=o+d*s;
   if(abs(q.x)>(.6-q.y)*.105)continue;
   float spine=weaponLine(q.x,.008),edge=pow(1.-abs(dot(nn,d)),3.);best=s;result=vec4(vec3(.95,.88,.61)+vec3(.25,.3,.5)*spine,.42+spine*.4+edge*.15);
  }if(result.a>0.)hit=best;return result;
 }
 if(mode==120){
  // An extruded crescent has real front/back faces and curved sidewalls in every view.
  float best=end+.01;vec3 normal=vec3(0,0,1);
  for(int cap=0;cap<2;cap++){
   float z=cap==0?-.14:.14;if(abs(rd.z)<1e-7)continue;float s=(z-ro.z)/rd.z;vec3 q=ro+rd*s;
   if(s>=begin&&s<best&&s<=end&&length(q.xy)<.83&&length(q.xy-vec2(.21,0))>.70){best=s;normal=vec3(0,0,cap==0?-1.:1.);}
  }
  for(int wall=0;wall<2;wall++){
   vec2 center=wall==0?vec2(0):vec2(.21,0);float radius=wall==0?.83:.70;vec2 o=ro.xy-center;
   vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(o,rd.xy),dot(o,o)-radius*radius);
   for(int k=0;k<2;k++){float s=roots[k];vec3 q=ro+rd*s;if(s<begin||s>=best||s>end||abs(q.z)>.14)continue;
    if(wall==0&&length(q.xy-vec2(.21,0))<.70)continue;if(wall==1&&length(q.xy)>.83)continue;
    best=s;normal=normalize(vec3((q.xy-center)*(wall==0?1.:-1.),0));
   }
  }
  vec3 o=ro,d=rd;o.xy=spin(.30)*o.xy;d.xy=spin(.30)*d.xy;float s;vec3 nn;
  if(revisionBox(o,d,vec3(.022,.94,.12),begin,end,s,nn)&&s<best){best=s;normal=vec3(transpose(spin(.30))*nn.xy,nn.z);}
  if(best>end)return result;hit=best;p=ro+rd*hit;
  float bevel=weaponLine(length(p.xy)-.83,.018)+weaponLine(length(p.xy-vec2(.21,0))-.70,.014);
  float shine=pow(1.-abs(dot(normal,rd)),3.);return vec4(vec3(.26,.16,.39)+vec3(.85,.85,.98)*(bevel+shine*.35),.85);
 }
 if(mode==119){
  if(!revisionBox(ro,rd,vec3(.94,.94,.14),begin,end,hit,n))return result;p=ro+rd*hit;
  float r=length(p.xy),a=atan(p.y,p.x),alpha;
  if(mode==119){float ring=weaponLine(r-.78,.018)+weaponLine(r-.93,.009);float seal=weaponLine(abs(p.x)-abs(p.y),.022)*(1.-smoothstep(.45,.65,r));float runes=pow(max(0.,cos(a*8.)),30.)*weaponLine(r-.86,.045);alpha=ring+seal+runes;return vec4(mix(vec3(.18,.025,.3),vec3(.93,.91,1.),min(1.,seal+ring*.7)),min(.95,alpha));}
  float crescent=weaponLine(length(p.xy+vec2(.2,0))-.73,.06)*smoothstep(-.6,.3,cos(a));
  float edge=weaponLine(length(p.xy+vec2(.2,0))-.79,.012),crosscut=weaponLine(p.x-p.y*.3,.018)*(1.-smoothstep(.65,.9,r));
  return vec4(vec3(.22,.09,.33)+vec3(.95,.95,1.)*(edge+crosscut),min(.95,crescent*.7+edge+crosscut));
 }
 if(mode==123){
  float slope=.55,offset=.4,r0=offset+slope*ro.y,dr=slope*rd.y;
  vec2 roots=quadratic(dot(rd.xz,rd.xz)-dr*dr,2.*(dot(ro.xz,rd.xz)-r0*dr),dot(ro.xz,ro.xz)-r0*r0);
  for(int k=0;k<2;k++){float s=roots[k];p=ro+rd*s;if(s<begin||s>end||abs(p.y)>.9)continue;float a=atan(p.z,p.x),tracer=pow(max(0.,cos(a*12.+p.y*3.)),36.);hit=s;return vec4(vec3(.7,.63,.88)+tracer*.5,(.05+tracer*.65)*(1.-smoothstep(.6,.95,abs(p.y))));}
 }return result;
}
