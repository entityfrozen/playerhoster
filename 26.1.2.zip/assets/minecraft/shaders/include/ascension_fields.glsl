// Move-specific geometry and materials. All work is bounded per ray; never spawn detail entities.
vec4 tidalBore(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal=vec3(0,1,0),p=vec3(0);float crest=0.;
  for(int layer=0;layer<3;layer++){
    float offset=float(layer)*.075-.10,s=clamp((offset-ro.y)/(abs(rd.y)<.01?.01:rd.y),begin,end);
    // Newton solve the curled traveling sheet, instead of ray-marching a water-filled cube.
    for(int j=0;j<5;j++){
      vec3 q=ro+rd*s;float phase=q.z*4.5-t*1.6+float(layer)*.7;
      float height=.15*sin(phase)+.055*q.x*q.x+offset;
      float derivative=rd.y-.675*cos(phase)*rd.z-.11*q.x*rd.x;
      if(abs(derivative)>.002)s-=clamp((q.y-height)/derivative,-.4,.4);
    }
    vec3 q=ro+rd*s;float phase=q.z*4.5-t*1.6+float(layer)*.7;
    if(s<begin||s>min(hit,end)||abs(q.x)>.97||abs(q.z)>.97||abs(q.y-(.15*sin(phase)+.055*q.x*q.x+offset))>.012)continue;
    hit=s;p=q;normal=normalize(vec3(-.11*q.x,1.,-.675*cos(phase)));crest=pow(.5+.5*sin(phase),8.);
  }
  if(hit>end)return vec4(0);
  float foam=pow(noise3(p*vec3(38.,13.,23.)-vec3(0,0,t*2.)),3.)*crest;
  float bank=smoothstep(.62,.94,abs(p.x)),wake=pow(1.-abs(2.*noise3(p*vec3(17.,4.,39.)-vec3(0,0,t*3.))-1.),12.);
  vec3 color=liquidLight(p,normal,rd,t)+vec3(.48,.85,.91)*(foam*1.8+bank*.4+wake*.22);
  float edge=(1.-smoothstep(.91,.98,abs(p.x)))*(1.-smoothstep(.90,.98,abs(p.z)));
  return vec4(color,(.66+crest*.20)*edge);
}
vec3 channelPoint(int j,float flash){
  float k=float(j),z=-.95+k*1.90/12.;
  return vec3((hash31(vec3(k,flash,11))-.5)*.28,(hash31(vec3(k,flash,19))-.5)*.28,z);
}
vec4 lightningChannel(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal;float halo=0.;vec3 last=channelPoint(0,floor(t*14.));
  for(int j=1;j<=12;j++){
    vec3 next=channelPoint(j,floor(t*14.));
    float s=creatureCapsule(ro,rd,last,next,.045,normal);
    if(s>=begin&&s<min(hit,end))hit=s;
    // A continuous, wider ionized sheath is integrated once per segment at closest approach.
    vec3 axis=next-last,o=ro-last;float aa=dot(axis,axis),ad=dot(axis,rd),den=max(.00001,aa-ad*ad);
    float u=clamp((dot(o,rd)*ad-dot(o,axis))/den,0.,1.);
    float d=clamp(dot(last+axis*u-ro,rd),begin,end),distance=length(ro+rd*d-last-axis*u);
    halo=max(halo,exp(-distance*distance*220.)*.72);
    if(j%3==0){
      vec3 fork=next+vec3(j%2==0?.23:-.23,.15,-.13);
      s=creatureCapsule(ro,rd,next,fork,.016,normal);if(s>=begin&&s<min(hit,end))hit=s;
    }
    last=next;
  }
  if(hit<=end)return vec4(1.35,1.19,.71,1.);
  hit=clamp(-dot(ro,rd),begin,end);return vec4(1.,.62,.06,halo);
}
vec4 stormCircuit(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end;if(abs(rd.y)<1e-6)return vec4(0);hit=-ro.y/rd.y;if(hit<begin||hit>end)return vec4(0);
  vec3 p=ro+rd*hit;float r=length(p.xz);if(r>.97)return vec4(0);
  float angle=atan(p.z,p.x),sector=floor(angle/(2.*ASC_PI/9.)+.5),a=angle-sector*(2.*ASC_PI/9.);
  vec2 q=vec2(cos(a),sin(a))*r;float segment=floor(q.x*8.),f=fract(q.x*8.),flash=floor(t*13.);
  float one=(hash31(vec3(segment,sector,flash))-.5)*.11,two=(hash31(vec3(segment+1.,sector,flash))-.5)*.11;
  float center=mix(one,two,f),width=max(.002,length(fwidth(p.xz))*.55);
  float bolt=exp(-pow(abs(q.y-center)/(width+.003),2.))*smoothstep(.025,.07,r)*(1.-smoothstep(.82,.94,r));
  float sheath=exp(-abs(q.y-center)*65.)*.35;
  float branch=exp(-pow((abs(q.y-center)-max(0.,q.x-.45)*.35)/(width+.0015),2.))*smoothstep(.45,.52,r)*(1.-smoothstep(.69,.78,r));
  float corona=exp(-abs(r-(.84+.015*sin(angle*11.+flash)))*100.)*pow(.5+.5*sin(angle*7.+flash),3.)*.35;
  float intensity=max(bolt,max(branch,corona));return vec4(mix(vec3(1.,.52,.04),vec3(1.4,1.30,.88),intensity),min(.98,intensity+sheath));
}
float infernalLink(vec3 p){
  float index=floor((p.z+.98)/.18),z=mod(p.z+.98,.18)-.09;
  vec2 q=mod(index,2.)<.5?p.xy:p.yx;
  return length(vec2((length(vec2(q.x/.22,z/.115))-1.)*.115,q.y))-.027;
}
vec4 infernalChain(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=begin;bool found=false;
  for(int j=0;j<56;j++){
    vec3 p=ro+rd*hit;float d=infernalLink(p);
    if(abs(d)<.003){found=true;break;}hit+=max(.002,abs(d)*.72);if(hit>end)break;
  }
  if(!found)return vec4(0);vec3 p=ro+rd*hit;vec2 e=vec2(.002,0);
  vec3 n=normalize(vec3(infernalLink(p+e.xyy)-infernalLink(p-e.xyy),infernalLink(p+e.yxy)-infernalLink(p-e.yxy),infernalLink(p+e.yyx)-infernalLink(p-e.yyx)));
  float seams=pow(1.-abs(2.*noise3(p*27.-vec3(0,0,t*.15))-1.),11.);
  float spec=pow(max(0.,dot(reflect(rd,n),normalize(vec3(-.4,.8,-.5)))),28.);
  return vec4(vec3(.055,.025,.018)+hotGas(.6)*(.35+seams*.9)+spec*.4,.98);
}
vec4 acousticWall(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  vec3 n;if(!revisionBox(ro,rd,vec3(.98),begin,end,hit,n))return vec4(0);
  vec3 p=ro+rd*hit;float edge=pow(max(abs(p.x),abs(p.y)),24.);
  // Traveling compression fronts and fine Schlieren-like bands, rather than a glowing checkerboard.
  float flow=noise3(vec3(p.xy*7.,t*.35));
  float front=pow(.5+.5*cos(p.x*28.+sin(p.y*6.+t*3.)*.65-t*8.),18.);
  float harmonic=pow(.5+.5*sin(p.y*35.+p.x*3.-t*11.+flow),22.);
  float aa=max(.003,length(fwidth(p.xy))*.5),border=1.-smoothstep(.012,.012+aa,abs(max(abs(p.x),abs(p.y))-.93));
  return vec4(vec3(.35,.70,.82)+front*vec3(.45,.40,.22)+harmonic*.17,.055+edge*.50+border*.72+front*.28+harmonic*.12);
}
vec4 abyssalCrown(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal=vec3(0,1,0);vec4 sum=vec4(0);
  float radius=.56+.36*ro.y,slope=.36*rd.y;
  vec2 roots=quadratic(dot(rd.xz,rd.xz)-slope*slope,2.*(dot(ro.xz,rd.xz)-radius*slope),dot(ro.xz,ro.xz)-radius*radius);
  for(int k=0;k<2;k++){
    float s=roots[k];vec3 p=ro+rd*s;if(s<begin||s>min(hit,end)||p.y<-.62||p.y>.55)continue;
    float a=atan(p.z,p.x),edge=.30+.17*sin(a*7.+t*2.)+.07*sin(a*13.-t*3.);
    if(p.y>edge)continue;normal=normalize(vec3(p.x,-.36*length(p.xz),p.z));hit=s;
    float lip=exp(-abs(p.y-edge)*85.),froth=pow(noise3(p*45.-vec3(0,t*2.,0)),5.);
    sum=vec4(liquidLight(p,normal,rd,t)+vec3(.48,.86,.95)*(lip+froth),.78);
  }
  for(int k=0;k<9;k++){
    float f=float(k),a=f*2.39996,phase=fract(t*.45+f*.117),r=.40+phase*.36;
    vec3 center=vec3(cos(a)*r,-.15+sin(phase*ASC_PI)*.90,sin(a)*r),n;
    float s=creatureEllipsoid(ro,rd,center,vec3(.022,.047,.022),n);
    if(s>=begin&&s<min(hit,end)){hit=s;sum=vec4(liquidLight(ro+rd*s,n,rd,t)+.25,.94);}
  }
  return sum;
}
vec4 horizonLens(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec4 sum=vec4(0);vec2 span;
  if(raySphereSpan(ro,rd,vec3(0),.79,span)){
    float s=span.x>=begin?span.x:span.y;
    if(s>=begin&&s<=end){vec3 p=ro+rd*s,n=normalize(p);float rim=pow(1.-abs(dot(n,rd)),5.);
      float stripes=pow(.5+.5*cos(atan(p.z,p.x)*12.+p.y*7.-t*.7),24.);
      float equator=exp(-abs(p.y)*72.);sum=vec4(vec3(.15,.26,.32)+vec3(.45,.65,.73)*(rim+stripes*.2+equator*.7),.025+rim*.65+equator*.6);hit=s;}
  }
  // Meridional field arcs bend inward toward a compressed equator, leaving clear gaps.
  for(int k=0;k<6;k++){
    float angle=float(k)*ASC_PI/3.+t*.07;vec3 previous=vec3(0,-.88,0),n;
    for(int j=1;j<=8;j++){
      float u=float(j)/8.,y=-.88+u*1.76,r=.82*pow(max(0.,sin(u*ASC_PI)),.65);
      vec3 next=vec3(cos(angle+y*.5)*r,y,sin(angle+y*.5)*r);
      float s=creatureCapsule(ro,rd,previous,next,.004,n);
      if(s>=begin&&s<min(hit,end)){hit=s;sum=vec4(.63,.84,.91,.83);}previous=next;
    }
  }
  return sum;
}
