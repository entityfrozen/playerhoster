// Revision-one rigs. Bounded analytic surfaces; no nested ray marching or geometry bounce.
bool revisionBox(vec3 ro,vec3 rd,vec3 halfSize,float begin,float end,out float hit,out vec3 normal){
  vec3 inv=1./(rd+vec3(1e-8)),a=(-halfSize-ro)*inv,b=(halfSize-ro)*inv;
  vec3 lo=min(a,b),hi=max(a,b);hit=max(begin,max(max(lo.x,lo.y),lo.z));
  if(hit>min(end,min(min(hi.x,hi.y),hi.z)))return false;
  vec3 p=ro+rd*hit,q=abs(p/halfSize);normal=q.x>q.y&&q.x>q.z?vec3(sign(p.x),0,0):q.y>q.z?vec3(0,sign(p.y),0):vec3(0,0,sign(p.z));return true;
}
float revisionCrack(vec3 p){
  vec3 cell=floor(p),f=fract(p);float one=10.,two=10.;
  // Nine neighboring seeds in the visible ice face, rather than a repeated stripe grid.
  for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){
    vec3 o=vec3(x,y,0),seed=vec3(hash31(cell+o),hash31(cell+o+31.),.5);
    float d=length(o.xy+seed.xy-f.xy);if(d<one){two=one;one=d;}else two=min(two,d);
  }return 1.-smoothstep(.025,.065,two-one);
}
#moj_import <minecraft:ascension_creature.glsl>
#moj_import <minecraft:ascension_solar.glsl>
#moj_import <minecraft:ascension_fields.glsl>
#moj_import <minecraft:ascension_weather.glsl>
#moj_import <minecraft:ascension_tempest.glsl>
#moj_import <minecraft:ascension_temporal.glsl>
#moj_import <minecraft:ascension_chrono_web.glsl>
#moj_import <minecraft:ascension_sense.glsl>
#moj_import <minecraft:ascension_speed.glsl>
#moj_import <minecraft:ascension_weapons.glsl>
#moj_import <minecraft:ascension_boom.glsl>
vec4 revisionSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end;vec3 p,n=vec3(0,1,0);vec2 span;float alpha=1.;vec3 color=vec3(1);
  if(mode>=124&&mode<=131)return boomSurface(mode,ro,rd,t,begin,end,hit);
  if(mode>=114&&mode<=123)return weaponSurface(mode,ro,rd,t,begin,end,hit);
  if(mode>=106&&mode<=113)return speedSurface(mode,ro,rd,t,begin,end,hit);
  if(mode>=98&&mode<=105)return senseSurface(mode,ro,rd,t,begin,end,hit);
  if(mode>=91&&mode<=97)return chronoWebSurface(mode,ro,rd,t,begin,end,hit);
  if(mode==85||mode==86)return tempestSurface(mode,ro,rd,t,begin,end,hit);
  if(mode>=87&&mode<=90)return temporalSurface(mode,ro,rd,t,begin,end,hit);
  if(mode==83||mode==84)return weatherField(mode,ro,rd,t,begin,end,hit);
  if(mode==62||mode==64||(mode>=77&&mode<=82))return solarSurface(mode,ro,rd,t,begin,end,hit);
  if(mode==55)return tidalBore(ro,rd,t,begin,end,hit);
  if(mode==60)return lightningChannel(ro,rd,t,begin,end,hit);
  if(mode==61)return stormCircuit(ro,rd,t,begin,end,hit);
  if(mode==66)return infernalChain(ro,rd,t,begin,end,hit);
  if(mode==70)return acousticWall(ro,rd,t,begin,end,hit);
  if(mode==58)return abyssalCrown(ro,rd,t,begin,end,hit);
  if(mode==69)return horizonLens(ro,rd,t,begin,end,hit);
  if(mode==59||mode==72)return leviathanSurface(mode,ro,rd,t,begin,end,hit);
  if(mode==70){
    if(!revisionBox(ro,rd,vec3(.98),begin,end,hit,n))return vec4(0);p=ro+rd*hit;
    float edge=pow(max(abs(p.x),abs(p.y)),20.);
    float wave=pow(.5+.5*sin(p.x*22.+t*9.)*sin(p.y*13.-t*6.),6.);
    return vec4(vec3(.50,.83,1.)+wave*.5,.10+edge*.7+wave*.4+abs(n.x+n.y)*.2);
  }
  if(mode==73){
    float front=abs(rd.z)<1e-6?end+1.:-ro.z/rd.z;vec3 q=ro+rd*front;
    float r=length(q.xy),a=atan(q.y,q.x);float d=exp(-abs(r-.88)*100.)+exp(-abs(r-.68)*100.);
    d=max(d,pow(max(0.,cos(a*12.)),32.)*smoothstep(.75,.80,r)*(1.-smoothstep(.86,.88,r)));
    vec2 hand=vec2(sin(t*.8),cos(t*.8));d=max(d,exp(-abs(q.x*hand.y-q.y*hand.x)*120.)*step(0.,dot(q.xy,hand))*step(r,.68));
    if(front>=begin&&front<=end&&r<.98&&d>.005){hit=front;return vec4(.75,.91,1.,min(.95,d));}
    vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-.88*.88);
    for(int i=0;i<2;i++){float s=roots[i];if(s>=begin&&s<=end&&abs((ro+rd*s).z)<.06){hit=s;return vec4(.75,.91,1.,.8);}}
    return vec4(0);
  }
  bool sheet=mode==55||mode==61||mode==67||mode==70||mode==73||mode==75;
  if(sheet){
    bool vertical=mode==70||mode==73;float den=vertical?rd.z:rd.y;
    if(abs(den)<1e-6)return vec4(0);hit=-(vertical?ro.z:ro.y)/den;
    if(hit<begin||hit>end)return vec4(0);p=ro+rd*hit;vec2 uv=vertical?p.xy:p.xz;
    if(mode==55){
      if(abs(p.x)>.98||abs(p.z)>.98)return vec4(0);
      float flow=fbm(vec3(p.x*7.,t*.6,p.z*4.-t*2.));
      float foam=smoothstep(.58,.77,flow)+pow(1.-abs(p.x),20.)*.2;
      float edge=(1.-smoothstep(.72,.98,abs(p.x)))*(1.-smoothstep(.80,.98,abs(p.z)));
      return vec4(mix(vec3(.015,.20,.38),vec3(.72,.96,1.),foam),edge*(.5+foam*.4));
    }
    if(mode==70){
      if(abs(uv.x)>.98||abs(uv.y)>.98)return vec4(0);
      float edge=pow(max(abs(uv.x),abs(uv.y)),20.);
      float interference=pow(.5+.5*sin(uv.x*22.+t*9.)*sin(uv.y*13.-t*6.),6.);
      return vec4(vec3(.50,.83,1.)+interference*.5,.10+edge*.70+interference*.4);
    }
    float r=length(uv),a=atan(uv.y,uv.x);if(r>.98)return vec4(0);
    if(mode==75){float rays=pow(max(0.,cos(a*8.)),28.)*smoothstep(.3,.5,r)*(1.-smoothstep(.83,.92,r));float rings=exp(-abs(r-.70)*120.)+exp(-abs(r-.9)*120.);float center=exp(-abs(r-.18)*85.);return vec4(vec3(1.,.72,.12),min(.95,max(rings,max(center,rays))));}
    if(mode==67){
      if(cos(a*3.)>.93)return vec4(0); // Readable exits in the infernal ring.
      float flame=fbm(vec3(cos(a)*5.,sin(a)*5.,r*10.-t*3.));
      float ring=exp(-abs(r-(.78+flame*.07))*45.);
      return vec4(hotGas(.55+flame*.35),ring*(.6+flame*.4));
    }
    float outer=exp(-abs(r-.88)*100.),inner=exp(-abs(r-.68)*100.);
    float ticks=pow(max(0.,cos(a*(mode==73?12.:18.))),32.)*smoothstep(.75,.80,r)*(1.-smoothstep(.86,.88,r));
    float hand=0.;if(mode==73){vec2 d=vec2(sin(t*.8),cos(t*.8));hand=exp(-abs(uv.x*d.y-uv.y*d.x)*120.)*step(0.,dot(uv,d))*step(r,.68);}
    float spokes=mode==61?pow(max(0.,cos(a*5.+t)),16.)*exp(-abs(r-.43)*55.):hand;
    return vec4(mode==73?vec3(.75,.91,1.):vec3(1.,.74,.18),max(max(outer,inner),max(ticks,spokes))*.95);
  }
  if(mode==65){
    if(!revisionBox(ro,rd,vec3(.98),begin,end,hit,n))return vec4(0);p=ro+rd*hit;
    vec2 face=abs(n.z)>.5?p.xy:abs(n.x)>.5?p.zy:p.xz;
    float cracks=revisionCrack(vec3(face*5.,2.)),cloud=fbm(p*10.);
    float frost=pow(noise3(p*95.),8.),rim=pow(1.-abs(dot(n,rd)),3.);
    color=mix(vec3(.045,.25,.39),vec3(.38,.75,.91),cloud)+vec3(.60,.91,1.)*(cracks*.8+frost*.5+rim*.3);
    return vec4(color,.64+cracks*.3);
  }
  if(mode==57||mode==74){
    // Physical spear silhouette: a slender shaft and a distinct conical spearhead.
    float slope=-.85/1.08,offset=.85*.98/1.08;
    float r0=slope*ro.z+offset,dr=slope*rd.z;
    vec2 cone=quadratic(dot(rd.xy,rd.xy)-dr*dr,2.*(dot(ro.xy,rd.xy)-r0*dr),dot(ro.xy,ro.xy)-r0*r0);
    vec2 shaft=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-.12*.12);
    float nearest=end+1.;
    for(int i=0;i<2;i++){
      float s=cone[i],z=(ro+rd*s).z;if(s>=begin&&s<nearest&&z>-.1&&z<.98)nearest=s;
      s=shaft[i];z=(ro+rd*s).z;if(s>=begin&&s<nearest&&z>-.98&&z<.1)nearest=s;
    }
    if(nearest>end)return vec4(0);hit=nearest;p=ro+rd*hit;
    n=normalize(vec3(p.xy,.2));float granules=fbm(p*22.-vec3(0,0,t*3.));
    if(mode==74){float stream=pow(.5+.5*cos(atan(p.y,p.x)*5.+p.z*23.+granules*4.-t*9.),18.);float tip=smoothstep(.60,.98,p.z);return vec4(mix(vec3(.72,.42,.07),vec3(1.45,1.35,.93),stream+tip*.7),.45+stream*.5+tip*.45);}
    return vec4(liquidLight(p,n,rd,t),.88);
  }
  if(mode==63){
    // Integrate a smooth luminous core through a bounded cylinder, rather than drawing its shell.
    float aa=dot(rd.xy,rd.xy);vec2 roots=quadratic(aa,2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-.88*.88);
    float near=max(begin,roots.x),far=min(end,roots.y);
    if(aa<1e-8){if(length(ro.xy)>.88)return vec4(0);near=begin;far=end;}
    if(abs(rd.z)>1e-7){vec2 zcap=vec2((-.98-ro.z)/rd.z,(.98-ro.z)/rd.z);near=max(near,min(zcap.x,zcap.y));far=min(far,max(zcap.x,zcap.y));}
    else if(abs(ro.z)>.98)return vec4(0);
    if(near>far)return vec4(0);
    float closest=aa<1e-8?near:clamp(-dot(ro.xy,rd.xy)/aa,near,far);
    vec3 core=ro+rd*closest;float r=length(core.xy)/.88;
    float glow=pow(max(0.,1.-r*r),3.);float white=exp(-r*9.);
    float flow=noise3(core*vec3(13.,13.,19.)-vec3(0,0,t*5.));
    float braid=pow(.5+.5*cos(atan(core.y,core.x)*3.+core.z*19.-t*12.+flow*3.),8.);
    float plasma=.72+.14*flow+braid*.25;
    hit=near;return vec4(mix(vec3(1.,.35,.015),vec3(1.7,1.65,1.4),white)+braid*glow*.15,min(.98,glow*plasma*(.6+min(1.,far-near))));
  }
  bool axial=mode==56||mode==60||mode==66||mode==68||mode==71||mode==76;
  if(axial){
    // Elliptical cylinder, clipped by the projectile/beam's true endpoints.
    float radius=mode==56?.60:mode==60?.24:mode==66?.36:mode==68?.32:.88;
    vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-radius*radius);
    bool found=false;
    for(int i=0;i<2;i++){float s=roots[i];vec3 q=ro+rd*s;if(s>=begin&&s<=end&&abs(q.z)<.98){hit=s;p=q;found=true;break;}}
    if(!found){vec3 nn;if(!revisionBox(ro,rd,vec3(radius,radius,.98),begin,end,hit,nn))return vec4(0);p=ro+rd*hit;if(length(p.xy)>radius)return vec4(0);}
    float a=atan(p.y,p.x),z=p.z;
    n=normalize(vec3(p.xy,0));
    if(mode==56)return vec4(liquidLight(p,n,rd,t),.55+pow(1.-abs(dot(n,rd)),3.)*.4);
    if(mode==76){float fiber=noise3(vec3(p.xy*90.,z*5.));float rim=pow(1.-abs(dot(n,rd)),2.);float twist=pow(.5+.5*cos(a*9.+z*95.),12.);return vec4(vec3(.45,.56,.61)+fiber*.25+twist*.22,.50+rim*.35+twist*.12);}
    if(mode==57){float scale=sin(z*25.+a*4.-t*7.);return vec4(mix(vec3(.025,.29,.55),vec3(.7,.97,1.),pow(max(0.,scale),8.)),.88);}
    if(mode==66){float links=pow(max(0.,cos(z*29.)),4.)*pow(abs(cos(a+floor(z*10.)*1.57)),2.);return vec4(hotGas(.45+links*.45),.18+links*.8);}
    if(mode==68){float memory=fbm(p*18.-vec3(0,0,t*2.));float edge=pow(1.-abs(dot(n,rd)),4.);float fronts=pow(.5+.5*cos(z*26.-t*10.+sin(a*3.)*.6),20.);return vec4(vec3(.14,.35,.46)+memory*.20+vec3(.53,.87,.92)*(edge*.5+fronts*.5),.045+edge*.24+fronts*.6);}
    if(mode==71){float spec=pow(max(0.,dot(reflect(rd,n),normalize(vec3(-.4,.8,-.5)))),64.);float seam=exp(-abs(abs(p.x)-.72)*85.);float grooves=pow(.5+.5*cos(z*75.),30.);float brushed=noise3(p*vec3(125.,125.,7.));vec3 rails=mix(vec3(.06,.42,1.),vec3(1.,.10,.04),step(0.,p.x));return vec4(vec3(.085,.12,.16)*(.7+brushed*.5)+spec*.7+rails*seam*(1.1+grooves*.7)+grooves*.06,.98);}
    if(mode==60){float arc=fbm(vec3(z*15.,a*3.,floor(t*18.)));float sparks=pow(smoothstep(.48,.8,arc),6.);return vec4(vec3(1.,.73,.22)*(.22+sparks)+sparks*.65,.08+sparks*.92);}
    float filament=fbm(p*vec3(17.,17.,7.)-vec3(0,0,t*4.));float hot=pow(smoothstep(.4,.75,filament),3.);return vec4(vec3(1.,.63,.10)+hot*.7,.20+hot*.70);
  }
  return vec4(0);
}
