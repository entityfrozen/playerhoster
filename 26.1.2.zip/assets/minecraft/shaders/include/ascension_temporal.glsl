// Distinct temporal silhouettes: fractured pause bubble, flowing tempo, snapshot shards, acceleration wake.
vec4 temporalSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec4 sum=vec4(0);vec2 span;
  if(mode==87){
    if(!raySphereSpan(ro,rd,vec3(0),.86,span))return sum;
    float s=span.x>=begin?span.x:span.y;if(s>end)return sum;hit=s;
    vec3 p=ro+rd*s,n=normalize(p);float rim=pow(1.-abs(dot(n,rd)),3.);
    vec3 q=p;q.xz=spin(.13)*q.xz;
    float fracture=revisionCrack(vec3(q.xy*5.+q.z*1.7,3.));
    float slices=pow(max(0.,cos((p.y+p.z*.32)*17.+sin(p.x*11.))),24.);
    return vec4(mix(vec3(.16,.47,.63),vec3(.85,.98,1.),fracture),.022+rim*.21+fracture*.19+slices*.09);
  }
  if(mode==88){
    if(abs(rd.y)<1e-5)return sum;
    for(int k=0;k<3;k++){
      float y=-.32+float(k)*.32,s=(y-ro.y)/rd.y;if(s<begin||s>end)continue;
      vec3 p=ro+rd*s;float r=length(p.xz);if(r>.94||r<.12)continue;
      float a=atan(p.z,p.x),stream=pow(max(0.,sin(a*3.+r*14.-t*4.5-float(k)*1.4)),18.);
      float lane=exp(-pow((r-(.32+float(k)*.22))/.027,2.));
      float alpha=(stream*.52+lane*.21)*(1.-smoothstep(.86,.94,r));
      if(alpha>.008){hit=min(hit,s);sum=solarOver(sum,vec4(mix(vec3(.20,.65,.79),vec3(1.,.80,.39),stream),alpha));}
    }return sum;
  }
  if(mode==90){
    vec2 roots=quadratic(dot(rd.xz,rd.xz),2.*dot(ro.xz,rd.xz),dot(ro.xz,ro.xz)-.78*.78);
    for(int k=0;k<2;k++){
      float s=roots[k];if(s<begin||s>end)continue;vec3 p=ro+rd*s;if(abs(p.y)>.88)continue;
      float a=atan(p.z,p.x),streak=pow(max(0.,cos(a*9.+p.y*4.-t*5.)),26.);
      float dash=smoothstep(.05,.22,fract(p.y*3.-t*1.6+a*.22));
      float alpha=streak*dash*(1.-smoothstep(.60,.88,abs(p.y)))*.74;
      if(alpha>.005){hit=min(hit,s);sum=solarOver(sum,vec4(mix(vec3(.25,.71,1.),vec3(1.1,.94,.62),streak),alpha));}
    }return sum;
  }
  // Floating broken snapshot planes, rather than another clock face or a reused dome.
  for(int k=0;k<9;k++){
    float a=float(k)*2.399963;vec3 normal=vec3(cos(a),0,sin(a)),right=vec3(-sin(a),0,cos(a));
    vec3 center=normal*(.35+float(k%3)*.17)+vec3(0,sin(float(k)*4.+t*.2)*.42,0);
    float den=dot(rd,normal);if(abs(den)<1e-6)continue;float s=dot(center-ro,normal)/den;if(s<begin||s>end)continue;
    vec3 point=ro+rd*s-center;vec2 uv=vec2(dot(point,right),point.y);
    float shape=max(abs(uv.x)*1.5+abs(uv.y)*.42-.20,max(abs(uv.y)-.28,-uv.x-uv.y*.3-.15));
    if(shape>0.)continue;float edge=exp(shape*180.);
    float crack=pow(max(0.,cos(uv.x*29.+sin(uv.y*23.)*2.)),30.);
    float pulse=.65+.35*sin(t*2.-float(k));
    vec4 shard=vec4(mix(vec3(.24,.56,.70),vec3(1.,.89,.59),edge),(.07+edge*.78+crack*.17)*pulse);
    hit=min(hit,s);sum=solarOver(sum,shard);
  }
  return sum;
}
