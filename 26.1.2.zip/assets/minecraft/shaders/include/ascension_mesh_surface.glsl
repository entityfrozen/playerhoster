vec4 aspectSurface(int material,vec3 p,vec3 n,vec3 view){
  n=normalize(n);if(!gl_FrontFacing)n=-n;
  vec3 v=normalize(-view),l=normalize(vec3(-.45,.80,.6));
  float diffuse=.22+.78*max(0.,dot(n,l));
  float rim=pow(1.-max(0.,dot(n,v)),3.);
  float spec=pow(max(0.,dot(n,normalize(l+v))),55.);
  float scale=pow(.5+.5*cos(p.z*155.+sin(p.y*115.)*2.8),9.)*pow(.5+.5*sin(p.y*110.),3.);
  vec3 base=mix(vec3(.018,.16,.22),vec3(.06,.58,.65),smoothstep(.28,.78,p.y));
  base*=.80+.28*scale;
  if(material==1)base=mix(vec3(.045,.26,.32),vec3(.34,.78,.78),smoothstep(.4,.9,p.y));
  if(material==2)base=vec3(.80,.94,.91);
  if(material==3)return vec4(vec3(.24,.91,1.)*(1.1+rim),1);
  if(material==4)base=vec3(.003,.012,.02);
  if(material==5)base=vec3(.035,.27,.32);
  if(material==6)base=mix(vec3(.025,.028,.055),vec3(.18,.15,.27),scale)*1.3;
  if(material==7)base=vec3(.58,.75,.85);
  return vec4(base*diffuse+spec*vec3(.57,.85,.91)+rim*vec3(.03,.23,.29),1);
}
