// Solid layers. Fire, smoke, tornado and the black hole use optical integration instead.
vec3 boltPoint(float k,float flash){
  return vec3((hash31(vec3(k,flash,2))-.5)*.24,.82-k*.117,
              (hash31(vec3(k,flash,7))-.5)*.16);
}
float rockFacet(vec3 p,vec3 b){
  float d=boxSdf(p,b);
  d=max(d,(dot(p,normalize(vec3(.7,1.,.35)))-b.y*.77));
  d=max(d,(dot(p,normalize(vec3(-.9,.35,.8)))-b.x*.97));
  d=max(d,(dot(p,normalize(vec3(.3,-.4,-1.)))-b.z*.89));
  return d;
}
float icePrism(vec3 p,float radius,float height){
  float y=(p.y+height*.5)/height;
  float width=radius*clamp(1.-max(0.,y-.50)*1.9,.015,1.);
  float d=max(-p.y-height*.5,p.y-height*.5);
  for(int i=0;i<6;i++){float a=float(i)*1.047197;d=max(d,dot(p.xz,vec2(cos(a),sin(a)))-width);}
  return d;
}
float rosterShape(int mode,vec3 p,float t){
  float d=3.;vec3 q=p;
  if(mode==10){
    float radial=length(p.xy),angle=atan(p.y,p.x);
    float spokes=abs(sin(angle*9.+.025*sin(angle*7.)))*radial/9.-.0025;
    float spiral=abs(mod(radial+.015*angle+.012*sin(angle*5.+radial*9.),.095)-.0475)-.0026;
    return max(min(spokes,spiral),max(radial-.87,abs(p.z)-.0028));
  }
  if(mode==11){q.xy-=vec2(.014*sin(p.z*9.-t*3.),.012*cos(p.z*11.));return max(length(q.xy)-.007,abs(p.z)-.77);}
  if(mode==12){
    for(int i=0;i<7;i++){
      float k=float(i),seed=hash31(vec3(k,3,6));
      vec3 v=p-vec3((k-3.)*.19,-.22+seed*.12,sin(k*3.)*.16);
      v.xy=spin((seed-.5)*.75)*v.xy;v.xz=spin(k*1.7)*v.xz;
      d=min(d,rockFacet(v,vec3(.14+seed*.07,.19+seed*.18,.15)));
    }return d;
  }
  if(mode==13){
    float flash=floor(t*10.);
    for(int i=0;i<14;i++){
      float k=float(i);vec3 v=boltPoint(k,flash),w=boltPoint(k+1.,flash);
      d=min(d,capsule(p,v,w,.008));
      if(i==3||i==6||i==9){
        vec3 start=v;float side=i==6?-1.:1.;
        for(int j=1;j<5;j++){
          float f=float(j);vec3 end=v+vec3(side*(f*.105+.025*sin(f*8.+k)),-f*.092,sin(k+f)*.07);
          d=min(d,capsule(p,start,end,.0045-f*.00065));start=end;
        }
      }
    }return d;
  }
  if(mode==14){
    // Vertical compression streamlines; this is not the awakened black-hole mode.
    float angle=mod(atan(p.z,p.x)-p.y*.38+ASC_PI/9.,2.*ASC_PI/9.)-ASC_PI/9.;
    vec2 folded=vec2(cos(angle),sin(angle))*length(p.xz);
    d=max(length(folded-vec2(.25+.39*p.y*p.y,0))-.008,abs(p.y)-.82);
    return min(d,torus(p,.27,.005));
  }
  if(mode==15){
    q.xy=spin(-.35)*q.xy;
    float y=clamp((q.y+.38)/1.23,0.,1.);
    float width=.145*(1.-pow(y,4.));
    float blade=max(max(abs(q.x)-width,abs(q.y-.23)-.61),abs(q.z)-(.052*(1.-abs(q.x)/max(width,.001))+.009));
    float guard=rockFacet(q-vec3(0,-.43,0),vec3(.30,.035,.06));
    float grip=capsule(q,vec3(0,-.78,0),vec3(0,-.45,0),.043);
    return min(blade,min(guard,grip));
  }
  if(mode==16){q.yz=spin(1.570796)*q.yz;d=torus(q,.74,.008);d=min(d,torus(q,.55,.006));return min(d,torus(q,.33,.004));}
  if(mode==17){
    d=boxSdf(p,vec3(.165,.64,.165))-.015;
    for(int i=0;i<5;i++){float y=-.48+float(i)*.24;d=min(d,boxSdf(p-vec3(0,y,0),vec3(.205,.035,.205))-.008);}
    d=min(d,boxSdf(p-vec3(0,.68,0),vec3(.23,.075,.23))-.012);
    d=min(d,boxSdf(p-vec3(0,-.68,0),vec3(.23,.075,.23))-.012);
    return d;
  }
  if(mode==18){q.yz=spin(.5)*q.yz;return rockFacet(q,vec3(.27,.38,.17));}
  if(mode==21){
    q.xz=spin(.38)*q.xz;d=icePrism(q-vec3(0,.01,0),.19,1.55);
    q=p-vec3(.23,-.23,.08);q.xy=spin(.35)*q.xy;d=min(d,icePrism(q,.105,.88));
    q=p-vec3(-.17,-.30,-.12);q.yz=spin(-.25)*q.yz;return min(d,icePrism(q,.10,.70));
  }
  return length(p)-.3;
}
vec4 rosterMaterial(int mode,vec3 p,vec3 n,vec3 ray,float t){
  vec3 lightDir=normalize(vec3(-.4,.8,.5));
  float diffuse=max(0.,dot(n,lightDir)),rim=pow(1.-abs(dot(n,ray)),3.);
  float spec=pow(max(0.,dot(reflect(-lightDir,n),-ray)),38.);
  float rough=fbm(p*21.),fine=noise3(p*145.);vec3 color;float alpha=1.;
  if(mode==10||mode==11){color=mix(vec3(.35,.40,.42),vec3(.95,.97,.97),diffuse*.6+rim*.3)+spec*.25;alpha=.82;}
  else if(mode==12){
    float mineral=noise3(p*65.),dark=smoothstep(.54,.69,mineral);
    color=mix(vec3(.48,.43,.37),vec3(.11,.10,.09),dark);
    color=mix(color,vec3(.68,.63,.55),pow(rough,3.)*.6);
    float seam=1.-smoothstep(.015,.06,abs(noise3(p*8.)-.5));
    color*=.30+diffuse*.65;color*=1.-seam*.5;color+=spec*pow(fine,8.)*.4;
  }
  else if(mode==13){color=vec3(.86,.93,1.);alpha=.98;}
  else if(mode==14){float pulse=pow(.5+.5*sin(p.y*11.-t*8.),6.);color=mix(vec3(.20,.38,.48),vec3(.83,.94,1.),pulse);alpha=.38+pulse*.48;}
  else if(mode==15){
    vec3 q=p;q.xy=spin(-.35)*q.xy;
    float edge=smoothstep(.075,.13,abs(q.x)),blade=step(-.38,q.y);
    color=mix(vec3(.075,.009,.013),vec3(.45,.012,.025),rough);
    color=mix(color,vec3(.55,.59,.61),edge*blade);
    if(q.y<-.4)color=mix(vec3(.035,.022,.020),vec3(.21,.13,.07),rough);
    float vein=1.-smoothstep(.006,.020,abs(q.x-(noise3(vec3(q.y*12.,0,0))-.5)*.055));
    color=color*(.32+diffuse*.65)+spec*vec3(.75,.72,.68)*(.2+edge*.7)+vec3(.45,.008,.015)*vein*blade;
  }
  else if(mode==16){color=vec3(.68,.87,.88);alpha=.24+rim*.30;}
  else if(mode==17||mode==18){
    color=mix(vec3(.12,.14,.15),vec3(.36,.38,.39),rough*.6+fine*.2);
    color*=.36+diffuse*.55;color+=spec*vec3(.65,.70,.73)*.8;
    float brushed=noise3(p*vec3(120.,8.,120.)),scratches=pow(noise3(p*vec3(240.,12.,240.)),12.);
    color*=.85+brushed*.25;color+=scratches*.18;
    if(mode==17&&abs(p.y)>.61)color=mix(color,p.y>0.?vec3(.035,.26,.58):vec3(.65,.075,.025),.80);
    color+=rim*vec3(.12,.15,.17);
  }
  else{
    float fracture=1.-smoothstep(.008,.055,abs(noise3(p*15.)-.49));
    color=mix(vec3(.035,.19,.27),vec3(.40,.69,.78),rough*.6+diffuse*.3);
    color+=vec3(.40,.65,.69)*fracture*.38+vec3(.70,.91,.96)*spec+rim*vec3(.12,.27,.32);
  }
  return vec4(color,alpha);
}
