// Speed: compressed air, tapered wakes and physical shock fronts. No electrical arcs.
float speedBand(float d,float width){return exp(-abs(d)/width);}
vec4 speedSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
 hit=end+.01;vec3 p,n;vec4 result=vec4(0);float best=end+.01;
 if(mode==108||mode==109){
  // Axial pulse/trajectory: volumetric thin core, discrete forward chevrons and flowing tracer.
  vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-.58*.58);
  for(int k=0;k<2;k++){
   float s=roots[k];p=ro+rd*s;if(s<begin||s>end||abs(p.z)>.97)continue;
   float a=atan(p.y,p.x),pulse=speedBand(fract(p.z*.65-t*1.8)-.5,.045);
   float fins=pow(max(0.,cos(a*4.)),28.)*(.28+pulse*.7);
   float chevron=speedBand(fract(p.z*3.+abs(sin(a*2.))*.3-t*.7)-.5,.025);
   float alpha=mode==108?fins:chevron*.85+fins*.18;
   if(s<best&&alpha>.008){best=s;result=vec4(vec3(1.,.93,.75)+pulse*.3,alpha);}
  }
 }else if(mode==110){
  if(abs(rd.y)<1e-7)return result;float s=-ro.y/rd.y;p=ro+rd*s;
  if(s<begin||s>end||length(p.xz)>.98)return result;
  float r=length(p.xz),a=atan(p.z,p.x),fade=1.-smoothstep(.65,.98,r);
  float splits=speedBand(sin(a*7.+sin(r*22.)*.18)*r,.009)*smoothstep(.10,.25,r);
  float branch=speedBand(sin(a*13.+r*8.)*r,.006)*smoothstep(.3,.5,r);
  float front=speedBand(r-min(.94,t*3.),.025)*(1.-smoothstep(.15,.4,t));
  best=s;result=vec4(vec3(.78,.68,.49)+front*.7,(splits*.55+branch*.3+front)*fade*(1.-smoothstep(.15,.8,t)));
 }else if(mode==111){
  // Rigid Minecraft-shaped runner, held in a sprint pose as the real player moves away.
  for(int k=0;k<6;k++){
   vec3 center=k==0?vec3(0,.72,.10):k==1?vec3(0,.16,0):k==2?vec3(-.35,.14,-.13):k==3?vec3(.35,.23,.13):k==4?vec3(-.14,-.57,.16):vec3(.14,-.57,-.16);
   vec3 axes=k==0?vec3(.21):k==1?vec3(.25,.34,.13):k<4?vec3(.115,.31,.12):vec3(.12,.34,.13);
   float angle=k<2?-.13:k==2||k==5?.70:-.70;
   vec3 o=ro-center,d=rd;mat2 pose=spin(angle);o.yz=pose*o.yz;d.yz=pose*d.yz;
   float s;vec3 normal;if(!revisionBox(o,d,axes,begin,end,s,normal)||s>best)continue;
   vec3 q=o+d*s;vec3 relative=abs(q/axes);float bevel=pow(max(min(relative.x,relative.y),max(min(relative.x,relative.z),min(relative.y,relative.z))),24.);
   float shine=pow(1.-abs(dot(normal,d)),3.);
   best=s;result=vec4(vec3(.87,.93,1.)+bevel*.25,(.09+bevel*.45+shine*.12)*(1.-smoothstep(.05,.6,t)));
  }
 }else{
  // Wake, turn wave, final-break bow shock and Mach cone are distinct analytic surfaces.
  for(int k=0;k<3;k++){
   float s;
   if(mode==106){
    float radius=.25+float(k)*.25;vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-radius*radius);s=roots.x>=begin?roots.x:roots.y;
   }else if(mode==107){
    float radius=.20+mod(t*2.+float(k)*.24,.75);vec2 roots=quadratic(dot(rd,rd),2.*dot(ro,rd),dot(ro,ro)-radius*radius);s=roots.x>=begin?roots.x:roots.y;
   }else{
    float slope=mode==112?-.75:-.48,offset=.18+float(k)*.12;
    float r0=offset+slope*ro.z,dr=slope*rd.z;
    vec2 roots=quadratic(dot(rd.xy,rd.xy)-dr*dr,2.*(dot(ro.xy,rd.xy)-r0*dr),dot(ro.xy,ro.xy)-r0*r0);s=roots.x>=begin?roots.x:roots.y;
   }
   if(s<begin||s>best||s>end)continue;p=ro+rd*s;if(abs(p.z)>.95||length(p.xy)>.98)continue;
   float a=atan(p.y,p.x),r=length(p.xy),alpha=0.;
   if(mode==106){
    float filaments=pow(max(0.,cos(a*(12.+float(k)*5.)+sin(a*3.)*.4)),50.);
    float taper=smoothstep(-.96,-.6,p.z)*(1.-smoothstep(.35,.96,p.z));
    float stream=.35+.65*pow(.5+.5*cos(p.z*18.-t*28.+float(k)*2.),5.);
    alpha=filaments*taper*stream*.85;
   }else if(mode==107){
    float equator=speedBand(p.y,.06),ripple=pow(max(0.,cos(a*18.+r*6.)),24.);
    alpha=(equator*.6+ripple*.12)*(1.-smoothstep(.05,.65,t));
   }else{
    float edge=speedBand(p.z-(.72-float(k)*.14),.035);
    float streak=pow(max(0.,cos(a*27.+sin(a*5.)*.7)),44.);
    float taper=smoothstep(-.95,-.55,p.z)*(1.-smoothstep(.65,.95,p.z));
    alpha=(.07+edge*.7+streak*.38)*taper;
   }
   if(alpha>.004){best=s;result=vec4(mix(vec3(.69,.82,.94),vec3(1.20,1.10,.87),float(mode==112||mode==113)),min(.95,alpha));}
  }
 }
 if(result.a>.003)hit=best;return result;
}
