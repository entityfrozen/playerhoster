// Boom: fixed analytic bodies. Texture flow adds motion without moving collision roots.
bool boomEllipsoid(vec3 ro,vec3 rd,vec3 center,vec3 size,float near,float far,out float hit,out vec3 normal){
 vec3 a=(ro-center)/size,b=rd/size;vec2 roots=quadratic(dot(b,b),2.*dot(a,b),dot(a,a)-1.);
 hit=roots.x>=near?roots.x:roots.y;if(hit<near||hit>far)return false;
 normal=normalize((ro+rd*hit-center)/(size*size));return true;
}
vec4 boomSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
 hit=end+.01;vec3 normal=vec3(0),n;float s;bool found=false;
 if(mode==124){
  if(!revisionBox(ro,rd,vec3(.6,.34,.6),begin,end,hit,normal))return vec4(0);
  vec3 p=ro+rd*hit;float steel=.22+.1*noise3(p*40.);float seam=exp(-abs(abs(p.x)-.4)*85.);
  float lamp=exp(-length(vec2(p.x,p.z-.55))*18.)*(.6+.4*sin(t*9.));
  return vec4(vec3(steel*.5,steel*.55,steel*.6)+vec3(.8,.08,.015)*(seam+lamp),1.);
 }
 if(mode==125||mode==126){
  // A steel cylinder, tapered nose, engine and four solid tail fins.
  float width=mode==126?.60:.36;
  vec2 roots=quadratic(dot(rd.xy,rd.xy),2.*dot(ro.xy,rd.xy),dot(ro.xy,ro.xy)-width*width);
  for(int i=0;i<2;i++){float q=roots[i];vec3 p=ro+rd*q;if(q>=begin&&q<=end&&abs(p.z)<.67&&q<hit){hit=q;normal=normalize(vec3(p.xy,0));found=true;}}
  if(boomEllipsoid(ro,rd,vec3(0,0,.57),vec3(width,width,.4),begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  if(mode==126&&boomEllipsoid(ro,rd,vec3(0,0,-.1),vec3(.65,.65,.67),begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  for(int i=0;i<2;i++){
   vec3 a=ro-vec3(0,0,-.67);vec3 size=i==0?vec3(.75,.055,.22):vec3(.055,.75,.22);
   if(revisionBox(a,rd,size,begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  }
  if(!found)return vec4(0);vec3 p=ro+rd*hit;
  float stripe=step(.16,p.z)*step(p.z,.3),panels=pow(.5+.5*cos(atan(p.y,p.x)*8.),35.);
  float light=.35+.65*max(0.,dot(normal,normalize(vec3(-.5,.8,-.4))));
  float shine=pow(max(0.,dot(reflect(rd,normal),normalize(vec3(-.4,.8,-.6)))),32.);
  vec3 paint=mix(vec3(.19,.22,.23),vec3(.67,.045,.018),stripe);if(p.z>.68)paint=vec3(.075,.08,.085);
  if(mode==126){float hazard=step(.2,p.z)*step(p.z,.43);float bands=step(0.,sin(atan(p.y,p.x)*8.+p.z*13.));paint=mix(vec3(.19,.23,.12),mix(vec3(.04),vec3(.94,.66,.055),bands),hazard);}
  return vec4(paint*light+shine*.65+panels*.045,1.);
 }
 if(mode==127){
  t*=.4;
  float expand=min(1.,.2+t*2.);bool fire=false;
  if(boomEllipsoid(ro,rd,vec3(0),vec3(.65*expand),begin,end,s,n)){hit=s;normal=n;fire=true;}
  for(int i=0;i<10;i++) {float a=float(i)*2.39996;vec3 center=vec3(cos(a)*.46,sin(a*1.7)*.33,sin(a)*.46)*expand;
   if(boomEllipsoid(ro,rd,center,vec3(.31*expand),begin,end,s,n)&&s<hit){hit=s;normal=n;fire=true;}}
  if(!fire)return vec4(0);
  vec3 p=ro+rd*hit;float flow=fbm(p*vec3(9.,10.,9.)-vec3(0,t*2.8,0));
  float hot=pow(max(0.,1.-t*.8),2.)+.42*flow;float rim=pow(1.-abs(dot(normal,rd)),2.);
  vec3 color=mix(vec3(.12,.055,.025),vec3(1.3,.29,.025),smoothstep(.2,.65,hot));
  color=mix(color,vec3(2.,1.65,.85),smoothstep(.5,.98,hot));
  return vec4(color,(.88-rim*.25)*max(.0,1.-smoothstep(.65,1.2,t)));
 }
 if(mode==129){
  // Rising column, outward-rolling cap and low dust. All intersections have a fixed budget.
  float rise=1.-exp(-t*.65),spread=1.-exp(-t*.22),capY=.08+.39*rise;
  for(int j=0;j<6;j++){
   float f=float(j)/5.,jet=t*.7-f*3.;
   vec3 center=vec3(sin(jet)*.025,-.72+f*(capY+.64),cos(jet*1.13)*.025);
   float width=.12+.05*sin(f*5.+t*.8)+.04*f;
   if(boomEllipsoid(ro,rd,center,vec3(width,.23,width),begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  }
  float capWidth=.29+.37*spread;
  if(boomEllipsoid(ro,rd,vec3(0,capY,0),vec3(capWidth,.20+.08*spread,capWidth),begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  for(int j=0;j<16;j++){
   float a=float(j)*2.399963,roll=t*.83+float(j)*1.73;
   float radius=capWidth*(.63+.10*sin(roll));
   vec3 center=vec3(cos(a)*radius,capY+cos(roll)*.075+sin(float(j)*5.7)*.035,sin(a)*radius);
   float width=.17+.09*spread+.035*sin(roll+.9);
   vec3 size=vec3(width,.16+.08*spread+.025*cos(roll),width);
   if(boomEllipsoid(ro,rd,center,size,begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  }
  for(int j=0;j<4;j++){
   float a=float(j)*2.399963+t*.025;
   vec3 center=vec3(cos(a)*(.25+spread*.10),-.81,sin(a)*(.25+spread*.10));
   if(boomEllipsoid(ro,rd,center,vec3(.26+spread*.13,.085,.26+spread*.13),begin,end,s,n)&&s<hit){hit=s;normal=n;found=true;}
  }
  if(!found)return vec4(0);vec3 p=ro+rd*hit;
  float r=length(p.xz);vec2 direction=p.xz/max(.001,r);
  vec2 roll=spin(t*.65)*vec2(r-capWidth*.65,(p.y-capY)*1.6);
  vec3 flow=vec3(direction.x*(roll.x+capWidth*.65),roll.y,direction.y*(roll.x+capWidth*.65));
  vec3 q=mix(p-vec3(0,t*.18,0),flow,smoothstep(capY-.28,capY,p.y));
  float smoke=fbm(q*14.),fine=noise3(q*46.);
  vec3 bump=vec3(noise3(q*28.+vec3(.17,0,0)),noise3(q*28.+vec3(0,.17,0)),noise3(q*28.+vec3(0,0,.17)))-vec3(noise3(q*28.));
  vec3 litNormal=normalize(normal+bump*.45);
  float sun=.45+.55*max(0.,dot(litNormal,normalize(vec3(-.5,.85,-.35))));
  float belly=mix(.72,1.,smoothstep(capY-.22,capY+.13,p.y));
  vec3 color=mix(vec3(.20,.18,.16),vec3(1.,.96,.88),smoothstep(.18,.85,smoke))*sun*belly+fine*.025;
  float heat=exp(-t*.8)*exp(-abs(p.y-capY)*4.);
  color+=vec3(1.3,.25,.025)*heat*(.15+smoke*.5);
  float rim=pow(1.-abs(dot(litNormal,rd)),2.);
  float opacity=(.78+smoke*.2-rim*.22)*smoothstep(0.,.25,t)*(1.-smoothstep(11.5,15.,t));
  return vec4(color,opacity);
 }
 if(mode==128||mode==130||mode==131){
  if(abs(rd.y)<1e-7)return vec4(0);hit=-ro.y/rd.y;if(hit<begin||hit>end)return vec4(0);
  vec3 p=ro+rd*hit;float r=length(p.xz);if(r>.98)return vec4(0);float a=atan(p.z,p.x);
  if(mode==131){float ring=exp(-abs(r-.87)*230.)+exp(-abs(r-.7)*190.);float ticks=pow(.5+.5*cos(a*24.),28.)*exp(-abs(r-.79)*95.);float cross=exp(-abs(p.x)*160.)+exp(-abs(p.z)*160.);return vec4(vec3(1.,.025,.012),min(.95,(ring+ticks+cross*.4)*(.65+.35*sin(t*7.))));}
  if(mode==128){t*=.4;float front=clamp(t*1.5,.03,.95);float wave=exp(-abs(r-front)*85.);return vec4(vec3(1.7,1.1,.48),wave*.8);}
  float ash=fbm(p*16.);vec2 cell=floor(p.xz*8.),f=fract(p.xz*8.);float d1=10.,d2=10.;
  for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){vec2 o=vec2(x,y);vec3 seed=vec3(cell+o,1.);vec2 jitter=vec2(hash31(seed),hash31(seed+17.));float d=length(o+jitter-f);if(d<d1){d2=d1;d1=d;}else d2=min(d2,d);}
  float crack=1.-smoothstep(.008,.04,d2-d1);
  return vec4(vec3(.025)+vec3(.6,.10,.015)*crack*.3,(.3+ash*.5)*(1.-smoothstep(.6,.98,r)));
 }
 return vec4(0);
}
