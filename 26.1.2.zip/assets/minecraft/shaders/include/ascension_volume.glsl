#ifndef ASCENSION_VOLUME
#define ASCENSION_VOLUME
const float ASC_PI=3.14159265359;
mat2 spin(float a){return mat2(cos(a),-sin(a),sin(a),cos(a));}
float boxSdf(vec3 p,vec3 b){vec3 q=abs(p)-b;return length(max(q,0.))+min(max(q.x,max(q.y,q.z)),0.);}
float capsule(vec3 p,vec3 a,vec3 b,float r){vec3 d=b-a;return length(p-a-d*clamp(dot(p-a,d)/max(dot(d,d),.0001),0.,1.))-r;}
float torus(vec3 p,float r,float w){return length(vec2(length(p.xz)-r,p.y))-w;}
float crystal(vec3 p,float r){return (abs(p.x)*1.5+abs(p.y)+abs(p.z)*1.5-r)*.43;}
float grain(vec3 p){return sin(p.x*7.+sin(p.z*5.))*sin(p.y*9.+cos(p.x*3.));}
#moj_import <minecraft:ascension_optics.glsl>
#moj_import <minecraft:ascension_roster.glsl>
#moj_import <minecraft:ascension_moves.glsl>
float shape(int mode,vec3 p,float t){
  if(mode>=23)return moveShape(mode,p,t);
  if(mode>=8)return rosterShape(mode,p,t);
  int m=mode%4;bool detail=mode>=4;float d=3.;
  if(m==0){
    // A thin floor sweep, raised outer frost teeth, and six branching dendrites.
    if(!detail){
      float frost=fbm(p*vec3(26.,1.,26.));
      d=max(max(abs(p.y)-.005,length(p.xz)-.83),(.47-frost)*.025);
      d=min(d,torus(p-vec3(0,.004,0),.84,.010));
      d=min(d,max(abs(length(p.xz)-.79)-.016,abs(p.y)-.004));
      for(int i=0;i<36;i++){vec3 q=p;q.xz=spin(float(i)*ASC_PI/18.)*q.xz;q-=vec3(.80,.028,0);d=min(d,crystal(q,.048));}
      return d;
    }
    for(int i=0;i<6;i++){
      vec3 q=p;q.xz=spin(float(i)*ASC_PI/3.)*q.xz;
      d=min(d,capsule(q,vec3(.05,.006,0),vec3(.73,.006,0),.003));
      for(int j=1;j<4;j++){float r=float(j)*.16;d=min(d,capsule(q,vec3(r,.006,0),vec3(r+.12,.006,.12),.003));d=min(d,capsule(q,vec3(r,.006,0),vec3(r+.12,.006,-.12),.003));}
    }
    return d;
  }
  if(m==1){
    // Wrist, broad palm and four separated knuckles form a recognizable clenched hand.
    d=boxSdf(p-vec3(0,-.07,-.40),vec3(.19,.16,.22))-.025;
    d=min(d,boxSdf(p-vec3(0,-.04,.04),vec3(.36,.20,.22))-.035);
    for(int i=0;i<4;i++){
      float x=(float(i)-1.5)*.23;vec3 q=p-vec3(x,.20,.32);
      q.yz=spin(-.10+float(i)*.035)*q.yz;
      d=min(d,boxSdf(q,vec3(.084,.17,.16))-.022);
      d=min(d,boxSdf(p-vec3(x,-.06,.34),vec3(.084,.09,.12))-.020);
    }
    vec3 q=p-vec3(-.43,-.15,.16);q.xy=spin(-.45)*q.xy;
    d=min(d,boxSdf(q,vec3(.11,.12,.20))-.025);
    if(detail)return abs(d)-.008;
    return d;
  }
  if(m==2){
    // Loose incandescent fragments accompany the separately integrated flame volume.
    for(int i=0;i<7;i++){
      float a=float(i)*ASC_PI*2./7.;vec3 q=p;
      q.xz-=vec2(cos(a),sin(a))*(.37+.055*sin(p.y*7.-t*9.+a));
      q.x+=.035*sin(p.y*13.-t*8.+a);
      q.y-=mod(t*.6+float(i)*.19,1.4)-.7;d=min(d,crystal(q,.025));
    }return d;
  }
  // Discrete hot fragments accompany Backdraft's volumetric pressure front.
  for(int i=0;i<12;i++){
    vec3 k=p;k.xz=spin(float(i)*ASC_PI/6.)*k.xz;
    d=min(d,capsule(k,vec3(.55,.03,0),vec3(.82,.15+.06*sin(float(i)+t*9.),.04),.008));
  }return d;
}
vec4 material(int mode,vec3 p,vec3 normal,vec3 ray,float t){
  if(mode>=23)return moveMaterial(mode,p,normal,ray,t);
  if(mode>=8)return rosterMaterial(mode,p,normal,ray,t);
  if(mode==5){float rim=pow(1.-abs(dot(normal,ray)),3.5);return vec4(.55,.91,1.,rim*.32);}
  bool ice=mode%4<2,detail=mode>=4;
  float rim=pow(1.-abs(dot(normal,ray)),2.5),light=.4+.6*max(0.,dot(normal,normalize(vec3(-.4,.8,.5))));
  float flow=fbm(p*9.+vec3(0,-t*.8,t*.2));
  vec3 c;float alpha;
  if(ice){
    float glint=pow(fbm(p*95.),8.);
    c=mix(vec3(.015,.14,.23),vec3(.48,.84,.94),light*.7+rim*.2);
    c+=vec3(.60,.92,1.)*glint*.4+vec3(.14,.40,.55)*rim;
    alpha=mode%4==0?.26+flow*.40:.96;
    if(detail){c=vec3(.69,.95,1.);alpha=.65+.25*flow;}
  }else{
    c=mix(vec3(.24,.008,.001),vec3(1.,.35,.012),flow);
    c=mix(c,vec3(1.,.88,.43),pow(flow,5.)*.9);c+=vec3(.65,.13,.005)*rim;
    alpha=mode%4==2?.64:.90;
    if(detail){c=mix(vec3(1.,.23,.015),vec3(1.,.94,.65),flow);alpha=.82;}
  }
  return vec4(c,alpha);
}
#moj_import <minecraft:ascension_fast.glsl>
#moj_import <minecraft:ascension_lines.glsl>
#moj_import <minecraft:ascension_solids.glsl>
// Only the small remaining curved surfaces use SDF stepping. Keeping this dispatcher separate
// prevents the driver from retaining the former nested roster geometry inside the fallback loop.
float fallbackShape(int mode,vec3 p,float t){
  if(mode==10){
    float radial=length(p.xy),angle=atan(p.y,p.x);
    float spokes=abs(sin(angle*9.+.025*sin(angle*7.)))*radial/9.-.0025;
    float spiral=abs(mod(radial+.015*angle+.012*sin(angle*5.+radial*9.),.095)-.0475)-.0026;
    return max(min(spokes,spiral),max(radial-.87,abs(p.z)-.0028));
  }
  if(mode==14||mode==48){
    float count=mode==14?9.:12.,twist=mode==14?p.y*.38:0.;
    float angle=mod(atan(p.z,p.x)-twist+ASC_PI/count,2.*ASC_PI/count)-ASC_PI/count;
    vec2 folded=vec2(cos(angle),sin(angle))*length(p.xz);
    float radius=mode==14?.25+.39*p.y*p.y:.70-.48*pow(abs(p.y),.7);
    float line=max(length(folded-vec2(radius,0))-(mode==14?.008:.006),abs(p.y)-.83);
    return min(line,torus(p,mode==14?.27:.62,.005));
  }
  if(mode==16){p.yz=spin(1.570796)*p.yz;return min(torus(p,.74,.008),min(torus(p,.55,.006),torus(p,.33,.004)));}
  if(mode==29){
    float palm=max(abs(p.y-.205)-.004,boxSdf(p-vec3(0,.20,.03),vec3(.35,.01,.20)));
    return max(palm,(abs(noise3(p*vec3(25.,9.,25.))-.51)-.025)*.035);
  }
  if(mode==49){
    vec3 v=p-vec3(.07,.32,0);float crescent=max(abs(length(v.xy)-.54)-.055,max(-v.y-.04,abs(v.z)-.025));
    return min(crescent,capsule(p,vec3(-.27,-.82,0),vec3(-.27,.66,0),.035));
  }
  // Blood's tapered blade; no per-step noise or multi-object traversal.
  vec3 q=p;q.xy=spin(-.35)*q.xy;float y=clamp((q.y+.38)/1.23,0.,1.),width=.145*(1.-pow(y,4.));
  float blade=max(max(abs(q.x)-width,abs(q.y-.23)-.61),abs(q.z)-(.052*(1.-abs(q.x)/max(width,.001))+.009));
  return min(blade,min(rockFacet(q-vec3(0,-.43,0),vec3(.30,.035,.06)),capsule(q,vec3(0,-.78,0),vec3(0,-.45,0),.043)));
}
vec4 arcRender(int mode,vec3 ro,vec3 rd,float t,out float hit){
  vec3 inv=1./(rd+vec3(1e-8)),a=(-vec3(1.)-ro)*inv,b=(vec3(1.)-ro)*inv;
  vec3 lo=min(a,b),hi=max(a,b);float begin=max(max(lo.x,lo.y),lo.z),end=min(min(hi.x,hi.y),hi.z);
  hit=max(.001,begin+.0001);if(end<hit)return vec4(0.);
  if(mode>=55)return revisionSurface(mode,ro,rd,t,hit,end,hit);
  if(mode==0||mode==4)return frostField(mode,ro,rd,t,hit,end,hit);
  if(mode==8||mode==19||mode==37)return livingAtmosphere(mode,ro,rd,t,hit,end,hit);
  if(mode==36)return shadowSurface(ro,rd,t,hit,end,hit);
  if(mode==2||mode==3||mode==7||mode==20||mode==41)return livingAtmosphere(mode,ro,rd,t,hit,end,hit);
  if(mode==9)return funnelSurface(ro,rd,t,hit,end,hit);
  if(mode==43)return pressureColumn(ro,rd,t,hit,end,hit);
  if(mode==32)return dustSurface(ro,rd,t,hit,end,hit);
  if(mode==23||mode==27||mode==52)return waveSurfaces(mode,ro,rd,t,hit,end,hit);
  if(lineMode(mode))return lineScene(mode,ro,rd,t,hit,end,hit);
  if(mode==1||mode==5||mode==12||mode==17||mode==18||mode==21||mode==42||mode==53)return solidScene(mode,ro,rd,t,hit,end,hit);
  if(mode==25)return groundImpactSurface(ro,rd,t,hit,end,hit);
  // Retain the thin edge volume when the camera lies in the flat web's own plane.
  if(mode==10&&abs(ro.z)>.012||mode==44)return webSurface(mode,ro,rd,t,hit,end,hit);
  if(mode==22)return blackHole(ro,rd,t,hit,end,hit);
  float nearest=10.,nearT=hit;bool found=false;
  float pixel=max(.001,length(fwidth(ro+rd*max(hit,.1)))*.35);
  for(int i=0;i<64;i++){vec3 p=ro+rd*hit;float d=abs(fallbackShape(mode,p,t));if(d<nearest){nearest=d;nearT=hit;}if(d<pixel){found=true;break;}hit+=max(pixel*.65,d*.80);if(hit>end)break;}
  if(!found){hit=nearT;float halo=exp(-nearest*(mode==13?55.:80.))*(mode==13?.6:.075);if(halo<.005)return vec4(0.);vec3 glow=mode>=23?moveGlow(mode):mode==13?vec3(.19,.43,1.):mode==14?vec3(.57,.72,.83):mode==15?vec3(.55,.005,.018):mode%4<2?vec3(.35,.78,1.):vec3(1.,.30,.015);return vec4(glow,halo);}
  vec3 p=ro+rd*hit;vec2 e=vec2(.001,0.);
  vec3 n=normalize(vec3(fallbackShape(mode,p+e.xyy,t)-fallbackShape(mode,p-e.xyy,t),fallbackShape(mode,p+e.yxy,t)-fallbackShape(mode,p-e.yxy,t),fallbackShape(mode,p+e.yyx,t)-fallbackShape(mode,p-e.yyx,t)));
  return material(mode,p,n,rd,t);
}
vec3 arcLocal(int face,vec2 uv){vec2 p=uv*2.-1.;int f=face%6;vec3 q=f==0?vec3(p.x,-1.,-p.y):f==1?vec3(p.x,1.,p.y):f==2?vec3(-p.x,-p.y,-1.):f==3?vec3(p.x,-p.y,1.):f==4?vec3(-1.,-p.y,p.x):vec3(1.,-p.y,-p.x);return face>=6?-q:q;}
#endif
