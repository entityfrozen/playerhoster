// Local storm sky and lightning. Analytic shells keep the overhead field inexpensive from inside.
vec4 tempestSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;
  if(mode==86){
    vec3 normal;float best=end+.01,glow=end+.01;
    vec3 last=vec3(.07,.90,-.02);
    for(int j=1;j<=18;j++){
      float f=float(j)/18.;vec3 next=vec3((hash31(vec3(j,7,3))-.5)*.24,.90-1.8*f,(hash31(vec3(j,2,9))-.5)*.19);
      float width=mix(.009,.0035,f);
      float s=creatureCapsule(ro,rd,last,next,width,normal);if(s>=begin)best=min(best,s);
      s=creatureCapsule(ro,rd,last,next,width*3.5,normal);if(s>=begin)glow=min(glow,s);
      if(j==5||j==10||j==13){
        vec3 branch=next;
        for(int b=1;b<=3;b++){
          vec3 tip=branch+vec3((j==10?-.09:.10)+(hash31(vec3(b,j,2))-.5)*.09,-.045-hash31(vec3(j,b,9))*.08,(hash31(vec3(j,b,3))-.5)*.09);
          s=creatureCapsule(ro,rd,branch,tip,width*.5,normal);if(s>=begin)best=min(best,s);branch=tip;
        }
      }
      last=next;
    }
    float pulse=.72+.28*sin(t*72.);
    if(best<=end){hit=best;return vec4(vec3(1.55,1.75,2.0)*pulse,.98);}
    if(glow<=end){hit=glow;return vec4(.28,.48,1.,.24*pulse);}return vec4(0);
  }
  vec4 sum=vec4(0);vec3 scale=vec3(1.,.72,1.);
  vec3 o=(ro-vec3(0,.03,0))/scale,d=rd/scale;
  for(int layer=0;layer<2;layer++){
    float radius=.91+float(layer)*.055;
    vec2 roots=quadratic(dot(d,d),2.*dot(o,d),dot(o,o)-radius*radius);
    for(int side=0;side<2;side++){
      float s=roots[side];if(s<begin||s>end)continue;
      vec3 p=ro+rd*s;if(p.y<-.05)continue;
      float r=length(p.xz),angle=atan(p.z,p.x),phase=t*.17+float(layer)*.3;
      vec3 flow=vec3(cos(angle-phase+r*5.)*r*8.,p.y*10.-t*.16,sin(angle-phase+r*5.)*r*8.);
      float billow=fluidFbm(flow),fine=fluidNoise(flow*3.1+11.);
      float eye=smoothstep(.09,.18,r);
      float towers=smoothstep(.24,.68,billow*.80+fine*.20);
      float alpha=eye*(.74+.23*towers)*(1.-smoothstep(.90,.97,r));
      float light=smoothstep(.20,.80,billow)*(.65+fine*.25);
      vec3 color=mix(vec3(.012,.019,.031),vec3(.20,.24,.28),light);
      float flashPhase=mod(t-2.+12.5,2.5),flash=exp(-pow(flashPhase/.045,2.))+.28*exp(-pow((flashPhase-.12)/.025,2.));
      float litCloud=exp(-pow((sin(angle+float(layer))-.35)*2.4,2.))*smoothstep(.18,.72,billow);
      color+=vec3(.18,.26,.42)*flash*(.12+litCloud*.88);
      if(alpha>.01){hit=min(hit,s);sum=solarOver(sum,vec4(color,alpha));}
    }
  }
  return sum;
}
