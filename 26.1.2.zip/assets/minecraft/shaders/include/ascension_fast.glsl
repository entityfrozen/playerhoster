// Bounded field renderers. Volumes share cached noise and reject empty work before shading.
#moj_import <minecraft:ascension_atmosphere.glsl>
float revisionCrack(vec3 p);
bool raySphereSpan(vec3 ro,vec3 rd,vec3 center,float radius,out vec2 span){
  vec3 o=ro-center;float b=dot(o,rd),h=b*b-dot(o,o)+radius*radius;
  if(h<0.)return false;h=sqrt(h);span=vec2(-b-h,-b+h);return span.y>0.;
}
vec4 frostField(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=(.006-ro.y)/(abs(rd.y)<1e-7?1e-7:rd.y);
  if(hit<begin||hit>end)return vec4(0);
  vec3 p=ro+rd*hit;float r=length(p.xz);if(r>.86)return vec4(0);
  float aa=max(.001,length(fwidth(p.xz))*.65);
  float angle=atan(p.z,p.x),sector=mod(angle+ASC_PI/6.,ASC_PI/3.)-ASC_PI/6.;
  vec2 q=vec2(cos(sector),sin(sector))*r;
  float trunk=abs(q.y),branch=1.;
  for(int i=1;i<4;i++){
    float x=float(i)*.16;vec2 v=vec2(q.x-x,abs(q.y));
    branch=min(branch,length(v-vec2(.12)*clamp(dot(v,vec2(.12))/.0288,0.,1.)));
  }
  float dendrite=(1.-smoothstep(.002,.002+aa,min(trunk,branch)))*smoothstep(.03,.07,r)*(1.-smoothstep(.73,.75,r));
  if(mode==4)return vec4(.69,.95,1.,dendrite*.85);
  float ice=fbm(p*vec3(26.,1.,26.)),fine=noise3(p*120.);
  float fissures=revisionCrack(vec3(p.xz*13.,5.));
  float inclusions=pow(noise3(vec3(p.xz*76.,9.)),10.);
  float ring=1.-smoothstep(.005,.005+aa,abs(r-.84));
  float teeth=(1.-smoothstep(.005,.025,abs(r-.802)))*pow(max(0.,cos(angle*36.)),6.);
  float opacity=(.24+ice*.38+fissures*.15)*(1.-smoothstep(.79,.83,r));
  vec3 color=mix(vec3(.035,.18,.29),vec3(.48,.80,.91),ice)+pow(fine,9.)*.28;
  color+=vec3(.47,.80,.95)*(fissures*.45+inclusions*.45);
  float detail=max(dendrite,max(ring,teeth));color=mix(color,vec3(.72,.95,1.),detail);
  return vec4(color,max(opacity,detail*.86));
}
vec4 shadowSurface(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal=vec3(0,1,0);vec3 point=vec3(0);
  for(int i=0;i<2;i++){
    vec3 center=i==0?vec3(0,-.22,0):vec3(0,.48,0),scale=i==0?vec3(.34,.54,.29):vec3(.19,.19,.17);
    vec3 o=(ro-center)/scale,d=rd/scale;float b=dot(o,d),a=dot(d,d),c=dot(o,o)-1.,h=b*b-a*c;
    if(h<0.)continue;float s=(-b-sqrt(h))/a;if(s<begin||s>min(hit,end))continue;
    hit=s;point=ro+rd*s;normal=normalize((point-center)/(scale*scale));
  }
  if(hit>end)return vec4(0);float flow=fbm(point*10.-vec3(0,t*.35,0));
  float rim=pow(1.-abs(dot(normal,rd)),3.),fibers=pow(1.-abs(noise3(point*vec3(47.,8.,47.))*2.-1.),12.);
  float dissolve=smoothstep(.18,.44,flow),edge=pow(1.-abs(2.*flow-1.),10.);
  return vec4(vec3(.045,.055,.070)+vec3(.20,.27,.33)*(rim*.55+fibers*.12+edge*.12),(.22+rim*.43)*dissolve);
}
vec2 quadratic(float a,float b,float c){
  if(abs(a)<1e-8){float s=abs(b)<1e-8?1e5:-c/b;return vec2(s);}
  float h=b*b-4.*a*c;if(h<0.)return vec2(1e5);h=sqrt(h);
  vec2 s=vec2(-b-h,-b+h)/(2.*a);return vec2(min(s.x,s.y),max(s.x,s.y));
}
#moj_import <minecraft:ascension_tornado.glsl>
vec4 dustSurface(vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=(.08-ro.y)/(abs(rd.y)<.012?(rd.y<0.?-.012:.012):rd.y);
  if(hit<begin||hit>end)return vec4(0);vec3 p=ro+rd*hit;float r=length(p.xz);if(r>.86)return vec4(0);
  float n=fbm(p*vec3(7.,5.,7.)-vec3(t*.15,t*.7,0));
  return vec4(mix(vec3(.15,.12,.09),vec3(.48,.44,.37),n),(1.-smoothstep(.45,.86,r))*(.15+n*.35));
}
vec4 waveSurfaces(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  hit=end+.01;vec3 normal=vec3(0,1,0);
  for(int i=0;i<3;i++){
    vec2 roots;
    if(mode==52){vec2 span;if(!raySphereSpan(ro,rd,vec3(0),.32+float(i)*.25,span))continue;roots=span;}
    else if(mode==27){float z=-.55+float(i)*.48;roots=quadratic(.35*dot(rd.xy,rd.xy),rd.z+.7*dot(ro.xy,rd.xy),ro.z-z+.35*dot(ro.xy,ro.xy));}
    else{float y=-.45+float(i)*.42;roots=quadratic(.13*dot(rd.xz,rd.xz),rd.y+.26*dot(ro.xz,rd.xz),ro.y-y+.13*dot(ro.xz,ro.xz));}
    for(int side=0;side<2;side++){
      float s=roots[side];if(s<begin||s>min(hit,end))continue;vec3 p=ro+rd*s,n;
      if(mode==52){vec3 q=p;q.xy=spin(float(i)*.27)*q.xy;if(abs(sin(atan(q.z,q.x)*3.+float(i)))>.72)continue;n=normalize(p);}
      else if(mode==27){if(length(p.xy)>.30+float(i)*.24)continue;n=normalize(vec3(p.xy*.7,1.));}
      else{float r=length(p.xz),a=atan(p.z,p.x);if(r>.67-.12*abs(float(i)-1.)||sin(a*2.+float(i)*2.1)<.12)continue;n=normalize(vec3(p.x*.26,1.,p.z*.26));}
      hit=s;normal=n;
    }
  }
  if(hit>end)return vec4(0);return moveMaterial(mode,ro+rd*hit,normal,rd,t);
}
#moj_import <minecraft:ascension_revision.glsl>
