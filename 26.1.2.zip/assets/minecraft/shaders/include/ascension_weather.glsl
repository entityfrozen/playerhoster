// NOAA-inspired hurricane eye, eyewall and spiral rainbands; no cone substitution.
// Ice Rain shares only the bounded optical integrator, not the hurricane's density field.
vec4 weatherField(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
  int samples=mode==83?40:24;
  vec4 sum=vec4(0);hit=begin;bool touched=false;float stepSize=(end-begin)/float(samples);
  float jitter=fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453);
  float phase=t*(2.*ASC_PI/12.5);
  for(int k=0;k<40;k++){
    if(k>=samples)break;
    float s=begin+(float(k)+.15+jitter*.70)*stepSize;vec3 p=ro+rd*s;float r=length(p.xz);
    if(r>.94||abs(p.y)>.92)continue;
    float envelope=(1.-smoothstep(.84,.94,r))*smoothstep(-.92,-.82,p.y)*(1.-smoothstep(.82,.92,p.y));
    float density=0.;vec3 color=vec3(0);
    if(mode==83){
      if(r<.12)continue;
      float a=atan(p.z,p.x),spiral=a-phase+r*6.5;
      vec3 uv=vec3(cos(spiral)*r*13.,p.y*6.+sin(phase)*1.8,sin(spiral)*r*13.);
      float coarse=fluidNoise(uv),fine=fluidNoise(uv*2.07+17.3);
      float cloud=coarse*.72+fine*.28;
      float wallRadius=.235+.065*smoothstep(-.7,.7,p.y)+(cloud-.5)*.045;
      float eyewall=exp(-pow((r-wallRadius)/(.055+.025*cloud),2.));
      float arm=.5+.5*sin(spiral*3.+(cloud-.5)*1.6);
      float bands=pow(arm,7.)*smoothstep(.30,.43,r);
      float cloudTop=.48+.16*sin(spiral*3.)+(cloud-.5)*.21;
      float towers=exp(-pow((p.y-cloudTop)/.19,2.));
      float rainCurtain=smoothstep(-.88,-.55,p.y)*(1.-smoothstep(.23,.54,p.y));
      float anvil=exp(-pow((p.y-(.43+(cloud-.5)*.34))/.19,2.))
        *smoothstep(.13,.23,r)*(1.-smoothstep(.75,.94,r));
      density=(eyewall*(.35+cloud)*6.+bands*(towers*10.+rainCurtain*.13)
        +anvil*(.45+cloud)*2.2)*envelope;
      float light=clamp(.12+cloud*.50+fine*.13+max(0.,p.y)*.28,0.,1.);
      color=mix(vec3(.055,.075,.095),vec3(.84,.88,.88),light);
      vec2 rainCell=floor(vec2(cos(spiral),sin(spiral))*r*72.);
      float rain=step(.976,fract(sin(dot(rainCell,vec2(127.1,311.7)))*43758.5453))
        *pow(.5+.5*sin(p.y*61.+phase*68.),3.);
      density+=rain*(bands+eyewall)*rainCurtain*envelope*6.;
      color+=rain*vec3(.20,.28,.31);
      float flashPhase=mod(t-2.+12.5,2.5);
      float flash=exp(-pow(flashPhase/.045,2.))+.32*exp(-pow((flashPhase-.12)/.025,2.));
      color+=vec3(.38,.48,.67)*flash*(eyewall*.55+bands*.3+anvil*.20);
      float dust=exp(-pow((p.y+.77)/.12,2.))*(eyewall+bands*.6);
      density+=dust*envelope*3.;color=mix(color,vec3(.22,.20,.17),clamp(dust,0.,.55));
      float debris=step(.88,fine)*step(.67,cloud)*exp(-pow((p.y+.54)/.29,2.));
      density+=debris*eyewall*envelope*16.;color=mix(color,vec3(.08,.065,.045),debris*.6);
    }else{
      float cloud=.5;
      if(p.y>.10){
        vec3 uv=p*vec3(7.,4.,7.)-vec3(sin(phase)*1.8,0,cos(phase)*1.4);
        cloud=fluidNoise(uv)*.72+fluidNoise(uv*2.07+17.3)*.28;
      }
      float cap=exp(-pow((p.y-.55-(cloud-.5)*.13)/.17,2.));
      float shafts=pow(fluidNoise(vec3(p.xz*48.,4.)),12.);
      float falling=pow(.5+.5*sin(p.y*39.+phase*38.+cloud*7.),9.);
      density=(cap*(.4+cloud)*1.9+shafts*falling*24.)*envelope;
      color=mix(vec3(.20,.37,.46),vec3(.71,.92,1.),cloud)+shafts*falling*vec3(.6,.8,1.);
    }
    float alpha=1.-exp(-density*stepSize);
    if(alpha>.008&&!touched){hit=s;touched=true;}
    sum.rgb+=(1.-sum.a)*color*alpha;sum.a+=(1.-sum.a)*alpha;
    if(sum.a>.985)break;
  }
  return vec4(sum.rgb/max(sum.a,.001),sum.a);
}
