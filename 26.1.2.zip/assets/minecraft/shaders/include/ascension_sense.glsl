// Sense: optical anatomy, directional fractures and rigid spectral steel. Bounded intersections.
float senseLine(float distance,float width){return exp(-abs(distance)/width);}
vec4 senseSurface(int mode,vec3 ro,vec3 rd,float t,float begin,float end,out float hit){
 hit=end+.01;vec3 p,n;vec2 span;vec4 sum=vec4(0);
 if(mode==98||mode==99){
  vec3 axes=vec3(.96,.58,.22),o=ro/axes,d=rd/axes;
  vec2 roots=quadratic(dot(d,d),2.*dot(o,d),dot(o,o)-1.);
  float s=roots.x>=begin?roots.x:roots.y;if(s<begin||s>end)return sum;hit=s;p=ro+rd*s;
  float lid=.48*max(0.,1.-pow(abs(p.x)/.96,1.5));
  float edge=senseLine(abs(p.y)-lid,.016),body=1.-smoothstep(lid-.02,lid+.02,abs(p.y));
  vec2 q=vec2(p.x,p.y*1.2);float r=length(q),a=atan(q.y,q.x);
  float iris=1.-smoothstep(.29,.31,r),pupil=1.-smoothstep(.96,1.08,length(q/vec2(.065,.25)));
  float fiber=pow(.5+.5*cos(a*79.+sin(a*19.)*2.+r*100.-t*.3),4.);
  float limbus=senseLine(r-.30,.011),inner=senseLine(r-.105,.014);
  vec3 white=vec3(.17,.065,.29)+vec3(.35,.13,.55)*pow(max(0.,1.-r),2.);
  vec3 irisColor=mix(vec3(.24,.018,.57),vec3(.91,.48,1.15),fiber*.65+inner*.35);
  vec3 color=mix(white,irisColor,iris);color=mix(color,vec3(.008,.002,.025),pupil);
  color+=vec3(.83,.44,1.1)*(edge*1.3+limbus*.7)+vec3(1.2)*exp(-length(q-vec2(-.08,.11))*65.);
  float lashes=pow(max(0.,cos(a*12.)),38.)*senseLine(r-.75,.045);
  float orbit=senseLine(length(p.xy*vec2(1.,1.65))-.91,.008);
  float runes=pow(max(0.,cos(a*20.-t*.8)),45.)*senseLine(length(p.xy*vec2(1.,1.65))-.82,.018);
  float alpha=body*(.18+iris*.65)+edge*.9+orbit*.36+runes*.6+lashes*.3;
  if(mode==99){float crack=abs(q.x+q.y*.4+.035*sin(q.y*40.));alpha*=smoothstep(.025,.045,crack);color+=vec3(.8,.5,1.)*senseLine(crack-.035,.014);}
  return vec4(color,min(.98,alpha)*smoothstep(0.,.16,t));
 }
 if(mode==100){
  vec3 axes=vec3(.94,.75,.94),o=ro/axes,d=rd/axes;vec2 roots=quadratic(dot(d,d),2.*dot(o,d),dot(o,o)-1.);
  float s=roots.x>=begin?roots.x:roots.y;if(s<begin||s>end)return sum;hit=s;p=ro+rd*s;
  float a=atan(p.z,p.x),r=length(p.xz),rim=pow(1.-abs(dot(normalize(p/axes),rd)),3.);
  float waves=pow(max(0.,cos(p.y*36.+sin(a*7.-t)*.9-t*2.)),30.);
  float glyph=pow(max(0.,cos(a*18.+sin(p.y*10.))),45.)*senseLine(p.y+.2,.1);
  return vec4(vec3(.48,.16,.88)+waves*.3+glyph*.6,.022+rim*.14+waves*.16+glyph*.4);
 }
 if(mode==101){
  if(!revisionBox(ro,rd,vec3(.84,.94,.15),begin,end,hit,n))return sum;p=ro+rd*hit;
  vec2 face=abs(n.z)>.5?p.xy:abs(n.x)>.5?vec2(p.z*4.,p.y):vec2(p.x,p.z*4.);
  float slash=face.x+face.y*.23+.07*sin(face.y*15.),seam=senseLine(slash,.012);
  float branches=senseLine(abs(slash)-(.12+.15*sin(p.y*9.)),.009)*smoothstep(.03,.12,abs(p.y));
  float edge=pow(1.-abs(dot(n,rd)),3.);return vec4(vec3(.64,.24,1.)+seam*.8,(seam+branches*.65+edge*.08)*(1.-smoothstep(.75,.95,abs(p.y))));
 }
 if(mode==102){
  // Three rigid parts, with a tapered crystalline blade. No elastic pose motion.
  float nearest=end+.01;vec3 normal;bool found=false;
  for(int k=0;k<3;k++){
   vec3 center=k==0?vec3(0,.14,0):k==1?vec3(0,-.51,0):vec3(0,-.76,0);
   vec3 size=k==0?vec3(.38,.80,.10):k==1?vec3(.78,.065,.15):vec3(.065,.23,.065);
   float s;vec3 nn;if(revisionBox(ro-center,rd,size,begin,end,s,nn)&&s<nearest){
    vec3 q=ro+rd*s;if(k==0&&abs(q.x)>(.97-q.y)*.32)continue;nearest=s;normal=nn;found=true;
   }
  }
  if(!found)return sum;hit=nearest;p=ro+rd*hit;
  float bevel=senseLine(abs(p.x)-(.97-p.y)*.32,.014)*step(-.5,p.y);
  float spine=senseLine(p.x,.008)*step(-.52,p.y),runes=pow(max(0.,cos(p.y*52.)),20.)*senseLine(p.x,.04)*step(-.45,p.y);
  float shine=pow(max(0.,dot(reflect(rd,normal),normalize(vec3(-.3,.7,-1.)))),32.);
  return vec4(vec3(.24,.12,.43)+vec3(.59,.29,.9)*shine+vec3(.95,.63,1.2)*(bevel+spine*.6+runes*.5),.40+bevel*.5+spine*.35);
 }
 if(mode==103){
  if(!revisionBox(ro,rd,vec3(.96,.88,.12),begin,end,hit,n))return sum;p=ro+rd*hit;
  float r=length(p.xy-vec2(-.14,0)),a=atan(p.y,p.x+.14);
  float arc=senseLine(r-.69,.025)*smoothstep(-.4,.2,cos(a));
  float inner=senseLine(r-.56,.016)*smoothstep(-.2,.4,cos(a));
  float slash=senseLine(p.x-.32+p.y*.35,.018)*(1.-smoothstep(.5,.85,abs(p.y)));
  float side=abs(n.z)<.5?.065:pow(1.-abs(dot(n,rd)),3.)*.05;
  return vec4(vec3(.64,.27,1.)+vec3(.9,.9,1.)*(arc+slash)*.7,min(.95,arc+inner*.6+slash*.7+side));
 }
 if(mode==104){
  for(int k=0;k<2;k++){
   vec3 center=vec3(k==0?-.29:.29,0,0);vec3 o=ro-center;
   vec2 roots=quadratic(dot(rd,rd),2.*dot(o,rd),dot(o,o)-.12*.12);
   float s=roots.x>=begin?roots.x:roots.y;if(s<begin||s>end)continue;hit=min(hit,s);p=ro+rd*s-center;
   float core=exp(-length(p.xy)*30.);sum=solarOver(sum,vec4(vec3(.63,.13,1.)+core*.8,.55+core*.4));
  }return sum;
 }
 // Owner-only purple edge pulse, leaving the crosshair and combat view clear.
 if(!revisionBox(ro,rd,vec3(.98,.98,.035),begin,end,hit,n))return sum;p=ro+rd*hit;
 vec2 screen=gl_FragCoord.xy/max(ScreenSize,vec2(1.))*2.-1.;
 float edge=pow(max(abs(screen.x),abs(screen.y)),4.),pulse=pow(max(0.,sin(min(t/.6,1.)*3.14159265)),1.3);
 return vec4(vec3(.47,.035,.79),edge*pulse*.54);
}
