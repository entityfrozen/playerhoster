// Native quad vertices pull the original OBJ geometry from per-face metadata texels.
// Tint and two independent magic bytes keep ordinary item textures on the vanilla path.
vec3 aspectVertex(ivec2 texel,ivec4 stamp,out vec3 normal,out int material){
  normal=Normal;material=-1;
  ivec3 tint=ivec3(round(Color.rgb*255.));
  if(stamp.a!=251||any(notEqual(tint,ivec3(11,30,81))))return Position;
  ivec2 size=textureSize(Sampler0,0);
  if(any(greaterThanEqual(texel+ivec2(1),size)))return Position;
  ivec4 n=ivec4(round(texelFetch(Sampler0,texel+ivec2(0,1),0)*255.));
  ivec4 low=ivec4(round(texelFetch(Sampler0,texel+ivec2(1,0),0)*255.));
  if(n.a!=177||low.a>7)return Position;
  material=low.a;
  vec3 p=(vec3(stamp.rgb)*256.+vec3(low.rgb))/65535.;
  normal=normalize(vec3(n.rgb)/127.5-1.);
  if(material==5){
    float a=.07+.055*sin(GameTime*24000.*.11);float c=cos(a),s=sin(a);
    vec2 hinge=vec2(.355,.36);vec2 q=p.yz-hinge;
    p.yz=mat2(c,s,-s,c)*q+hinge;
    normal.yz=mat2(c,s,-s,c)*normal.yz;
  }
  return p;
}
