flat in int legacyHand;
flat in ivec2 legacyOrigin;
in vec2 legacyCanvas;
in vec4 legacyColor;
vec4 legacyHandSurface(){
 vec2 pixel=vec2(legacyOrigin)+vec2(2.5)+clamp(legacyCanvas,vec2(0),vec2(1))*57.;
 return texture(Sampler0,pixel/vec2(textureSize(Sampler0,0)))*legacyColor*ColorModulator;
}
