flat out int legacyHand;
flat out ivec2 legacyOrigin;
out vec2 legacyCanvas;
out vec4 legacyColor;
vec3 legacyHandVertex(ivec2 pixel,ivec4 stamp,out vec3 normal){
 legacyHand=0;legacyOrigin=ivec2(0);legacyCanvas=vec2(0);legacyColor=vec4(1);normal=Normal;
 if(stamp.a!=249)return Position;
 ivec2 size=textureSize(Sampler0,0);if(any(greaterThanEqual(pixel+ivec2(1),size)))return Position;
 ivec4 low=ivec4(round(texelFetch(Sampler0,pixel+ivec2(1,0),0)*255.));
 ivec4 norm=ivec4(round(texelFetch(Sampler0,pixel+ivec2(0,1),0)*255.));
 ivec4 flag=ivec4(round(texelFetch(Sampler0,pixel+ivec2(1,1),0)*255.));
 if(low.a!=167||norm.a!=166||flag.r<90||flag.r>93||any(notEqual(flag.gba,ivec3(37,41,165))))return Position;
 int corner=flag.r-90;ivec2 xy=ivec2(corner&1,(corner>>1)&1);
 legacyHand=1;legacyCanvas=vec2(xy);legacyOrigin=pixel-xy*61;
 normal=normalize(vec3(norm.rgb)/127.5-1.);
 legacyColor=minecraft_mix_light(Light0_Direction,Light1_Direction,normalize(mat3(ModelViewMat)*normal),Color)*texelFetch(Sampler2,UV2/16,0);
 return (vec3(stamp.rgb)*256.+vec3(low.rgb))/65535.*5.-2.;
}
